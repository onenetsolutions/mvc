# PO Management System - Backend Documentation

## 📋 Project Overview

This is a comprehensive **Purchase Order (PO) Management System** built with Node.js, Express.js, and MySQL. The system manages construction/project management operations including employee management, material tracking, machinery management, financial transactions, and various operational workflows.

**Project Name:** PO Management System  
**Version:** 1.0.0  
**Author:** OB  
**Technology Stack:** Node.js, Express.js, MySQL, JWT Authentication  

---

## 🏗️ Architecture & Project Structure

### **MVC Architecture Pattern**
The project follows a **Model-View-Controller (MVC)** architecture with clear separation of concerns:

```
backend/
├── 📁 cantrollers/          # Controllers (Business Logic)
├── 📁 config/              # Configuration Files
├── 📁 libs/                # Core Libraries & Utilities
├── 📁 routes/              # API Route Definitions
├── 📁 services/            # Service Layer (Data Processing)
├── 📁 tmp/                 # Temporary Files
├── 📄 index.js             # Main Application Entry Point
├── 📄 package.json         # Dependencies & Scripts
├── 📄 error.handler.js     # Global Error Handling
└── 📄 .env                 # Environment Variables
```

---

## 🔧 Core Dependencies & Libraries

### **Runtime Dependencies**
- **express** (^4.17.1) - Web framework for Node.js
- **mysql2** (^3.11.4) - MySQL database driver
- **mssql** (^6.2.1) - Microsoft SQL Server support
- **jsonwebtoken** (8.5.1) - JWT token authentication
- **bcryptjs** (^2.4.3) - Password hashing
- **cors** (2.8.5) - Cross-Origin Resource Sharing
- **body-parser** (1.19.0) - Request body parsing
- **cookie-parser** (1.4.5) - Cookie handling
- **dotenv** (8.2.0) - Environment variable management
- **multer** (^1.4.4) - File upload handling
- **express-fileupload** (^1.4.0) - Additional file upload support
- **exceljs** (^4.3.0) - Excel file processing
- **xlsx** (^0.18.5) - Excel/CSV file handling
- **csvtojson** (^2.0.10) - CSV to JSON conversion
- **nodemailer** (^6.4.11) - Email sending functionality
- **node-cron** (^3.0.3) - Scheduled task management
- **moment** (^2.30.1) - Date/time manipulation
- **queue** (^6.0.1) - Job queue management

---

## ⚙️ Configuration Files

### **config/sqlConfig.json**
Database connection configuration for MySQL:
```json
{
  "host": "localhost",
  "user": "root",
  "password": "root123",
  "database": "onepr4co_mvc",
  "connectionLimit": 50,
  "queueLimit": 0,
  "waitForConnections": true,
  "port": 3306,
  "dateStrings": true
}
```

### **config/multer.js**
File upload configuration using Multer middleware:
- **Destination:** `uploads/` directory
- **Filename:** Timestamp + original filename
- **Purpose:** Handle file uploads for documents, images, etc.

---

## 🏛️ Core Libraries (`libs/`)

### **1. `libs/index.js`** - Main Library Index
Central export file that combines all utility modules:
```javascript
module.exports = {
    ...cuQueryBuild,  // Query builders
    ...execute,       // Database executors
    ...auth,          // Authentication utilities
    ...docNo,         // Document number generators
    ...queue,         // Queue management
    eventID          // Event ID generator
};
```

### **2. `libs/dbConnection.js`** - Database Connection Management
- **MySQL Connection Pool:** Manages database connections efficiently
- **Connection Initialization:** Automatic pool creation and management
- **Error Handling:** Graceful connection failure handling
- **Support for MSSQL:** Commented code for Microsoft SQL Server support

**Key Functions:**
- `init()` - Initialize connection pool
- `initConnection()` - Get or create connection pool

### **3. `libs/dbRequest.js`** - Database Query Execution
Handles all database operations with proper error handling:

**Functions:**
- `queryExecute(str)` - Execute SELECT/INSERT/UPDATE queries
- `spExecute(spname, body)` - Execute stored procedures
- `queryExecuteDelete(str)` - Execute DELETE queries with affected rows count

### **4. `libs/dbQueryStr.js`** - Dynamic Query Builders
Advanced SQL query construction utilities:

**Functions:**
- `insertQuery(body, tblName, output)` - Generate INSERT statements
- `updateQuery(body, tblName, search)` - Generate UPDATE statements
- `whereClause(str)` - Build WHERE clauses with operators

**Supported Operators:**
- `eq` (=), `like` (LIKE), `in` (IN), `gt` (>), `gte` (>=)
- `lt` (<), `lte` (<=), `noteq` (!=), `notin` (NOT IN)

### **5. `libs/auth.js`** - Authentication & Authorization
JWT-based authentication system:

**Functions:**
- `sign(user)` - Generate JWT tokens with expiration
- `verify(token)` - Verify and decode JWT tokens
- `verifyASY(token)` - Asynchronous token verification
- `status(UserPass, InputPass, statusOf)` - Password/status validation

**Token Configuration:**
- **Default Expiration:** 24 hours (configurable via `TOKEN_EXPIRE_IN` env var)
- **Private Key:** Configurable via `PKEY` environment variable

### **6. `libs/docNo.js`** - Document Number Generation
Auto-generates document numbers with prefixes:
```javascript
docNo(tableName, colName, docName)
// Example: Generates "INV0001", "INV0002", etc.
```

### **7. `libs/queue.js`** - Job Queue Management
Implements job queues for different operations:
- **Queue Types:** Indent, PO, GRN, DSR, Invoice, DNote
- **Configuration:** Concurrency: 1, Timeout: 5000ms, Auto-start enabled

---

## 🛣️ API Routes Structure

### **Route Organization**
All routes follow RESTful conventions with CRUD operations:

### **Authentication Routes (`routes/r_login.js`)**
```
POST /api/login/login     - User authentication
POST /api/login/logout    - User logout
```

### **Master Data Routes**
```
GET  /api/unit/list           - List units
POST /api/unit/add            - Add new unit
PUT  /api/unit/editDelete     - Update/delete unit

GET  /api/department/list     - List departments
POST /api/department/add      - Add department
PUT  /api/department/editDelete - Update/delete department

GET  /api/party/list          - List parties
POST /api/party/add           - Add party
PUT  /api/party/editDelete    - Update/delete party

GET  /api/employee/list       - List employees
POST /api/employee/add        - Add employee
PUT  /api/employee/editDelete - Update/delete employee

GET  /api/material/list       - List materials
POST /api/material/add        - Add material
PUT  /api/material/editDelete - Update/delete material

GET  /api/machinery/list      - List machinery
POST /api/machinery/add       - Add machinery
PUT  /api/machinery/editDelete - Update/delete machinery

GET  /api/user/list           - List users
POST /api/user/add            - Add user
PUT  /api/user/editDelete     - Update/delete user
```

### **Transaction Routes**
```
GET  /api/attendance/list      - List attendance entries
POST /api/attendance/add       - Add attendance entry
PUT  /api/attendance/editDelete - Update/delete attendance

GET  /api/materialEntry/list   - List material entries
POST /api/materialEntry/add    - Add material entry
PUT  /api/materialEntry/editDelete - Update/delete material entry

GET  /api/paymentEntry/list    - List payment entries
POST /api/paymentEntry/add     - Add payment entry
PUT  /api/paymentEntry/editDelete - Update/delete payment entry

GET  /api/billDetails/list     - List bill details
POST /api/billDetails/add      - Add bill details
PUT  /api/billDetails/editDelete - Update/delete bill details

GET  /api/dailyExpenses/list   - List daily expenses
POST /api/dailyExpenses/add    - Add daily expense
PUT  /api/dailyExpenses/editDelete - Update/delete daily expense

GET  /api/salary/list          - List salary entries
POST /api/salary/add           - Add salary entry
PUT  /api/salary/editDelete    - Update/delete salary entry
```

### **Specialized Routes**
```
GET  /api/tender/list          - List tenders
POST /api/tender/add           - Add tender
PUT  /api/tender/editDelete    - Update/delete tender

GET  /api/workOrder/list       - List work orders
POST /api/workOrder/add        - Add work order
PUT  /api/workOrder/editDelete - Update/delete work order

GET  /api/credit/list          - List credit entries
POST /api/credit/add           - Add credit entry
PUT  /api/credit/editDelete    - Update/delete credit entry

GET  /api/session/list         - List sessions
POST /api/session/add          - Add session
PUT  /api/session/editDelete   - Update/delete session
```

### **Vehicle/Machinery Specific Routes**
```
GET  /api/mvtipper/list        - List tipper vehicle details
POST /api/mvtipper/add         - Add tipper vehicle
PUT  /api/mvtipper/editDelete  - Update/delete tipper vehicle

GET  /api/mvjcb/list           - List JCB vehicle details
POST /api/mvjcb/add            - Add JCB vehicle
PUT  /api/mvjcb/editDelete     - Update/delete JCB vehicle

GET  /api/mvrollert/list       - List roller vehicle details
POST /api/mvrollert/add        - Add roller vehicle
PUT  /api/mvrollert/editDelete - Update/delete roller vehicle
```

---

## 🔄 Application Flow & Data Processing

### **1. Request Flow**
```
Client Request → Route Handler → Service Layer → Library Functions → Database → Response
```

### **2. Authentication Flow**
```
1. User submits login credentials
2. Route handler receives request
3. Service validates input
4. Query user_master table
5. Compare password with bcrypt
6. Generate JWT token on success
7. Return token and user info
```

### **3. CRUD Operations Flow**
```
1. Client sends request with data
2. Route validates authentication (commented out in current code)
3. Service processes business logic
4. Generate document numbers if needed
5. Build SQL queries using query builders
6. Execute database operations
7. Return success/error response
```

### **4. File Upload Flow**
```
1. Client uploads file
2. Multer processes file upload
3. File saved to uploads/ directory
4. File path stored in database
5. Success response with file path
```

---

## 📊 Database Schema Overview

### **Core Tables**
- `user_master` - User authentication and roles
- `employee_master` - Employee information
- `department_master` - Department management
- `party_master` - Party/vendor information
- `material_master` - Material catalog
- `machinery_master` - Equipment catalog
- `unit_master` - Measurement units

### **Transaction Tables**
- `attendance_entry` - Employee attendance records
- `material_entry` - Material procurement records
- `payment_entry` - Payment transactions
- `bill_details` - Billing information
- `daily_expenses` - Daily operational expenses
- `salary_entry` - Salary payments
- `credit_entry` - Credit transactions

### **Specialized Tables**
- `tender` - Tender management
- `work_order` - Work order management
- `mvtipper_details` - Tipper vehicle records
- `mvjcb_details` - JCB vehicle records
- `mvrtt_details` - Roller vehicle records

---

## 🔐 Security Features

### **Authentication**
- **JWT Token-based** authentication
- **Password Hashing** with bcryptjs (10 rounds)
- **Token Expiration** (24 hours default)
- **Secure Private Keys** via environment variables

### **Input Validation**
- **SQL Injection Prevention** through parameterized queries
- **Input Sanitization** in service layers
- **Required Field Validation** before database operations

### **File Upload Security**
- **File Type Validation** (configurable)
- **File Size Limits** (configurable via body-parser)
- **Secure File Storage** in designated directories

---

## 📈 Business Logic Implementation

### **Document Number Generation**
- **Auto-incrementing** numbers with prefixes
- **Table-specific** numbering (MAT001, INV001, etc.)
- **Thread-safe** generation using database queries

### **Search & Filtering**
- **Multi-column** search across relevant fields
- **Pagination** support for large datasets
- **Soft Delete** implementation (is_deleted flag)

### **Queue Management**
- **Sequential Processing** for critical operations
- **Timeout Handling** (5-second timeout)
- **Error Recovery** mechanisms

---

## 🚀 Getting Started

### **Prerequisites**
- Node.js (v14 or higher)
- MySQL Server (v5.7 or higher)
- npm or yarn package manager

### **Installation**
```bash
# Clone the repository
git clone <repository-url>
cd backend

# Install dependencies
npm install

# Configure environment variables
cp .env.example .env
# Edit .env with your database credentials

# Configure database
# Create database 'onepr4co_mvc'
# Import schema and initial data

# Start the server
npm start
```

### **Environment Variables**
```env
PORT=5000
PKEY=your-jwt-secret-key
TOKEN_EXPIRE_IN=24
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your-password
DB_NAME=onepr4co_mvc
```

### **API Testing**
```bash
# Login
curl -X POST http://localhost:5000/api/login/login \
  -H "Content-Type: application/json" \
  -d '{"userName":"Admin","loginPassword":"123456"}'

# Get employee list
curl -X GET http://localhost:5000/api/employee/list \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

---

## 🔧 Development & Maintenance

### **Adding New Modules**
1. Create route file in `routes/` directory
2. Create service file in `services/` directory
3. Register routes in `index.js`
4. Update database schema if needed
5. Add API documentation

### **Database Migrations**
- Use the query builder functions for consistent SQL generation
- Implement soft deletes using `is_deleted` flag
- Add proper indexes for frequently queried columns

### **Error Handling**
- Centralized error handling in `error.handler.js`
- Proper HTTP status codes for different error types
- Detailed error logging for debugging

### **Performance Optimization**
- Connection pooling for database operations
- Queue management for sequential processing
- File upload optimization with size limits
- Proper indexing on database tables

---

## 📝 API Response Format

### **Success Response**
```json
{
  "result": { /* data object */ },
  "message": "Operation successful"
}
```

### **Error Response**
```json
{
  "result": null,
  "message": "Error description"
}
```

### **Authentication Error**
```json
{
  "message": "Sign in to continue."
}
```

---

## 🐛 Troubleshooting

### **Common Issues**

1. **Database Connection Failed**
   - Check MySQL server status
   - Verify credentials in `sqlConfig.json`
   - Ensure database exists

2. **Login Not Working**
   - Verify password hash in database
   - Check JWT token generation
   - Ensure bcrypt compare function works

3. **File Upload Issues**
   - Check `uploads/` directory permissions
   - Verify multer configuration
   - Check file size limits

4. **CORS Errors**
   - Verify CORS configuration in `index.js`
   - Check frontend origin settings

---

## 📚 Additional Notes

- **Code Comments:** Most business logic includes detailed comments
- **Modular Design:** Easy to extend and maintain
- **Scalable Architecture:** Supports multiple database types
- **Production Ready:** Includes error handling and logging
- **Documentation:** Comprehensive inline code documentation

---

## 👥 Support & Maintenance

For questions or issues:
1. Check the error logs in console
2. Verify database connectivity
3. Review API request/response formats
4. Check file permissions for uploads

**Last Updated:** January 15, 2026  
**Version:** 1.0.0</content>
<parameter name="filePath">c:\Users\user\Gosh Sir\MVC Project 2026_01_07 2\backend\PROJECT_DOCUMENTATION.md