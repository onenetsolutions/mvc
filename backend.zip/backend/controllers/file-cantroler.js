
const sql = require('mssql');
const dbConfig = require('../libs/dbConnection'); 

exports.uploadFile = async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ msg: 'No file uploaded' });
  }

  const filePath = req.file.path; 

  try {
   
    const pool = await sql.connect(dbConfig);

    // Insert the file path into SQL Server
    const query = 'INSERT INTO Uploads (file_path) VALUES (@filePath)';
    await pool.request()
      .input('filePath', sql.VarChar, filePath)
      .query(query);

    res.status(200).json({ msg: 'File uploaded successfully', filePath });
  } catch (error) {
    console.error('Error uploading file:', error);
    res.status(500).json({ msg: 'Database error', error });
  }
};
