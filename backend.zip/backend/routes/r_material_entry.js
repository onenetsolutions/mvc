const express = require('express');
const router = express.Router();
const service = require('../services/s_material_entry');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all material_entry records
router.get('/list', authenticate, (req, res, next) => {
    service.materialEntryList(req, res, next);
});

// Route for getting next entry number
router.get('/nextEntryNo', authenticate, (req, res, next) => {
    service.getNextEntryNo(req, res, next);
});

// Route for adding a new material_entry record
router.post('/add', authenticate, (req, res, next) => {
    service.insertMaterialEntry(req, res, next);
});

// Route for editing or deleting a material_entry record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteMaterialEntry(req, res, next);
});

module.exports = router;

