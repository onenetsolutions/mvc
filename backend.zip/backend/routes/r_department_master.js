const express = require('express');
const router = express.Router();
const service = require('../services/s_department_master');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all department_master records
router.get('/list', authenticate, (req, res, next) => {
    service.departmentMasterList(req, res, next);
});

// Route for adding a new department_master record
router.post('/add', authenticate, (req, res, next) => {
    service.insertdepartmentMaster(req, res, next);
});

// Route for editing or deleting a department_master record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeletedepartmentMaster(req, res, next);
});

module.exports = router;

