const express = require('express')
const router = express.Router()
const service = require('../services/s_login')
const lib = require('../libs/index')



router.post('/login', (req, res, next) => {
    service.login(req, res, next)
})

router.post('/logout', (req, res, next) => {
    service.logout(req, res, next)
})


module.exports = router