const express = require('express');
const router = express.Router();
const service = require('../services/s_workhead_master');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all workhead_master records
router.get('/list', authenticate, (req, res, next) => {
    service.workheadMasterList(req, res, next);
});

// Route for adding a new workhead_master record
router.post('/add', authenticate, (req, res, next) => {
    service.insertworkheadMaster(req, res, next);
});

// Route for editing or deleting a workhead_master record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteworkheadMaster(req, res, next);
});

module.exports = router;
