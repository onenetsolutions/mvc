const express = require('express');
const router = express.Router();
const service = require('../services/s_mvtipper_details');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

router.get('/list', authenticate, (req, res, next) => {
    service.getmvtipperList(req, res, next);
});

router.post('/add', authenticate, (req, res, next) => {
    service.insertMvTipper(req, res, next);
});

router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteMVtipperEntry(req, res, next);
});

module.exports = router;

