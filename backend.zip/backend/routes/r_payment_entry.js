const express = require('express');
const router = express.Router();
const service = require('../services/s_payment_entry');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all payment_entry records
router.get('/list', authenticate, (req, res, next) => {
    service.paymentEntryList(req, res, next);
});

// Route for adding a new payment_entry record
router.post('/add', authenticate, (req, res, next) => {
    service.insertPaymentEntry(req, res, next);
});

// Route for editing or deleting a payment_entry record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeletePaymentEntry(req, res, next);
});

module.exports = router;

