const express = require('express');
const router = express.Router();
const service = require('../services/s_mvjcb_details');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

router.get('/list', authenticate, (req, res, next) => {
    service.getmvjcbList(req, res, next);
});

router.post('/add', authenticate, (req, res, next) => {
    service.insertMvJCB(req, res, next);
});

router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteMVjcbEntry(req, res, next);
});

module.exports = router;

