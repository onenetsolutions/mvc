const express = require('express');
const router = express.Router();
const service = require('../services/s_machinery_master');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all machinery_master records
router.get('/list', authenticate, (req, res, next) => {
    service.machineryMasterList(req, res, next);
});

// Route for adding a new machinery_master record
router.post('/add', authenticate, (req, res, next) => {
    service.insertMachineryMaster(req, res, next);
});

// Route for editing or deleting a machinery_master record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteMachineryMaster(req, res, next);
});

module.exports = router;

