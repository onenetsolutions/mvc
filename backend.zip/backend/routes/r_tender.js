const express = require('express');
const router = express.Router();
const service = require('../services/s_tender');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all tender records
router.get('/list', authenticate, (req, res, next) => {
    service.TenderList(req, res, next);
});

// Route for adding a new tender record
router.post('/add', authenticate, (req, res, next) => {
    service.insertTender(req, res, next);
});

// Route for editing or deleting a tender record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteTender(req, res, next);
});

module.exports = router;

