const express = require('express');
const router = express.Router();
const dashboardService = require('../services/s_dashboard');
const authenticate = require('../middleware/authMiddleware');

router.get('/', authenticate, async (req, res) => {
  await dashboardService.getDashboardData(req, res);
});

module.exports = router;
