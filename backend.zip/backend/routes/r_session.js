const express = require('express');
const router = express.Router();
const service = require('../services/s_session');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Apply authentication middleware to all routes
router.get('/list', authenticate, (req, res, next) => {
    service.sessionlist(req, res, next);
});

module.exports = router;