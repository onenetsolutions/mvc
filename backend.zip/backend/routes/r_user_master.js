const express = require('express');
const router = express.Router();
const service = require('../services/s_user_master');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all user_master records
router.get('/list', authenticate, (req, res, next) => {
    service.UserMasterList(req, res, next);
});

// Route for adding a new user_master record
router.post('/add', authenticate, (req, res, next) => {
    service.insertUserMaster(req, res, next);
});

// Route for editing or deleting a user_master record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteUserMaster(req, res, next);
});

module.exports = router;

