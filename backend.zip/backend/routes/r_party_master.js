const express = require('express');
const router = express.Router();
const service = require('../services/s_party_master');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all party_master records
router.get('/list', authenticate, (req, res, next) => {
    service.partyMasterList(req, res, next);
});

// Route for adding a new party_master record
router.post('/add', authenticate, (req, res, next) => {
    service.insertpartyMaster(req, res, next);
});

// Route for editing or deleting a party_master record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeletepartyMaster(req, res, next);
});

module.exports = router;

