const express = require('express');
const router = express.Router();
const service = require('../services/s_bill_adjustment');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all bill_adjustment records
router.get('/list', authenticate, (req, res, next) => {
    service.billAdjustmentList(req, res, next);
});

// Route for adding a new bill_adjustment record
router.post('/add', authenticate, (req, res, next) => {
    service.insertBillAdjustment(req, res, next);
});

// Route for editing or deleting a bill_adjustment record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteBillAdjustment(req, res, next);
});

module.exports = router;

