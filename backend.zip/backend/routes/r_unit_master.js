const express = require('express');
const router = express.Router();
const service = require('../services/s_unit_master');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all unit_master records
router.get('/list', authenticate, (req, res, next) => {
    service.unitMasterList(req, res, next);
});

// Route for adding a new unit_master record
router.post('/add', authenticate, (req, res, next) => {
    service.insertunitMaster(req, res, next);
});

// Route for editing or deleting a unit_master record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteunitMaster(req, res, next);
});

module.exports = router;

