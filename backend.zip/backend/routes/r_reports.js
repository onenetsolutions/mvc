const express = require('express');
const router = express.Router();
const reportService = require('../services/s_report');
const siteWiseReportService = require('../services/s_report_site_wise');
const supplierReportService = require('../services/s_report_supplier');
const contractorReportService = require('../services/s_report_contractor');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Get View Data (JSON for Table)
router.post('/view/:type', authenticate, async (req, res) => {
    try {
        const { type } = req.params;
        const { filters = {}, columns = [] } = req.body || {};
        const result = await reportService.getReportData(type, filters, columns);
        res.status(200).json({ status: true, data: result });
    } catch (e) {
        res.status(500).json({ status: false, message: e.message });
    }
});

// Download Excel
router.post('/download/:type', authenticate, async (req, res) => {
    try {
        const { type } = req.params;
        const { filters = {}, columns = [] } = req.body || {};
        const result = await reportService.getReportData(type, filters, columns);
        await reportService.generateExcel(type, result, res, columns, filters);
    } catch (e) {
        res.status(500).send("Error generating excel");
    }
});

// Download PDF
router.post('/pdf/:type', authenticate, async (req, res) => {
    try {
        const { type } = req.params;
        const { filters = {}, columns = [] } = req.body || {};
        const result = await reportService.getReportData(type, filters, columns);
        await reportService.generatePDF(type, result, res, columns, filters);
    } catch (e) {
        res.status(500).send("Error generating PDF");
    }
});

// ============= SITE WISE REPORT =============
// Get site codes for dropdown
router.get('/site-wise/site-codes', authenticate, async (req, res) => {
    try {
        const result = await siteWiseReportService.getSiteCodes();
        res.status(200).json(result);
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Get site wise report data
router.get('/site-wise/:siteCode', authenticate, async (req, res) => {
    try {
        const { siteCode } = req.params;
        const result = await siteWiseReportService.getSiteWiseReport(siteCode);
        res.status(200).json(result);
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Download PDF for Site Wise Report
router.get('/site-wise/pdf/:siteCode', authenticate, async (req, res) => {
    try {
        const { siteCode } = req.params;
        const result = await siteWiseReportService.getSiteWiseReport(siteCode);
        if (result.success) {
            await siteWiseReportService.generateSiteWiseReportPDF(siteCode, result.data, res);
        } else {
            res.status(400).send("No data found for the selected site.");
        }
    } catch (e) {
        res.status(500).send("Error generating PDF");
    }
});

// ============= SUPPLIER REPORT =============
// Get suppliers list for dropdown
router.get('/supplier/list', authenticate, async (req, res) => {
    try {
        const result = await supplierReportService.getSuppliers();
        res.status(200).json(result);
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Get site codes for supplier report
router.get('/supplier/site-codes', authenticate, async (req, res) => {
    try {
        const result = await supplierReportService.getSiteCodes();
        res.status(200).json(result);
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Get supplier report data (with optional site filter)
router.get('/supplier/:supplierId', authenticate, async (req, res) => {
    try {
        const { supplierId } = req.params;
        const { siteCode } = req.query;
        const result = await supplierReportService.getSupplierReport(supplierId, siteCode);
        res.status(200).json(result);
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Download PDF for Supplier Report
router.get('/supplier/pdf/:supplierId', authenticate, async (req, res) => {
    try {
        const { supplierId } = req.params;
        const { siteCode } = req.query;
        const result = await supplierReportService.getSupplierReport(supplierId, siteCode);
        if (result.success) {
            await supplierReportService.generateSupplierReportPDF(supplierId, siteCode, result.data, res);
        } else {
            res.status(400).send("No data found for the selected supplier.");
        }
    } catch (e) {
        res.status(500).send("Error generating PDF");
    }
});

// ============= CONTRACTOR REPORT =============
// Get contractors list for dropdown
router.get('/contractor/list', authenticate, async (req, res) => {
    try {
        const result = await contractorReportService.getContractors();
        res.status(200).json(result);
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Get site codes for contractor report
router.get('/contractor/site-codes', authenticate, async (req, res) => {
    try {
        const result = await contractorReportService.getSiteCodes();
        res.status(200).json(result);
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Get contractor report data (siteCode optional query param)
router.get('/contractor/report', authenticate, async (req, res) => {
    try {
        const { siteCode, contractorId } = req.query;
        const result = await contractorReportService.getContractorReport(siteCode || null, contractorId);
        res.status(200).json(result);
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Download PDF for Contractor Report
router.get('/contractor/pdf', authenticate, async (req, res) => {
    try {
        const { siteCode, contractorId } = req.query;
        const result = await contractorReportService.getContractorReport(siteCode || null, contractorId);
        if (result.success) {
            await contractorReportService.generateContractorReportPDF(siteCode, contractorId, result.data, res);
        } else {
            res.status(400).send("No data found for the selected contractor.");
        }
    } catch (e) {
        res.status(500).send("Error generating PDF");
    }
});

// ============= LABOUR CONTRACTOR REPORT =============
// Get labour contractors list for dropdown
router.get('/labour-contractor/list', authenticate, async (req, res) => {
    try {
        const result = await contractorReportService.getLabourContractors();
        res.status(200).json(result);
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Get labour contractor report data (requires site code, supports manual entry)
router.post('/labour-contractor/report/:siteCode', authenticate, async (req, res) => {
    try {
        const { siteCode } = req.params;
        const { labourContractorId, manualEntry } = req.body;
        const result = await contractorReportService.getLabourContractorReport(
            siteCode,
            labourContractorId,
            manualEntry
        );
        res.status(200).json(result);
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// Download PDF for Labour Contractor Report
router.post('/labour-contractor/pdf/:siteCode', authenticate, async (req, res) => {
    try {
        const { siteCode } = req.params;
        const { labourContractorId, manualEntry } = req.body;
        const result = await contractorReportService.getLabourContractorReport(
            siteCode,
            labourContractorId,
            manualEntry
        );
        if (result.success) {
            await contractorReportService.generateLabourContractorReportPDF(siteCode, result.data, res);
        } else {
            res.status(400).send("No data found for the selected labour contractor.");
        }
    } catch (e) {
        res.status(500).send("Error generating PDF");
    }
});

module.exports = router;
