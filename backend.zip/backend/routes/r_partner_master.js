const express = require('express');
const router = express.Router();
const service = require('../services/s_partner_master');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all partner_master records
router.get('/list', authenticate, (req, res, next) => {
    service.partnerMasterList(req, res, next);
});

// Route for adding a new partner_master record
router.post('/add', authenticate, (req, res, next) => {
    service.insertpartnerMaster(req, res, next);
});

// Route for editing or deleting a partner_master record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeletepartnerMaster(req, res, next);
});

module.exports = router;

