const express = require('express');
const router = express.Router();
const service = require('../services/s_bill_details');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all bill_details records
router.get('/list', authenticate, (req, res, next) => {
    service.billDetailsList(req, res, next);
});

// Route for adding a new bill_details record
router.post('/add', authenticate, (req, res, next) => {
    service.insertBillDetails(req, res, next);
});

// Route for editing or deleting a bill_details record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteBillDetails(req, res, next);
});

module.exports = router;

