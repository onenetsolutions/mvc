const express = require('express');
const router = express.Router();
const service = require('../services/s_project');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all project records
router.get('/list', authenticate, (req, res, next) => {
    service.ProjectList(req, res, next);
});

// Route for adding a new project record
router.post('/add', authenticate, (req, res, next) => {
    service.insertProject(req, res, next);
});

// Route for editing or deleting a project record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteProject(req, res, next);
});

module.exports = router;