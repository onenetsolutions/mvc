const express = require('express');
const router = express.Router();
const service = require('../services/s_daily_expenses');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all daily_expenses records
router.get('/list', authenticate, (req, res, next) => {
    service.dailyExpensesList(req, res, next);
});

// Route for adding a new daily_expenses record
router.post('/add', authenticate, (req, res, next) => {
    service.insertDailyExpenses(req, res, next);
});

// Route for getting next daily expense entry number
router.get('/nextEntryNo', authenticate, (req, res, next) => {
    service.getNextEntryNo(req, res, next);
});

// Route for editing or deleting a daily_expenses record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteDailyExpenses(req, res, next);
});

// Route for fetching party ledger
router.get('/partyLedger', authenticate, (req, res, next) => {
    service.getPartyLedger(req, res, next);
});

module.exports = router;

