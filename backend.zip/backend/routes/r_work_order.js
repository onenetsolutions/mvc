const express = require('express');
const router = express.Router();
const service = require('../services/s_work_order');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all work_order records
router.get('/list', authenticate, (req, res, next) => {
    service.workOrderList(req, res, next);
});

// Route for fetching next auto-generated work order site code
router.get('/nextSiteCode', authenticate, (req, res, next) => {
    service.getNextSiteCode(req, res, next);
});

// Route for adding a new work_order record
router.post('/add', authenticate, (req, res, next) => {
    service.insertWorkOrder(req, res, next);
});

// Route for editing or deleting a work_order record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteWorkOrder(req, res, next);
});

module.exports = router;

