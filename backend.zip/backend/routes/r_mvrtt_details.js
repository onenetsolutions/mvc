const express = require('express');
const router = express.Router();
const service = require('../services/s_mvrollertt_details');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

router.get('/list', authenticate, (req, res, next) => {
    service.getmvrttList(req, res, next);
});

router.post('/add', authenticate, (req, res, next) => {
    service.insertMvRTT(req, res, next);
});

router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteMVRTEntry(req, res, next);
});

module.exports = router;

