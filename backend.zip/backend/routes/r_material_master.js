const express = require('express');
const router = express.Router();
const service = require('../services/s_material_master');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all material_master records
router.get('/list', authenticate, (req, res, next) => {
    service.MaterialMasterList(req, res, next);
});

// Route for adding a new material_master record
router.post('/add', authenticate, (req, res, next) => {
    service.insertMaterialMaster(req, res, next);
});

// Route for editing or deleting a material_master record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteMaterialMaster(req, res, next);
});

module.exports = router;

