const express = require('express');
const router = express.Router();
const service = require('../services/s_salary_entry');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all salary_entry records
router.get('/list', authenticate, (req, res, next) => {
    service.salaryEntryList(req, res, next);
});

// Route for adding a new salary_entry record
router.post('/add', authenticate, (req, res, next) => {
    service.insertSalaryEntry(req, res, next);
});

// Route for editing or deleting a salary_entry record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteSalaryEntry(req, res, next);
});

router.get('/count', authenticate, (req, res, next) => {
    service.getAttendanceCount(req, res, next);
});

module.exports = router;

