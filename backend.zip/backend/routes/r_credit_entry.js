const express = require('express');
const router = express.Router();
const service = require('../services/s_credit_entry');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all credit_entry records
router.get('/list', authenticate, (req, res, next) => {
    service.CreditEntryList(req, res, next);
});

// Route for adding a new credit_entry record
router.post('/add', authenticate, (req, res, next) => {
    service.insertCreditEntry(req, res, next);
});

// Route for editing or deleting a credit_entry record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteCreditEntry(req, res, next);
});

router.get('/stocktable', authenticate, (req, res, next) => {
    service.Stocktabalecount(req, res, next);
});

// Route for fetching party ledger
router.get('/partyLedger', authenticate, (req, res, next) => {
    service.getPartyLedger(req, res, next);
});

// Route for fetching office cash balance
router.get('/officeCashBalance', authenticate, (req, res, next) => {
    service.officeCashBalance(req, res, next);
});

module.exports = router;

