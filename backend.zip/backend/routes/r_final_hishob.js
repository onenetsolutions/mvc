const express = require('express');
const router = express.Router();
const authenticate = require('../middleware/authMiddleware');
const finalHishobService = require('../services/s_final_hishob');

// Route to get all site codes for dropdown
router.get('/site-codes', authenticate, async (req, res) => {
  try {
    const result = await finalHishobService.getSiteCodes();
    res.status(200).json(result);
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// Route to get complete final hishob data for a specific site
router.get('/:siteCode', authenticate, async (req, res) => {
  try {
    const { siteCode } = req.params;
    const result = await finalHishobService.getFinalHishob(siteCode);
    res.status(200).json(result);
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// Route to download final hishob PDF
router.post('/pdf/:siteCode', authenticate, async (req, res) => {
  try {
    const { siteCode } = req.params;
    const result = await finalHishobService.getFinalHishob(siteCode);
    if (!result.success) {
      return res.status(500).json(result);
    }
    await finalHishobService.generateFinalHishobPDF(siteCode, result.data, res);
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// Route to save/update final hishob and handle site closure
router.post('/:siteCode', authenticate, async (req, res) => {
  try {
    const { siteCode } = req.params;
    const result = await finalHishobService.saveFinalHishob(siteCode, req.body);
    res.status(200).json(result);
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// Route to get expense summary by partner (for reports)
router.get('/:siteCode/expenses/by-partner', authenticate, async (req, res) => {
  try {
    const { siteCode } = req.params;
    const result = await finalHishobService.getExpensesByPartner(siteCode);
    res.status(200).json(result);
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// Route to get receivable summary (for ledger posting)
router.get('/:siteCode/receivables', authenticate, async (req, res) => {
  try {
    const { siteCode } = req.params;
    const result = await finalHishobService.getPartnerReceivables(siteCode);
    res.status(200).json(result);
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

module.exports = router;
