const express = require('express');
const router = express.Router();
const service = require('../services/s_employee_master');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all employee_master records
router.get('/list', authenticate, (req, res, next) => {
    service.EmployeeMasterList(req, res, next);
});

// Route for adding a new employee_master record
router.post('/add', authenticate, (req, res, next) => {
    service.insertEmployeeMaster(req, res, next);
});

// Route for editing or deleting an employee_master record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteEmployeeMaster(req, res, next);
});

module.exports = router;

