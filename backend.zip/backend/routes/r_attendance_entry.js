const express = require('express');
const router = express.Router();
const service = require('../services/s_attendance_entry');
const authenticate = require('../middleware/authMiddleware'); // Import authentication middleware

// Route for listing all attendance_entry records
router.get('/list', authenticate, (req, res, next) => {
    service.AttendanceEntryList(req, res, next);
});

// Route for adding a new attendance_entry record
router.post('/add', authenticate, (req, res, next) => {
    service.insertAttendanceEntry(req, res, next);
});

// Route for editing or deleting an attendance_entry record
router.put('/editDelete', authenticate, (req, res, next) => {
    service.updateDeleteAttendanceEntry(req, res, next);
});

module.exports = router;

