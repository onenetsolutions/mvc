// Dependencies NODE_Module
const express = require('express'),
    app = express(),
    bodyParser = require('body-parser'),
    cors = require('cors'),
    dotenv = require('dotenv').config(),
    path = require('path'),
    cookieParser = require('cookie-parser');

const fileUpload = require('express-fileupload');

let lib = require("./libs/index")
let loginCheck = require("./services/s_login")



let port = process.env.PORT || 5000


app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(cors({
    exposedHeaders: ['X-Total-Count', 'X-Last-Entry-No']
}))
app.use('/fileAttachment', express.static('fileAttachment'));
app.use(express.json());
app.use(bodyParser.json({ limit: '80mb' }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, './web/build')));
app.use(/^(?!\/)/i, (req, res) => res.sendFile(path.join(__dirname, "./web/build", 'index.html')))
app.use(cookieParser());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ........router......//

const login = require('./routes/r_login')
const session = require('./routes/r_session.js')
const unit = require('./routes/r_unit_master')
const partner = require('./routes/r_partner_master')
const workhead = require('./routes/r_workhead_master')
const department = require('./routes/r_department_master')
const party = require('./routes/r_party_master')
const tender = require('./routes/r_tender')
const work_order = require('./routes/r_work_order')
const bill_details = require('./routes/r_bill_details')
const daily_expenses = require('./routes/r_daily_expenses')
const material_entry = require('./routes/r_material_entry')
const payment_entry = require('./routes/r_payment_entry')
const bill_adjustment = require('./routes/r_bill_adjustment')
const material = require('./routes/r_material_master.js')
const machinery = require('./routes/r_machinery_master.js')
const employee = require('./routes/r_employee_master.js')
const attendance_entry = require('./routes/r_attendance_entry.js')
const salary_entry = require('./routes/r_salary_entry')
const credit_entry = require('./routes/r_credit_entry.js')
const user = require('./routes/r_user_master')
const mvtipper = require('./routes/r_mvtipper_details.js')
const mvjcb = require('./routes/r_mvjcb_details.js')
const mvrollert = require('./routes/r_mvrtt_details.js')
const project = require('./routes/r_project')
const reports = require('./routes/r_reports')
const finalHishob = require('./routes/r_final_hishob')
const dashboard = require('./routes/r_dashboard')


// ..........API...........//

app.use('/api/login', login)
app.use('/api/session', session)


app.use('/api/unit', unit)
app.use('/api/partner', partner)
app.use('/api/workhead', workhead)
app.use('/api/user', user)
app.use('/api/department', department)
app.use('/api/party', party)
app.use('/api/tender', tender)
app.use('/api/workOrder', work_order)
app.use('/api/billDetails', bill_details)
app.use('/api/dailyExpenses', daily_expenses)
app.use('/api/materialEntry', material_entry)
app.use('/api/paymentEntry', payment_entry)
app.use('/api/billAdjustment', bill_adjustment)
app.use('/api/material',material)
app.use('/api/machinery',machinery)
app.use('/api/employee',employee)
app.use('/api/attendance',attendance_entry)
app.use('/api/salary',salary_entry)
app.use('/api/credit',credit_entry)
app.use('/api/mvtipper',mvtipper)
app.use('/api/mvjcb',mvjcb)
app.use('/api/mvrollert',mvrollert)
app.use('/api/project', project)
app.use('/api/reports', reports)
app.use('/api/finalHishob', finalHishob)
app.use('/api/dashboard', dashboard)





app.get('/', (req, res) => {
    res.send("hello");
});

app.listen(port, () => {
    console.log(`SERVER ${port} is running.....`)
})

module.exports = app;