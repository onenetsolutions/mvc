const lib = require('../libs/index');
let service = {};
const bcrypt = require('bcryptjs');


// Insert into cylinder_master

service.insertUserMaster = async (req, res, next) => {
    try {
        const user_name = req.body.user_name || '';
        const password = req.body.password || '';
        const mobile_no = req.body.mobile_no || '';
        // const user_type = req.body.user_type || '';
       
        // const location = req.body.location || '';
        // const department = req.body.department || '';
        
        // const imei_no = req.body.imei_no || '';
        // const unit_name = req.body.unit_name || '';


        // Hash the password before saving it
        const hashedPassword = await bcrypt.hash(password, 10); // 10 is the salt rounds

        // Constructing the SQL query string for inserting driver data
        const queryStr = `INSERT INTO user_master 
          (user_name, mobile_no,password ) 
          VALUES 
          ('${user_name}','${mobile_no}','${hashedPassword}')`;

        // Execute the query
        await lib.queryExecute(queryStr);

        // Sending a success response
        res.status(200).send({ result: req.body, message: 'Added Successfully!' });
    } catch (error) {
        // Handling any errors
        res.status(500).send(error);
    }
};


// List all cylinder_master entries
service.UserMasterList = async (req, res, next) => {
    try {
        let pageSet = '';
        const searchKey = req.query.searchKey || '';
        let searchCondition = 'is_deleted = 0';

        const allColumns = ['user_name', 'user_id'];

        if (searchKey) {
            const searchConditions = allColumns
                .map(col => `${col} LIKE '%${searchKey}%'`) // Fixed template literal syntax
                .join(' OR ');

            // Ensure that the condition is valid
            searchCondition += ` AND (${searchConditions})`;
        }

        const page = parseInt(req.query.page, 10) || 0; // Added radix parameter
        const size = parseInt(req.query.size, 10) || 10; // Added radix parameter

        if (size > 0) {
            pageSet = `LIMIT ${size} OFFSET ${page * size}`; // Corrected the pageSet syntax
        }

        let queryStr = `SELECT * 
                      FROM user_master
                      WHERE ${searchCondition} 
                      ORDER BY user_id ASC 
                      ${pageSet}`;

        const countQuery = `SELECT COUNT(*) AS totalCount 
                          FROM user_master
                          WHERE is_deleted = 0`;

        const totalCountResult = await lib.queryExecute(countQuery);
        const totalCount = totalCountResult[0].totalCount;

        const result = await lib.queryExecute(queryStr);

        // Include total count in the response
        const response = result.map(item => ({
            ...item,
            totalCount
        }));

        res.status(200).send(response);

    } catch (error) {
        console.error('Error in user_master_List:', error);
        res.status(500).send({ message: error.message });
    }
};



service.updateDeleteUserMaster = (req, res, next) => {
    try {
        req.query.search = req.query.search || `user_id eq ${req.body.user_id}`;

        let body = req.body;

        // If password is being updated, hash it
        if (body.password) {
            bcrypt.hash(body.password, 10, (err, hashedPassword) => {
                if (err) {
                    return res.status(500).send({ message: 'Error hashing the password' });
                }

                // Replace password with hashed password
                body.password = hashedPassword;

                // Proceed with updating the user data
                proceedWithUpdate(body, req, res);
            });
        } else {
            // Proceed with the update without changing the password
            proceedWithUpdate(body, req, res);
        }

    } catch (error) {
        res.status(500).send({ message: error.message });
    }
};

// Helper function to handle the update logic
function proceedWithUpdate(body, req, res) {
    if (body.changedUpdatedValue !== 'edit') {
        body.is_deleted = 1;
    }

    if (body.hasOwnProperty('modifiedAt')) {
        delete body.modifiedAt;
    }
    if (body.hasOwnProperty('modifiedBy')) {
        delete body.modifiedBy;
    }
    delete body.changedUpdatedValue;
    delete body.user_id;

    let queryParam = lib.whereClause(
        req.query.search.replace(new RegExp('%20', 'gi'), (v) => ' ')
    );
    let queryStr = lib.updateQuery(body, 'user_master', queryParam);
    lib.queryExecute(queryStr)
        .then((result) => {
            if (body.is_deleted === 1) {
                res.status(200).send({ message: 'Deleted Successfully!' });
            } else {
                res.status(200).send({ result: body, message: 'Updated Successfully!' });
            }
        })
        .catch((e) => res.status(400).send({ message: e.message }));
}

module.exports = service;


