const { queryExecute } = require('../libs/dbRequest');

const getDashboardData = async (req, res) => {
  try {
    // 1. Financial Overview
    const financialQuery = `
      SELECT 
        (SELECT IFNULL(SUM(CAST(net_bill_amount AS DECIMAL(15,2))), 0) 
         FROM bill_details WHERE is_deleted = 0) as total_bills_received,
        
        (SELECT IFNULL(SUM(CAST(amount AS DECIMAL(15,2))), 0) 
         FROM daily_expenses WHERE is_deleted = 0) as total_expenses,
        
        (SELECT IFNULL(SUM(CAST(amount AS DECIMAL(15,2))), 0) 
         FROM material_entry WHERE is_deleted = 0) as total_material_cost,
        
        (SELECT IFNULL(SUM(CAST(grand_total AS DECIMAL(15,2))), 0) 
         FROM mvjcb_detials WHERE is_deleted = 0) as total_jcb_cost,
        
        (SELECT IFNULL(SUM(CAST(total_amount AS DECIMAL(15,2))), 0) 
         FROM mv_rollertt_details WHERE is_deleted = 0) as total_roller_cost,
        
        (SELECT IFNULL(SUM(CAST(total_amount AS DECIMAL(15,2))), 0) 
         FROM mvtipper_details WHERE is_deleted = 0) as total_tipper_cost,
        
        (SELECT IFNULL(SUM(CAST(salary_paid AS DECIMAL(15,2))), 0) 
         FROM salary_entry WHERE is_deleted = 0) as total_salaries_paid,
        
        (SELECT IFNULL(SUM(CAST(work_order_amount AS DECIMAL(15,2))), 0) 
         FROM work_order WHERE is_deleted = 0) as total_work_order_amount
    `;
    
    const financial = await queryExecute(financialQuery);
    const totalBillsReceived = parseFloat(financial[0].total_bills_received) || 0;
    const totalExpenses = parseFloat(financial[0].total_expenses) || 0;
    const totalMaterialCost = parseFloat(financial[0].total_material_cost) || 0;
    const totalJcbCost = parseFloat(financial[0].total_jcb_cost) || 0;
    const totalRollerCost = parseFloat(financial[0].total_roller_cost) || 0;
    const totalTipperCost = parseFloat(financial[0].total_tipper_cost) || 0;
    const totalSalariesPaid = parseFloat(financial[0].total_salaries_paid) || 0;
    const totalWorkOrderAmount = parseFloat(financial[0].total_work_order_amount) || 0;
    
    const totalAllExpenses = totalExpenses + totalMaterialCost + totalJcbCost + 
                            totalRollerCost + totalTipperCost + totalSalariesPaid;
    const netProfit = totalBillsReceived - totalAllExpenses;

    // 2. Site Profit Summary
    const siteProfitQuery = `
      SELECT 
        wo.site_code,
        wo.site_name,
        wo.work_name,
        IFNULL(SUM(CAST(bd.net_bill_amount AS DECIMAL(15,2))), 0) as total_bills,
        (
          SELECT IFNULL(SUM(CAST(amount AS DECIMAL(15,2))), 0)
          FROM daily_expenses 
          WHERE site_code = wo.site_code AND is_deleted = 0
        ) as site_expenses,
        (
          SELECT IFNULL(SUM(CAST(amount AS DECIMAL(15,2))), 0)
          FROM material_entry 
          WHERE site_code = wo.site_code AND is_deleted = 0
        ) as material_cost,
        (
          SELECT IFNULL(SUM(CAST(grand_total AS DECIMAL(15,2))), 0)
          FROM mvjcb_detials 
          WHERE site_code = wo.site_code AND is_deleted = 0
        ) as jcb_cost,
        (
          SELECT IFNULL(SUM(CAST(total_amount AS DECIMAL(15,2))), 0)
          FROM mv_rollertt_details 
          WHERE site_code = wo.site_code AND is_deleted = 0
        ) as roller_cost,
        (
          SELECT IFNULL(SUM(CAST(total_amount AS DECIMAL(15,2))), 0)
          FROM mvtipper_details 
          WHERE site_code = wo.site_code AND is_deleted = 0
        ) as tipper_cost
      FROM work_order wo
      LEFT JOIN bill_details bd ON wo.site_code = bd.site_code AND bd.is_deleted = 0
      WHERE wo.is_deleted = 0 AND wo.site_code IS NOT NULL AND wo.site_code != ''
      GROUP BY wo.site_code, wo.site_name, wo.work_name
    `;
    
    const siteProfitData = await queryExecute(siteProfitQuery);
    const siteProfitSummary = siteProfitData.map(site => {
      const totalBills = parseFloat(site.total_bills) || 0;
      const siteExpenses = parseFloat(site.site_expenses) || 0;
      const materialCost = parseFloat(site.material_cost) || 0;
      const jcbCost = parseFloat(site.jcb_cost) || 0;
      const rollerCost = parseFloat(site.roller_cost) || 0;
      const tipperCost = parseFloat(site.tipper_cost) || 0;
      
      const totalSiteExpenses = siteExpenses + materialCost + jcbCost + rollerCost + tipperCost;
      const siteProfit = totalBills - totalSiteExpenses;
      
      return {
        site_code: site.site_code,
        site_name: site.site_name,
        work_name: site.work_name,
        total_bills: totalBills,
        total_expenses: totalSiteExpenses,
        profit: siteProfit,
        profit_percentage: totalBills > 0 ? ((siteProfit / totalBills) * 100).toFixed(2) : 0
      };
    });

    // 3. Pending Payments (bills received vs work order amounts)
    const pendingPaymentsQuery = `
      SELECT 
        wo.site_code,
        wo.site_name,
        wo.contractor_name,
        CAST(wo.work_order_amount AS DECIMAL(15,2)) as work_order_amount,
        IFNULL(SUM(CAST(bd.net_bill_amount AS DECIMAL(15,2))), 0) as bills_received
      FROM work_order wo
      LEFT JOIN bill_details bd ON wo.site_code = bd.site_code AND bd.is_deleted = 0
      WHERE wo.is_deleted = 0 AND wo.site_code IS NOT NULL AND wo.site_code != ''
      GROUP BY wo.site_code, wo.site_name, wo.contractor_name, wo.work_order_amount
      HAVING work_order_amount > bills_received
    `;
    
    const pendingPayments = await queryExecute(pendingPaymentsQuery);
    const pendingPaymentsSummary = pendingPayments.map(payment => {
      const workOrderAmount = parseFloat(payment.work_order_amount) || 0;
      const billsReceived = parseFloat(payment.bills_received) || 0;
      const pendingAmount = workOrderAmount - billsReceived;
      
      return {
        site_code: payment.site_code,
        site_name: payment.site_name,
        contractor_name: payment.contractor_name,
        work_order_amount: workOrderAmount,
        bills_received: billsReceived,
        pending_amount: pendingAmount,
        completion_percentage: workOrderAmount > 0 ? ((billsReceived / workOrderAmount) * 100).toFixed(2) : 0
      };
    });

    // 4. Cash Ledger Balance by Partner
    const cashLedgerQuery = `
      SELECT 
        pm.partner_name,
        IFNULL(
          (SELECT SUM(CAST(amount AS DECIMAL(15,2))) 
           FROM daily_expenses 
           WHERE paid_by = pm.partner_name AND is_deleted = 0), 0
        ) as daily_expenses,
        IFNULL(
          (SELECT SUM(CAST(grand_total AS DECIMAL(15,2))) 
           FROM mvjcb_detials 
           WHERE party_name = pm.partner_name AND is_deleted = 0), 0
        ) as jcb_expenses,
        IFNULL(
          (SELECT SUM(CAST(total_amount AS DECIMAL(15,2))) 
           FROM mv_rollertt_details 
           WHERE party_name = pm.partner_name AND is_deleted = 0), 0
        ) as roller_expenses,
        IFNULL(
          (SELECT SUM(CAST(total_amount AS DECIMAL(15,2))) 
           FROM mvtipper_details 
           WHERE party_name = pm.partner_name AND is_deleted = 0), 0
        ) as tipper_expenses
      FROM partner_master pm
      WHERE pm.is_deleted = 0
    `;
    
    const cashLedgerData = await queryExecute(cashLedgerQuery);
    const cashLedgerBalance = cashLedgerData.map(partner => {
      const dailyExpenses = parseFloat(partner.daily_expenses) || 0;
      const jcbExpenses = parseFloat(partner.jcb_expenses) || 0;
      const rollerExpenses = parseFloat(partner.roller_expenses) || 0;
      const tipperExpenses = parseFloat(partner.tipper_expenses) || 0;
      
      const totalExpenses = dailyExpenses + jcbExpenses + rollerExpenses + tipperExpenses;
      
      return {
        partner_name: partner.partner_name,
        total_expenses: totalExpenses,
        daily_expenses: dailyExpenses,
        machinery_expenses: jcbExpenses + rollerExpenses + tipperExpenses
      };
    });

    // Summary stats
    const summaryStats = {
      total_sites: siteProfitSummary.length,
      total_pending_payments: pendingPaymentsSummary.reduce((sum, p) => sum + p.pending_amount, 0),
      total_partners: cashLedgerBalance.length,
      avg_profit_percentage: siteProfitSummary.length > 0 
        ? (siteProfitSummary.reduce((sum, s) => sum + parseFloat(s.profit_percentage), 0) / siteProfitSummary.length).toFixed(2)
        : 0
    };

    res.status(200).json({
      success: true,
      data: {
        financialOverview: {
          total_bills_received: totalBillsReceived,
          total_work_order_amount: totalWorkOrderAmount,
          total_expenses: totalAllExpenses,
          breakdown: {
            daily_expenses: totalExpenses,
            material_cost: totalMaterialCost,
            machinery_cost: totalJcbCost + totalRollerCost + totalTipperCost,
            salaries: totalSalariesPaid
          },
          net_profit: netProfit,
          profit_margin: totalBillsReceived > 0 ? ((netProfit / totalBillsReceived) * 100).toFixed(2) : 0
        },
        siteProfitSummary,
        pendingPayments: pendingPaymentsSummary,
        cashLedgerBalance,
        summaryStats
      }
    });

  } catch (error) {
    console.error('Error in getDashboardData:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch dashboard data',
      error: error.message
    });
  }
};

module.exports = {
  getDashboardData
};
