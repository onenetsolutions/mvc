const { queryExecute } = require("../libs/dbRequest");
const { generatePDF, commonStyles, formatCurrency, formatDate, esc } = require('../libs/pdfGenerator');

const getSiteWiseReport = async (siteCode) => {
  try {
    // ===== 1. TENDER & WORK ORDER DETAILS =====
    const tenderWorkOrderQuery = `
      SELECT 
        wo.site_code,
        wo.site_name,
        t.entry_date as date_of_bidding,
        wo.department_name,
        wo.work_name,
        wo.work_head,
        t.tender_amount,
        t.tender_id_user as tender_id,
        wo.contractor_name,
        t.contractor_details as bidders_json,
        wo.agreement_no,
        wo.work_order_no,
        wo.work_order_date,
        wo.work_time_limit,
        wo.dlp_period,
        wo.security_deposit_amount,
        wo.additional_security_deposit_amount,
        wo.workdone_by as partners_json,
        wo.security_deposit as security_deposit_json,
        wo.additionalsecurity_deposit as additionalsecurity_deposit_json
      FROM work_order wo
      LEFT JOIN tender t ON t.sr_no = wo.sr_no AND t.is_deleted = 0
      WHERE wo.site_code = '${siteCode}' AND wo.is_deleted = 0
      ORDER BY wo.work_order_date DESC
      LIMIT 1
    `;
    const tenderWorkOrderData = await queryExecute(tenderWorkOrderQuery);
    const tenderData = tenderWorkOrderData[0] || {};

    // Parse JSON fields
    let bidders = [];
    let partners = [];
    let securityDeposits = [];
    let additionalSecurityDeposits = [];
    try {
      if (tenderData.bidders_json && tenderData.bidders_json.trim().startsWith('[')) {
        bidders = JSON.parse(tenderData.bidders_json);
      }
      if (tenderData.partners_json && tenderData.partners_json.trim().startsWith('[')) {
        partners = JSON.parse(tenderData.partners_json);
      }
      if (tenderData.security_deposit_json && tenderData.security_deposit_json.trim().startsWith('[')) {
        securityDeposits = JSON.parse(tenderData.security_deposit_json);
      }
      if (tenderData.additionalsecurity_deposit_json && tenderData.additionalsecurity_deposit_json.trim().startsWith('[')) {
        additionalSecurityDeposits = JSON.parse(tenderData.additionalsecurity_deposit_json);
      }
    } catch (e) {
      console.error('JSON parse error:', e);
    }

    // Extract relevant data for the assigned contractor
    let tenderFeeAmount = 0;
    let tenderFeePaidBy = null;
    let emdAmount = 0;
    let emdPaidBy = null;

    if (bidders && bidders.length > 0) {
      // Find the bidder who got the work order (match by contractor_name)
      const winningBidder = bidders.find(b => b.contractor_name === tenderData.contractor_name);
      if (winningBidder) {
        tenderFeeAmount = winningBidder.tender_fee || 0;
        tenderFeePaidBy = winningBidder.paid_by || null;
        emdAmount = winningBidder.emd_amount || 0;
        emdPaidBy = winningBidder.paid_by || null;
      } else {
        // Fallback: use the first bidder if no contractor match
        const firstBidder = bidders[0];
        tenderFeeAmount = firstBidder.tender_fee || 0;
        tenderFeePaidBy = firstBidder.paid_by || null;
        emdAmount = firstBidder.emd_amount || 0;
        emdPaidBy = firstBidder.paid_by || null;
      }
    }

    let sdPaidBy = securityDeposits.map(sd => sd.fdr_amount_paid_by).filter(Boolean).join(', ') || null;
    let asdPaidBy = additionalSecurityDeposits.map(asd => asd.fdr_amount_paid_by).filter(Boolean).join(', ') || null;

    // ===== 2. MATERIAL ENTRY (GROUPED BY SUPPLIER & PARTNER) =====
    const materialEntryQuery = `
      SELECT 
        me.challan_date as date,
        me.challan_no,
        me.supplier as supplier_name,
        me.material_details,
        me.amount,
        me.other_charges,
        (COALESCE(me.amount, 0) + COALESCE(me.other_charges, 0)) as total_amount,
        me.remark,
        COALESCE(me.partner_name, '') as partner_associated
      FROM material_entry me
      WHERE me.site_code = '${siteCode}' AND me.is_deleted = 0
        AND (me.machinery_type IS NULL OR me.machinery_type = '')
      ORDER BY me.supplier, me.challan_date
    `;
    const materialEntriesTemp = await queryExecute(materialEntryQuery);

    // Unpack material details JSON
    const materialEntries = [];
    materialEntriesTemp.forEach(row => {
      let details = [];
      try {
        if (row.material_details && typeof row.material_details === 'string') {
          details = JSON.parse(row.material_details);
        } else if (Array.isArray(row.material_details)) {
          details = row.material_details;
        }
      } catch (e) {
        console.error("Error parsing material_details:", e);
      }

      if (details.length > 0) {
        details.forEach((item, idx) => {
          materialEntries.push({
            ...row,
            material_name: item.material_name || '-',
            quantity: parseFloat(item.quantity) || 0,
            rate: parseFloat(item.rate) || 0,
            amount: (parseFloat(item.quantity) || 0) * (parseFloat(item.rate) || 0),
            other_charges: idx === 0 ? (parseFloat(row.other_charges) || 0) : 0,
            total_amount: ((parseFloat(item.quantity) || 0) * (parseFloat(item.rate) || 0)) + (idx === 0 ? (parseFloat(row.other_charges) || 0) : 0)
          });
        });
      } else {
        materialEntries.push({
          ...row,
          material_name: '-',
          quantity: 0,
          rate: 0
        });
      }
    });

    // Group material by supplier & partner
    const materialBySupplierPartner = {};
    materialEntries.forEach(item => {
      const supplier = item.supplier_name || 'Unknown Supplier';
      const partner = item.partner_associated || 'General';
      const key = `${supplier}|${partner}`;

      if (!materialBySupplierPartner[key]) {
        materialBySupplierPartner[key] = {
          supplier_name: supplier,
          partner_associated: partner,
          items: [],
          total_amount: 0
        };
      }
      materialBySupplierPartner[key].items.push(item);
      materialBySupplierPartner[key].total_amount += parseFloat(item.total_amount) || 0;
    });

    // ===== 3. MACHINERY DETAILS (ALL 3 TYPES, GROUPED BY PARTY) =====
    const jcbQuery = `
      SELECT 
        entry_date as date,
        party_name as machinery_owner,
        COALESCE(partner_name, '') as partner_associated,
        'JCB' as machinery_type,
        site_code,
        site_name,
        total_reading as reading_value,
        rate,
        COALESCE(grand_total, total_amount, 0) as amount,
        NULL as remark,
        'hrs' as reading_unit
      FROM mvjcb_detials
      WHERE site_code = '${siteCode}' AND is_deleted = 0
    `;

    const rollerQuery = `
      SELECT 
        entry_date as date,
        party_name as machinery_owner,
        COALESCE(partner_name, '') as partner_associated,
        'Roller/TT' as machinery_type,
        site_code,
        site_name,
        trip as reading_value,
        rate,
        total_amount as amount,
        NULL as remark,
        'trips/days' as reading_unit
      FROM mv_rollertt_details
      WHERE site_code = '${siteCode}' AND is_deleted = 0
    `;

    const tipperQuery = `
      SELECT 
        entry_date as date,
        party_name as machinery_owner,
        COALESCE(partner_name, '') as partner_associated,
        'Tipper' as machinery_type,
        site_code,
        site_name,
        qty as reading_value,
        rate,
        total_amount as amount,
        description as remark,
        'trips/days' as reading_unit
      FROM mvtipper_details
      WHERE site_code = '${siteCode}' AND is_deleted = 0
    `;

    const otherMachineryQuery = `
      SELECT
        entry_date as date,
        owner as machinery_owner,
        COALESCE(partner_name, '') as partner_associated,
        machinery_type as machinery_type,
        site_code,
        site_name,
        total_reading as reading_value,
        machinery_rate as rate,
        machinery_total as amount,
        description as remark,
        CASE
          WHEN machinery_type = 'JCB-Pokline' THEN 'hrs'
          ELSE 'trips/days'
        END as reading_unit
      FROM material_entry
      WHERE site_code = '${siteCode}' AND is_deleted = 0
        AND machinery_type IS NOT NULL AND machinery_type != ''
    `;

    const [jcbMachinery, rollerMachinery, tipperMachinery, otherMachinery] = await Promise.all([
      queryExecute(jcbQuery),
      queryExecute(rollerQuery),
      queryExecute(tipperQuery),
      queryExecute(otherMachineryQuery)
    ]);

    const allMachinery = [...jcbMachinery, ...rollerMachinery, ...tipperMachinery, ...otherMachinery];

    // Group machinery by party
    const machineryByParty = {};
    allMachinery.forEach(item => {
      const party = item.machinery_owner || 'Unknown Party';
      if (!machineryByParty[party]) {
        machineryByParty[party] = {
          party_name: party,
          items: [],
          total_amount: 0
        };
      }
      machineryByParty[party].items.push(item);
      machineryByParty[party].total_amount += parseFloat(item.amount) || 0;
    });

    // ===== 4. ALL EXPENSES BY PARTNERS (Comprehensive: Tender to Machinery, excl. Payment Entry) =====
    const dailyExpQuery = `
      SELECT 
        de.expense_date as date,
        de.paid_to as paid_to,
        de.payment_through,
        de.amount,
        de.payment_mode,
        de.paid_by,
        de.sub_payment_mode,
        de.description
      FROM daily_expenses de
      WHERE de.site_code = '${siteCode}' AND de.is_deleted = 0
    `;
    const salaryExpQuery = `
      SELECT 
        se.date as date,
        se.employee_name as paid_to,
        'Salary Payment' as payment_through,
        se.salary_paid as amount,
        se.payment_mode,
        se.paid_by,
        se.sub_payment_mode,
        CONCAT('Salary - ', se.employee_name) as description
      FROM salary_entry se
      WHERE se.is_deleted = 0 AND se.site_code = '${siteCode}'
    `;

    const [dailyExpenses, salaryExpenses] = await Promise.all([
      queryExecute(dailyExpQuery),
      queryExecute(salaryExpQuery)
    ]);

    // Build comprehensive allExpenses from all sources
    const allExpenses = [];

    // 1. Tender Entry expenses (tender_fee, emd)
    if (parseFloat(tenderFeeAmount) > 0) {
      allExpenses.push({
        date: tenderData.date_of_bidding || null,
        paid_to: 'Tender Fee',
        payment_through: 'Tender Entry',
        amount: parseFloat(tenderFeeAmount) || 0,
        payment_mode: '',
        paid_by: tenderFeePaidBy || '',
        partner_group: tenderFeePaidBy || '',
        description: `Tender Fee for ${tenderData.tender_id || siteCode}`
      });
    }
    if (parseFloat(emdAmount) > 0) {
      allExpenses.push({
        date: tenderData.date_of_bidding || null,
        paid_to: 'EMD',
        payment_through: 'Tender Entry',
        amount: parseFloat(emdAmount) || 0,
        payment_mode: '',
        paid_by: emdPaidBy || '',
        partner_group: emdPaidBy || '',
        description: `EMD for ${tenderData.tender_id || siteCode}`
      });
    }

    // 2. Work Order expenses (Security Deposits)
    securityDeposits.forEach(sd => {
      const amt = parseFloat(sd.fdr_amount) || 0;
      if (amt > 0) {
        allExpenses.push({
          date: tenderData.work_order_date || null,
          paid_to: 'Security Deposit',
          payment_through: 'Work Order',
          amount: amt,
          payment_mode: sd.fdr_type || '',
          paid_by: sd.fdr_amount_paid_by || '',
          partner_group: sd.fdr_amount_paid_by || '',
          description: `Security Deposit - ${sd.fdr_type || ''} ${sd.fdr_no || ''}`.trim()
        });
      }
    });
    additionalSecurityDeposits.forEach(asd => {
      const amt = parseFloat(asd.fdr_amount) || 0;
      if (amt > 0) {
        allExpenses.push({
          date: tenderData.work_order_date || null,
          paid_to: 'Additional Security Deposit',
          payment_through: 'Work Order',
          amount: amt,
          payment_mode: asd.fdr_type || '',
          paid_by: asd.fdr_amount_paid_by || '',
          partner_group: asd.fdr_amount_paid_by || '',
          description: `Additional SD - ${asd.fdr_type || ''} ${asd.fdr_no || ''}`.trim()
        });
      }
    });

    // 3. Daily Expenses
    dailyExpenses.forEach(de => {
      const isOfficeCash = String(de.payment_mode || '').toUpperCase().includes('OFFICE CASH');
      allExpenses.push({
        date: de.date,
        paid_to: de.paid_to || '',
        payment_through: de.payment_through || 'Daily Expenses',
        amount: parseFloat(de.amount) || 0,
        payment_mode: de.payment_mode || '',
        paid_by: isOfficeCash ? (de.sub_payment_mode || '') : (de.paid_by || ''),
        partner_group: isOfficeCash ? 'Office Cash' : (de.paid_by || ''),
        description: de.description || ''
      });
    });

    // 4. Material Entry (one row per challan)
    materialEntriesTemp.forEach(me => {
      allExpenses.push({
        date: me.date,
        paid_to: me.supplier_name || '',
        payment_through: 'Material Entry',
        amount: parseFloat(me.total_amount) || 0,
        payment_mode: '',
        paid_by: me.partner_associated || '',
        partner_group: me.partner_associated || '',
        description: `Material - ${me.supplier_name || ''}`
      });
    });

    // 5. All Machinery (JCB, Roller/TT, Tipper, Other)
    allMachinery.forEach(m => {
      allExpenses.push({
        date: m.date,
        paid_to: m.machinery_owner || '',
        payment_through: `Machinery - ${m.machinery_type}`,
        amount: parseFloat(m.amount) || 0,
        payment_mode: '',
        paid_by: m.partner_associated || '',
        partner_group: m.partner_associated || '',
        description: `${m.machinery_type} Machinery`
      });
    });

    // 6. Salary Entry
    salaryExpenses.forEach(se => {
      const isOfficeCash = String(se.payment_mode || '').toUpperCase().includes('OFFICE CASH');
      allExpenses.push({
        date: se.date,
        paid_to: se.paid_to || '',
        payment_through: se.payment_through || 'Salary Payment',
        amount: parseFloat(se.amount) || 0,
        payment_mode: se.payment_mode || '',
        paid_by: isOfficeCash ? (se.sub_payment_mode || '') : (se.paid_by || ''),
        partner_group: isOfficeCash ? 'Office Cash' : (se.paid_by || ''),
        description: se.description || ''
      });
    });

    // Sort by partner (paid_by) then date
    allExpenses.sort((a, b) => {
      const pA = (a.paid_by || '').toLowerCase();
      const pB = (b.paid_by || '').toLowerCase();
      if (pA < pB) return -1;
      if (pA > pB) return 1;
      return new Date(a.date || 0) - new Date(b.date || 0);
    });

    // Group expenses by partner
    const normalizedExpenses = allExpenses.map(item => ({
      ...item,
      paid_by: item.paid_by || '',
      partner_group: item.partner_group || item.paid_by || ''
    }));

    // ===== 5. BILL DETAILS (GROUPED BY PAYMENT STAGES) =====
    const billDetailsQuery = `
      SELECT 
        bd.entry_date as date,
        bd.contractor_name,
        bd.department_name,
        bd.work_name,
        bd.agreement_no,
        bd.bank_name,
        bd.bill_no as bill_no,
        bd.total_bill_amount,
        bd.deduction_amount,
        bd.net_bill_amount,
        bd.description
      FROM bill_details bd
      WHERE bd.site_code = '${siteCode}' AND bd.is_deleted = 0
      ORDER BY bd.entry_date, bd.bill_no
    `;

    const billDetails = await queryExecute(billDetailsQuery);

    const totalNetBillAmount = billDetails.reduce(
      (sum, bill) => sum + (parseFloat(bill.net_bill_amount) || 0),
      0
    );

    return {
      success: true,
      data: {
        siteDetails: {
          site_code: tenderData.site_code || siteCode,
          site_name: tenderData.site_name || '',
          date_of_bidding: tenderData.date_of_bidding || null,
          name_of_department: tenderData.department_name || '',
          name_of_work: tenderData.work_name || '',
          work_head: tenderData.work_head || '',
          tender_amount: tenderData.tender_amount || 0,
          tender_id: tenderData.tender_id || '',
          contractor_name: tenderData.contractor_name || '',
          agreement_no: tenderData.agreement_no || '',
          work_order_no: tenderData.work_order_no || '',
          date_of_work_order: tenderData.work_order_date || null,
          work_time_limit: tenderData.work_time_limit || null,
          dlp_period: tenderData.dlp_period || ''
        },
        bidders,
        tenderFee: {
          tender_fee_amount: tenderFeeAmount,
          tender_fee_paid_by: tenderFeePaidBy,
          tender_fee_payment_date: null,
          tender_fee_payment_mode: null
        },
        emdDetails: {
          emd_amount: emdAmount,
          emd_paid_by: emdPaidBy,
          emd_payment_date: null,
          emd_payment_mode: null
        },
        securityDeposit: {
          security_deposit_amount: tenderData.security_deposit_amount || 0,
          security_deposit_paid_by: sdPaidBy,
          security_deposit_payment_date: null,
          security_deposit_payment_mode: null,
          additional_security_deposit_amount: tenderData.additional_security_deposit_amount || 0,
          additional_security_deposit_paid_by: asdPaidBy,
          additional_security_deposit_payment_date: null,
          additional_security_deposit_payment_mode: null
        },
        partners: partners.map(name => ({ partner_name: name, partner_code: '' })),
        materialEntry: Object.values(materialBySupplierPartner).flatMap(group => group.items.map(item => ({
          ...item,
          partner_associated: group.partner_associated
        }))),
        machineryDetails: allMachinery.map(item => ({
          date: item.date,
          machinery_owner_name: item.machinery_owner,
          partner_associated: item.partner_associated || '',
          machinery_type: item.machinery_type,
          site_code: item.site_code,
          site_name: item.site_name,
          total_reading: item.reading_value,
          rate: item.rate,
          amount: item.amount,
          remark: item.remark,
          reading_unit: item.reading_unit
        })),
        allExpenses: normalizedExpenses,
        billDetails,
        totalNetBillAmount
      }
    };
  } catch (error) {
    console.error("Error in getSiteWiseReport:", error);
    return {
      success: false,
      message: error.message
    };
  }
};

// Get list of all site codes for dropdown
const getSiteCodes = async () => {
  try {
    const query = `
      SELECT DISTINCT 
        wo.site_code,
        wo.site_name
      FROM work_order wo
      WHERE wo.site_code IS NOT NULL AND wo.site_code != ''
      ORDER BY wo.site_code
    `;
    const siteCodes = await queryExecute(query);

    return {
      success: true,
      data: siteCodes
    };
  } catch (error) {
    console.error("Error in getSiteCodes:", error);
    return {
      success: false,
      message: error.message
    };
  }
};

const generateSiteWiseReportPDF = async (siteCode, data, res) => {
  const hasData = (data.billDetails && data.billDetails.length > 0) ||
    (data.materialEntry && data.materialEntry.length > 0) ||
    (data.machineryDetails && data.machineryDetails.length > 0) ||
    (data.allExpenses && data.allExpenses.length > 0);

  // Group expenses by partner
  const expensesByPartner = {};
  if (data.allExpenses) {
    data.allExpenses.forEach(exp => {
      const partner = exp.partner_group || exp.paid_by || 'Office Cash';
      if (!expensesByPartner[partner]) expensesByPartner[partner] = [];
      expensesByPartner[partner].push(exp);
    });
  }

  const html = `<!DOCTYPE html><html><head><style>${commonStyles}</style></head><body>
    <div class="report-title">Site Wise Report - ${esc(siteCode)}</div>

    <div class="section-header">Site Information</div>
    <div class="info-row"><span class="info-label">Site Name:</span> ${esc(data.siteDetails.site_name)}</div>
    <div class="info-row"><span class="info-label">Tender Amount:</span> ${formatCurrency(data.siteDetails.tender_amount)}</div>
    <div class="info-row"><span class="info-label">Contractor Name:</span> ${esc(data.siteDetails.contractor_name)}</div>
    <div class="info-row"><span class="info-label">Work Order Date:</span> ${esc(formatDate(data.siteDetails.date_of_work_order))}</div>
    <div class="info-row"><span class="info-label">Generated on:</span> ${new Date().toLocaleDateString('en-GB')}</div>

    <div class="section-header">Fees &amp; Deposits</div>
    <div class="fees-grid">
      <div class="info-row"><span class="info-label">Tender Fee:</span> ${formatCurrency(data.tenderFee?.tender_fee_amount)} (Paid By: ${esc(data.tenderFee?.tender_fee_paid_by)})</div>
      <div class="info-row"><span class="info-label">Security Deposit:</span> ${formatCurrency(data.securityDeposit?.security_deposit_amount)} (Paid By: ${esc(data.securityDeposit?.security_deposit_paid_by)})</div>
      <div class="info-row"><span class="info-label">EMD Amount:</span> ${formatCurrency(data.emdDetails?.emd_amount)} (Paid By: ${esc(data.emdDetails?.emd_paid_by)})</div>
      <div class="info-row"><span class="info-label">Additional SD:</span> ${formatCurrency(data.securityDeposit?.additional_security_deposit_amount)} (Paid By: ${esc(data.securityDeposit?.additional_security_deposit_paid_by)})</div>
    </div>

    ${data.billDetails && data.billDetails.length > 0 ? `
    <div class="section-header">Bill Details (Total Amount Received)</div>
    <table>
      <thead><tr>
        <th>Date</th><th>Bill No / Stage</th><th>Bank Name</th>
        <th class="text-right">Total Bill Amount</th><th class="text-right">Deductions</th>
        <th class="text-right">Net Amount</th><th>Description</th>
      </tr></thead>
      <tbody>
        ${data.billDetails.map(b => `<tr>
          <td>${esc(formatDate(b.date))}</td><td>${esc(b.bill_no)}</td><td>${esc(b.bank_name)}</td>
          <td class="text-right">${formatCurrency(b.total_bill_amount)}</td>
          <td class="text-right">${formatCurrency(b.deduction_amount)}</td>
          <td class="text-right">${formatCurrency(b.net_bill_amount)}</td>
          <td>${esc(b.description)}</td>
        </tr>`).join('')}
        <tr class="total-row">
          <td colspan="5" class="text-right">Total Net Bills Received:</td>
          <td class="text-right">${formatCurrency(data.totalNetBillAmount)}</td><td></td>
        </tr>
      </tbody>
    </table>` : ''}

    ${data.materialEntry && data.materialEntry.length > 0 ? `
    <div class="section-header">Material Supplies (Amount Given)</div>
    <table>
      <thead><tr>
        <th>Date</th><th>Challan</th><th>Supplier Name</th><th>Material</th>
        <th class="text-right">Qty</th><th class="text-right">Rate</th>
        <th class="text-right">Amount</th><th>Paid By (Partner)</th>
      </tr></thead>
      <tbody>
        ${data.materialEntry.map(e => `<tr>
          <td>${esc(formatDate(e.date))}</td><td>${esc(e.challan_no)}</td><td>${esc(e.supplier_name)}</td>
          <td>${esc(e.material_name)}</td><td class="text-right">${esc(e.quantity)}</td>
          <td class="text-right">${formatCurrency(e.rate)}</td>
          <td class="text-right">${formatCurrency(e.total_amount || e.amount)}</td>
          <td>${esc(e.partner_associated || e.partner_name)}</td>
        </tr>`).join('')}
      </tbody>
    </table>` : ''}

    ${data.machineryDetails && data.machineryDetails.length > 0 ? `
    <div class="section-header">Machinery Usage Details</div>
    <table>
      <thead><tr>
        <th>Date</th><th>Type</th><th>Machinery Owner</th><th>Reading</th>
        <th class="text-right">Rate</th><th class="text-right">Total Amount</th><th>Paid By</th>
      </tr></thead>
      <tbody>
        ${data.machineryDetails.map(m => `<tr>
          <td>${esc(formatDate(m.date))}</td><td>${esc(m.machinery_type)}</td><td>${esc(m.machinery_owner_name)}</td>
          <td>${(m.total_reading || 0)} ${esc(m.reading_unit)}</td>
          <td class="text-right">${formatCurrency(m.rate)}</td>
          <td class="text-right">${formatCurrency(m.amount)}</td>
          <td>${esc(m.partner_associated)}</td>
        </tr>`).join('')}
      </tbody>
    </table>` : ''}

    ${data.allExpenses && data.allExpenses.length > 0 ? `
    <div class="section-header">All Expenses By Partners on the site</div>
    <div style="font-size:8px;color:#666;margin-bottom:8px;">Complete expenses from Tender Entry, Work Order, Daily Expenses, Material Entry, Salary Entry &amp; all Machinery</div>
    ${Object.entries(expensesByPartner).map(([partner, expenses]) => {
    const partnerTotal = expenses.reduce((s, e) => s + (parseFloat(e.amount) || 0), 0);
    return `
      <div class="partner-header">Partner: ${partner === '' ? 'Office Cash' : esc(partner)}</div>
      <table>
        <thead><tr>
          <th>Sr</th><th>Date</th><th>Paid To</th><th>Payment Through</th>
          <th class="text-right">Amount</th><th>Payment Mode</th><th>Paid By</th><th>Description</th>
        </tr></thead>
        <tbody>
          ${expenses.map((e, idx) => `<tr>
            <td>${idx + 1}</td><td>${esc(formatDate(e.date))}</td><td>${esc(e.paid_to)}</td>
            <td>${esc(e.payment_through)}</td><td class="text-right">${formatCurrency(e.amount)}</td>
            <td>${esc(e.payment_mode)}</td><td>${esc(e.paid_by)}</td><td>${esc(e.description)}</td>
          </tr>`).join('')}
          <tr class="total-row">
            <td colspan="4" class="text-right">Total for ${partner === '' ? 'Office Cash' : esc(partner)}:</td>
            <td class="text-right">${formatCurrency(partnerTotal)}</td><td colspan="3"></td>
          </tr>
        </tbody>
      </table>`;
  }).join('')}` : ''}

    ${!hasData ? '<div class="no-data">No records found for this site.</div>' : ''}
  </body></html>`;

  const filename = `Site_Wise_Report_${siteCode}_${new Date().toISOString().slice(0, 10)}.pdf`;
  await generatePDF(html, res, filename, { layout: 'landscape' });
};

module.exports = {
  getSiteWiseReport,
  getSiteCodes,
  generateSiteWiseReportPDF
};
