const lib = require('../libs/index');
let service = {};

const sqlValue = (value) => {
  if (value === undefined || value === null || value === '') {
    return 'NULL';
  }
  return `'${value}'`;
};


service.insertworkheadMaster = async (req, res, next) => {
  try {
    const workhead_name = req.body.workhead_name || '';

        const queryStr = `INSERT INTO workhead_master 
          (workhead_name) 
          VALUES 
          (${sqlValue(workhead_name)})`;

    await lib.queryExecute(queryStr);

    res.status(200).send({ result: req.body, message: 'Added Successfully!' });
  } catch (error) {
    // Handling any errors
    res.status(500).send(error);
  }
};



service.workheadMasterList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = req.query.searchKey || '';
    let searchCondition = 'is_deleted = 0';

    const allColumns = ['workhead_name'];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');

      searchCondition += ` AND (${searchConditions})`;
    }

    const page = parseInt(req.query.page, 10) || 0;
    const size = parseInt(req.query.size, 10) || 10;

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                      FROM workhead_master
                      WHERE ${searchCondition} 
                      ORDER BY workhead_id ASC 
                      ${pageSet}`;

    const countQuery = `SELECT COUNT(*) AS totalCount 
                          FROM workhead_master
                          WHERE is_deleted = 0`;

    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = totalCountResult[0].totalCount;

    const result = await lib.queryExecute(queryStr);

    // Include total count in the response
    const response = result.map(item => ({
      ...item,
      totalCount
    }));

    res.status(200).send(response);

  } catch (error) {
    console.error('Error in workhead_master:', error);
    res.status(500).send({ message: error.message });
  }
};



// Update or delete workhead_master entry

service.updateDeleteworkheadMaster = async (req, res, next) => {
    try {
        console.log('Request body:', req.body);
        
        const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
        const workhead_id = req.body.workhead_id;

        if (changedUpdatedValue === 'edit') {
            const { workhead_name = '' } = req.body;

            const queryStr = `UPDATE workhead_master SET 
              workhead_name = ${sqlValue(workhead_name)}
                WHERE workhead_id = ${workhead_id}`;

            console.log('Generated SQL query:', queryStr);
            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Updated Successfully!' });

        } else if (changedUpdatedValue === 'delete') {
            const queryStr = `UPDATE workhead_master SET 
                is_deleted = 1
                WHERE workhead_id = ${workhead_id}`;

            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Deleted Successfully!' });
        } else {
            res.status(400).send({ error: 'Invalid changed update value' });
        }
    } catch (error) {
        console.error('Error in updateDeleteWorkHead:', error);
        res.status(500).send({ error: error.message || error });
    }
};



module.exports = service;
