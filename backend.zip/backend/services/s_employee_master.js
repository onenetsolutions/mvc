const lib = require('../libs/index');
let service = {};

const sqlValue = (value) => {
  if (value === undefined || value === null || value === '') {
    return 'NULL';
  }
  return `'${value}'`;
};


service.insertEmployeeMaster = async (req, res, next) => {
  try {


        const employee_name = req.body.employee_name || '';
        const gender = req.body.gender || '';
        const contact_no = req.body.contact_no || '';
        const dob = req.body.dob || '';
        const address = req.body.address || '';
        const salary_type = req.body.salary_type || '';
        const salary_amount = req.body.salary_amount || ''

    const queryStr = `INSERT INTO employee_master 
          (employee_name,gender,contact_no,dob,address,salary_type,salary_amount) 
          VALUES 
          (${sqlValue(employee_name)},${sqlValue(gender)},${sqlValue(contact_no)},${sqlValue(dob)},${sqlValue(address)},${sqlValue(salary_type)},${sqlValue(salary_amount)})`;


    await lib.queryExecute(queryStr);


    res.status(200).send({ result: req.body, message: 'Added Successfully!' });
  } catch (error) {
    // Handling any errors
    res.status(500).send(error);
  }
};



service.EmployeeMasterList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = req.query.searchKey || '';
    let searchCondition = 'is_deleted = 0';

    const allColumns = ['employee_name', 'gender', 'dob', 'address', 'salary_type', 'salary_amount'];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');


      searchCondition += ` AND (${searchConditions})`;
    }

    const page = parseInt(req.query.page, 10) || 0;
    const size = parseInt(req.query.size, 10) || 10;

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                      FROM employee_master
                      WHERE ${searchCondition} 
                      ORDER BY employee_id ASC 
                      ${pageSet}`;

    const countQuery = `SELECT COUNT(*) AS totalCount 
                          FROM employee_master
                          WHERE is_deleted = 0`;

    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = totalCountResult[0].totalCount;

    const result = await lib.queryExecute(queryStr);

    // Include total count in the response
    const response = result.map(item => ({
      ...item,
      totalCount
    }));

    res.status(200).send(response);

  } catch (error) {
    console.error('Error in employee_master:', error);
    res.status(500).send({ message: error.message });
  }
};



// Update or delete cylinder_master entry

service.updateDeleteEmployeeMaster = async (req, res, next) => {
  try {
    console.log('Request body:', req.body);

    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const employee_id = req.body.employee_id;

    if (changedUpdatedValue === 'edit') {
      const {
        employee_name = '',
        gender = '',
        contact_no = '',
        dob = '',
        address = '',
        salary_type = '',
        salary_amount = ''
      } = req.body;

      const queryStr = `UPDATE employee_master SET 
                employee_name = ${sqlValue(employee_name)},
                gender = ${sqlValue(gender)},
                contact_no = ${sqlValue(contact_no)},
                dob = ${sqlValue(dob)},
                address = ${sqlValue(address)},
                salary_type = ${sqlValue(salary_type)},
                salary_amount = ${sqlValue(salary_amount)}
                WHERE employee_id = ${employee_id}`;

      console.log('Generated SQL query:', queryStr);
      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      const queryStr = `UPDATE employee_master SET 
                is_deleted = 1
                WHERE employee_id = ${employee_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Deleted Successfully!' });
    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }
  } catch (error) {
    console.error('Error in update Employee Master:', error);
    res.status(500).send({ error: error.message || error });
  }
};



module.exports = service;


