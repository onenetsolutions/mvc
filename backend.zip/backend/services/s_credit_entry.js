const lib = require('../libs/index');
const { getCashBucket, validateCreditChange, getOfficeCashBalance } = require('../libs/officeCashBalance');
let service = {};


service.insertCreditEntry = async (req, res, next) => {
    try {
        const date = req.body.date || new Date().toISOString().split('T')[0];
        const party_name = req.body.party_name || '';
        const ref = req.body.ref || '';
        const description = req.body.description || '';
        const amount = req.body.amount || '';
        const credited_to = req.body.credited_to || '';
        const party_id = req.body.party_id || '';
        const material = req.body.materials ? JSON.stringify(req.body.materials) : ''; 

        const queryStr = `INSERT INTO credit_entry 
          (date, ref, party_name, description, amount, credited_to, party_id, material) 
          VALUES 
          ('${date}', '${ref}', '${party_name}', '${description}', '${amount}', '${credited_to}', '${party_id}', '${material}')`;

        console.log(queryStr, "hhhhhhhhhhhhhh");
        await lib.queryExecute(queryStr);

        res.status(200).send({ result: req.body, message: 'Added Successfully!' });
    } catch (error) {
        console.error('Error inserting credit entry:', error);
        res.status(500).send({ error: error.message });
    }
};

service.Stocktabalecount = async (req, res, next) => {
    try {
        // Get month from query param, or default to current month
        const selectedMonth = req.query.month || new Date().toISOString().slice(0, 7); // 'YYYY-MM'

        let queryStr = `
       SET @selected_month = '2025-11';

SELECT 
    COALESCE((
        SELECT SUM(amount)
        FROM daily_expenses 
        WHERE is_deleted = 0
          AND DATE_FORMAT(expense_date, '%Y-%m') = @selected_month
    ), 0) +
    COALESCE((
        SELECT SUM(total_amount)
        FROM payment_entry 
        WHERE is_deleted = 0
          AND DATE_FORMAT(entry_date, '%Y-%m') = @selected_month
    ), 0) +
    COALESCE((
        SELECT SUM(salary_paid)
        FROM salary_entry 
        WHERE is_deleted = 0
          AND DATE_FORMAT(date, '%Y-%m') = @selected_month
    ), 0) AS grand_total;
        `;

        const result = await lib.queryExecute(queryStr);

        res.json({ success: true, data: result });
    } catch (error) {
        next(error);
    }
};



service.CreditEntryList = async (req, res, next) => {
    try {
        let pageSet = '';
        const searchKey = req.query.searchKey || '';
        let searchCondition = 'is_deleted = 0';

        const allColumns = ['date', 'party_name', 'ref', 'description', 'amount', 'credited_to'];

        if (searchKey) {
            const searchConditions = allColumns
                .map(col => `${col} LIKE '%${searchKey}%'`)
                .join(' OR ');


            searchCondition += ` AND (${searchConditions})`;
        }

        const page = parseInt(req.query.page, 10) || 0;
        const size = parseInt(req.query.size, 10) || 10;

        if (size > 0) {
            pageSet = `LIMIT ${size} OFFSET ${page * size}`;
        }

        let queryStr = `SELECT * 
                      FROM credit_entry
                      WHERE ${searchCondition} 
                      ORDER BY credit_entry_id DESC 
                      ${pageSet}`;

        const countQuery = `SELECT COUNT(*) AS totalCount 
                          FROM credit_entry
                          WHERE is_deleted = 0`;

                         

        const totalCountResult = await lib.queryExecute(countQuery);
        const totalCount = totalCountResult[0].totalCount;

        const result = await lib.queryExecute(queryStr);

        // Include total count in the response
        const response = result.map(item => ({
            ...item,
            totalCount
        }));

        res.status(200).send(response);

    } catch (error) {
        console.error('Error in credit_entry:', error);
        res.status(500).send({ message: error.message });
    }
};



// Update or delete cylinder_master entry

service.updateDeleteCreditEntry = async (req, res, next) => {
    try {
        console.log('Request body:', req.body);

        const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
        const credit_entry_id = req.body.credit_entry_id;

        // Fetch the old record for balance adjustment
        const oldRecordResult = await lib.queryExecute(
            `SELECT amount, credited_to FROM credit_entry WHERE credit_entry_id = ${credit_entry_id}`
        );
        const oldRecord = oldRecordResult[0] || {};

        if (changedUpdatedValue === 'edit') {
            const {
                date = '',
                party_name = '',
                ref = '',
                description = '',
                amount = '',
                credited_to = '',
                party_id = ''
            } = req.body;

            const material = req.body.materials
                ? JSON.stringify(req.body.materials)
                : (req.body.material || "");

            // ── Office Cash Balance Adjustment (Credit Edit) ──
            // FORMULA: DIFF = NEW_CREDIT − OLD_CREDIT; NEW_BAL = CURRENT_BAL + DIFF
            const oldBucket = getCashBucket(oldRecord.credited_to);
            const newBucket = getCashBucket(credited_to);
            const oldAmount = parseFloat(oldRecord.amount || 0);
            const newAmount = parseFloat(amount || 0);

            // If bucket changed, validate both: removing from old, adding to new
            if (oldBucket && oldBucket !== newBucket) {
                const removeCheck = await validateCreditChange(oldBucket, oldAmount, 0);
                if (!removeCheck.valid) {
                    return res.status(400).send({ error: removeCheck.message });
                }
            }
            if (newBucket || oldBucket === newBucket) {
                const bucket = newBucket || oldBucket;
                if (bucket) {
                    const check = await validateCreditChange(
                        bucket,
                        oldBucket === newBucket ? oldAmount : 0,
                        newAmount
                    );
                    if (!check.valid) {
                        return res.status(400).send({ error: check.message });
                    }
                }
            }

            const queryStr = `UPDATE credit_entry SET 
                date = '${date}',
                party_name = '${party_name}',
                ref = '${ref}',
                description = '${description}',
                amount = '${amount}',
                credited_to = '${credited_to}',
                party_id = '${party_id}',
                material ='${material}'
                WHERE credit_entry_id = ${credit_entry_id}`;

            console.log('Generated SQL query:', queryStr);
            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Updated Successfully!' });

        } else if (changedUpdatedValue === 'delete') {
            // ── Office Cash Balance Adjustment (Credit Delete) ──
            // Deleting a credit = reducing credit to 0
            // FORMULA: DIFF = 0 − OLD_CREDIT; NEW_BAL = CURRENT_BAL + DIFF
            const delBucket = getCashBucket(oldRecord.credited_to);
            const delAmount = parseFloat(oldRecord.amount || 0);
            if (delBucket) {
                const check = await validateCreditChange(delBucket, delAmount, 0);
                if (!check.valid) {
                    return res.status(400).send({ error: check.message });
                }
            }

            const queryStr = `UPDATE credit_entry SET 
                is_deleted = 1
                WHERE credit_entry_id = ${credit_entry_id}`;

            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Deleted Successfully!' });
        } else {
            res.status(400).send({ error: 'Invalid changed update value' });
        }
    } catch (error) {
        console.error('Error in updateDepartmentMaster:', error);
        res.status(500).send({ error: error.message || error });
    }
};

// Get party ledger for cash credit entry
service.getPartyLedger = async (req, res, next) => {
    try {
        const party_name = req.query.party_name || '';
        const year = req.query.year || new Date().getFullYear();
        const month = req.query.month || new Date().getMonth() + 1;
        
        // Format month to YYYY-MM
        const monthStr = `${year}-${String(month).padStart(2, '0')}`;

        if (!party_name) {
            return res.status(400).send({ error: 'Party name is required' });
        }

        const queryStr = `
            SELECT 
                credit_entry_id,
                date,
                party_name,
                ref,
                description,
                amount,
                credited_to,
                is_deleted
            FROM credit_entry
            WHERE party_name = '${party_name}'
            AND is_deleted = 0
            AND DATE_FORMAT(date, '%Y-%m') = '${monthStr}'
            ORDER BY date ASC, credit_entry_id ASC
        `;

        const result = await lib.queryExecute(queryStr);

        // Calculate running balance
        let runningBalance = 0;
        const ledgerData = result.map(row => {
            const amount = parseFloat(row.amount) || 0;
            runningBalance += amount;
            return {
                ...row,
                credited_amount: amount,
                running_balance: runningBalance
            };
        });

        res.status(200).send({ success: true, data: ledgerData });
    } catch (error) {
        console.error('Error fetching party ledger:', error);
        res.status(500).send({ error: error.message });
    }
};

// Get current Office Cash balance per bucket (VD / MM)
service.officeCashBalance = async (req, res, next) => {
    try {
        const balances = await getOfficeCashBalance();
        res.status(200).send({
            success: true,
            data: balances,
            message: 'Office Cash Balance fetched successfully'
        });
    } catch (error) {
        console.error('Error fetching office cash balance:', error);
        res.status(500).send({ error: error.message });
    }
};

module.exports = service;


