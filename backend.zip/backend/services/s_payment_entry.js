const lib = require('../libs/index');
const { getCashBucket, validateDebitChange } = require('../libs/officeCashBalance');
let service = {};

const normalizeDecimal = (value, defaultValue = 0) => {
  if (value === undefined || value === null || String(value).trim() === '') {
    return Number(defaultValue);
  }
  const num = Number(value);
  return Number.isFinite(num) ? num : Number(defaultValue);
};

// Validation helper function
const validatePaymentEntry = (data) => {
  const errors = [];
  const asString = (value) => (value === undefined || value === null ? '' : String(value).trim());
  const isEmpty = (value) => asString(value) === '';
  const isOfficeCash = asString(data.payment_mode).toLowerCase() === 'office cash';

  // Mandatory field validation
  if (isEmpty(data.entry_date)) {
    errors.push('Date is mandatory');
  }

  if (isEmpty(data.paid_to)) {
    errors.push('Paid to is mandatory');
  }

  if (isEmpty(data.amount)) {
    errors.push('Amount is mandatory');
  } else if (isNaN(Number(data.amount)) || Number(data.amount) <= 0) {
    errors.push('Amount must be a valid positive number');
  }

  if (isEmpty(data.total_amount)) {
    errors.push('Total amount is mandatory');
  } else if (isNaN(Number(data.total_amount)) || Number(data.total_amount) <= 0) {
    errors.push('Total amount must be a valid positive number');
  }

  if (isEmpty(data.description)) {
    errors.push('Description is mandatory');
  }

  if (isEmpty(data.payment_mode)) {
    errors.push('Mode of Payment is mandatory');
  }

  if (!isOfficeCash && isEmpty(data.paid_by)) {
    errors.push('Paid by is mandatory (depends on regular/office cash)');
  }

  if (isOfficeCash && isEmpty(data.sub_payment_mode)) {
    errors.push('Office Cash selection is mandatory');
  }

  // Optional field validation (numeric validation only if provided)
  if (!isEmpty(data.gst_amount) && (isNaN(Number(data.gst_amount)) || Number(data.gst_amount) < 0)) {
    errors.push('GST amount must be a valid number');
  }

  if (!isEmpty(data.other_charges) && (isNaN(Number(data.other_charges)) || Number(data.other_charges) < 0)) {
    errors.push('Other charges must be a valid number');
  }

  return errors;
};

service.insertPaymentEntry = async (req, res, next) => {
  try {
    const entry_date = req.body.entry_date || '';
    const paid_to = req.body.paid_to || '';
    const description = req.body.description || '';
    const amount = normalizeDecimal(req.body.amount);
    const gst_amount = normalizeDecimal(req.body.gst_amount);
    const other_charges = normalizeDecimal(req.body.other_charges);
    const total_amount = normalizeDecimal(req.body.total_amount);
    const payment_mode = req.body.payment_mode || '';
    const sub_payment_mode = req.body.sub_payment_mode || '';
    const beneficiary_name = req.body.beneficiary_name || '';
    const paid_by = req.body.paid_by || '';
    const bank_name = req.body.bank_name || '';
    const account_name = req.body.account_name || '';
    const reference = req.body.reference || '';
    const remarks = req.body.remarks || '';

    // Validate mandatory fields
    const validationErrors = validatePaymentEntry(req.body);
    if (validationErrors.length > 0) {
      return res.status(400).send({ 
        error: 'Validation failed', 
        details: validationErrors 
      });
    }

    // ── Office Cash Balance Validation (New Debit) ──
    // FORMULA: DIFF = NEW_DEBIT − 0; NEW_BAL = CURRENT_BAL − DIFF
    if (String(payment_mode).toUpperCase().includes('OFFICE CASH')) {
      const bucket = getCashBucket(sub_payment_mode);
      const debitAmt = parseFloat(total_amount || amount || 0);
      const check = await validateDebitChange(bucket, 0, debitAmt);
      if (!check.valid) {
        return res.status(400).send({ error: check.message });
      }
    }

    const queryStr = `INSERT INTO payment_entry 
          (entry_date, paid_to, description, amount, gst_amount, 
           other_charges, total_amount, payment_mode, sub_payment_mode, beneficiary_name, 
           paid_by, bank_name, account_name, reference, remarks) 
          VALUES 
          ('${entry_date}', '${paid_to}', '${description}', ${amount}, 
           ${gst_amount}, ${other_charges}, ${total_amount}, 
           '${payment_mode}', '${sub_payment_mode}', '${beneficiary_name}', '${paid_by}', 
           '${bank_name}', '${account_name}', '${reference}', '${remarks}')`;

    await lib.queryExecute(queryStr);

    res.status(200).send({ result: req.body, message: 'Payment Entry Added Successfully!' });
  } catch (error) {
    res.status(500).send(error);
  }
};

service.paymentEntryList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = req.query.searchKey || '';
    let searchCondition = 'is_deleted = 0';

    const allColumns = [
      'entry_date', 'paid_to', 'description', 'amount', 'gst_amount',
      'other_charges', 'total_amount', 'payment_mode', 'sub_payment_mode', 'beneficiary_name',
      'paid_by', 'bank_name', 'account_name', 'reference', 'remarks'
    ];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');

      searchCondition += ` AND (${searchConditions})`;
    }

    const page = parseInt(req.query.page, 10) || 0;
    const size = parseInt(req.query.size, 10) || 10;

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                    FROM payment_entry
                    WHERE ${searchCondition} 
                    ORDER BY payment_entry_id ASC 
                    ${pageSet}`;

    const countQuery = `SELECT COUNT(*) AS totalCount 
                        FROM payment_entry
                        WHERE is_deleted = 0`;

    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = totalCountResult[0].totalCount;

    const result = await lib.queryExecute(queryStr);

    // Include total count in the response
    const response = result.map(item => ({
      ...item,
      totalCount
    }));

    res.status(200).send(response);

  } catch (error) {
    console.error('Error in payment_entry:', error);
    res.status(500).send({ message: error.message });
  }
};

service.updateDeletePaymentEntry = async (req, res, next) => {
  try {
    console.log('Request body:', req.body);
    
    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const payment_entry_id = req.body.payment_entry_id;

    // Fetch old record for balance adjustment
    const oldRecordResult = await lib.queryExecute(
      `SELECT total_amount, amount, payment_mode, sub_payment_mode FROM payment_entry WHERE payment_entry_id = ${payment_entry_id}`
    );
    const oldRecord = oldRecordResult[0] || {};

    if (changedUpdatedValue === 'edit') {
      const {
        entry_date = '',
        paid_to = '',
        description = '',
        amount = 0,
        gst_amount = 0,
        other_charges = 0,
        total_amount = 0,
        payment_mode = '',
        sub_payment_mode = '',
        beneficiary_name = '',
        paid_by = '',
        bank_name = '',
        account_name = '',
        reference = '',
        remarks = ''
      } = req.body;

      // Validate mandatory fields
      const validationErrors = validatePaymentEntry(req.body);
      if (validationErrors.length > 0) {
        return res.status(400).send({ 
          error: 'Validation failed', 
          details: validationErrors 
        });
      }

      // ── Office Cash Balance Adjustment (Payment Edit) ──
      // FORMULA: DIFF = NEW_DEBIT − OLD_DEBIT; NEW_BAL = CURRENT_BAL − DIFF
      const oldIsOfficeCash = String(oldRecord.payment_mode || '').toUpperCase().includes('OFFICE CASH');
      const newIsOfficeCash = String(payment_mode).toUpperCase().includes('OFFICE CASH');
      const oldBucket = oldIsOfficeCash ? getCashBucket(oldRecord.sub_payment_mode) : '';
      const newBucket = newIsOfficeCash ? getCashBucket(sub_payment_mode) : '';
      const oldPayAmt = oldIsOfficeCash ? parseFloat(oldRecord.total_amount || oldRecord.amount || 0) : 0;
      const newPayAmt = newIsOfficeCash ? parseFloat(total_amount || amount || 0) : 0;

      if (oldBucket === newBucket && oldBucket) {
        const check = await validateDebitChange(oldBucket, oldPayAmt, newPayAmt);
        if (!check.valid) return res.status(400).send({ error: check.message });
      } else {
        if (oldBucket) {
          const releaseCheck = await validateDebitChange(oldBucket, oldPayAmt, 0);
          if (!releaseCheck.valid) return res.status(400).send({ error: releaseCheck.message });
        }
        if (newBucket) {
          const debitCheck = await validateDebitChange(newBucket, 0, newPayAmt);
          if (!debitCheck.valid) return res.status(400).send({ error: debitCheck.message });
        }
      }

      const queryStr = `UPDATE payment_entry SET 
          entry_date = '${entry_date}',
          paid_to = '${paid_to}',
          description = '${description}',
          amount = ${normalizeDecimal(amount)},
          gst_amount = ${normalizeDecimal(gst_amount)},
          other_charges = ${normalizeDecimal(other_charges)},
          total_amount = ${normalizeDecimal(total_amount)},
          payment_mode = '${payment_mode}',
          sub_payment_mode = '${sub_payment_mode}',
          beneficiary_name = '${beneficiary_name}',
          paid_by = '${paid_by}',
          bank_name = '${bank_name}',
          account_name = '${account_name}',
          reference = '${reference}',
          remarks = '${remarks}'
          WHERE payment_entry_id = ${payment_entry_id}`;

      console.log('Generated SQL query:', queryStr);
      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Payment Entry Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      // ── Office Cash Balance Adjustment (Payment Delete) ──
      // Deleting a debit = setting debit to 0, balance increases

      const queryStr = `UPDATE payment_entry SET 
          is_deleted = 1
          WHERE payment_entry_id = ${payment_entry_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Payment Entry Deleted Successfully!' });
    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }
  } catch (error) {
    console.error('Error in updatePaymentEntry:', error);
    res.status(500).send({ error: error.message || error });
  }
};

module.exports = service;