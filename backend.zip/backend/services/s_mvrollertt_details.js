const lib = require('../libs/index');
let service = {};

const numVal = (v) => (v === '' || v === null || v === undefined) ? 'NULL' : v;


service.insertMvRTT = async (req, res, next) => {
  try {
    const {
      entry_date = '',
      site_code = '',
      party_name = '',
      site_name = '',
      partner_name = '',
      machinery_name= '',
      machinery_no = '',
      trip= '',
      rate = '',
      other_charges = '',
      total_amount = ''
    } = req.body;

    // Validate mandatory fields
    if (!entry_date || !party_name || !site_code || !site_name || !machinery_name || 
        !trip || !rate || !total_amount) {
      return res.status(400).send({ 
        error: 'Mandatory fields missing: Entry Date, Name of Party, Site Code, Site Name, Name of Machinery, No of Trips/Day, Rate, and Amount are required.' 
      });
    }

 const getLastEntryQuery = `
      SELECT entry_no 
      FROM mv_rollertt_details    
      WHERE is_deleted = 0 
   AND entry_no LIKE 'MVR%'
      ORDER BY entry_no DESC 
      LIMIT 1;
    `;
      const lastEntryResult = await lib.queryExecute(getLastEntryQuery);
 let entry_no;
    if (lastEntryResult.length > 0) {
      const lastEntry = lastEntryResult[0].entry_no;
   const numericMatch = String(lastEntry).match(/(\d+)$/);
   const lastNumber = numericMatch ? parseInt(numericMatch[1], 10) || 0 : 0;
   const padLength = numericMatch ? Math.max(numericMatch[1].length, 4) : 4;
   const newNumber = String(lastNumber + 1).padStart(padLength, '0');
   entry_no = `MVR${newNumber}`;
    } else {
      // console.log('No previous entries found. Starting fresh.');
      entry_no = 'MVR0001';
    }


   
    const queryStr = `
      INSERT INTO mv_rollertt_details
        (entry_no, entry_date, site_code, party_name, site_name, partner_name, machinery_name, 
         machinery_no, trip, rate, other_charges, total_amount)
      VALUES 
        ('${entry_no}', '${entry_date}', '${site_code}', '${party_name}', 
         '${site_name}', '${partner_name}', '${machinery_name}', '${machinery_no}', 
         ${numVal(trip)}, ${numVal(rate)}, ${numVal(other_charges)}, ${numVal(total_amount)})
    `;

    await lib.queryExecute(queryStr);
     console.log(queryStr,"query responce ")

    res.status(200).send({
      result: req.body,
      message: 'MV JCB Entry Added Successfully!',
      entry_no
    });
  } catch (error) {
    console.error('Error inserting MV JCB:', error);
    res.status(500).send({ message: 'Error inserting MV JCB', error });
  }
};

service.getmvrttList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = String(req.query.searchKey || '').trim();
    let searchCondition = 'is_deleted = 0';

    const allColumns = [
      'entry_no', 'entry_date', 'party_name', 'site_name',
      'machinery_name', 'machinery_no', 'trip', 'rate', 'other_charges', 
      'total_amount'
    ];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');

      searchCondition += ` AND (${searchConditions})`;
    }

    const page = Math.max(parseInt(req.query.page, 10) || 0, 0);
    const size = Math.max(parseInt(req.query.size, 10) || 10, 1);

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                    FROM mv_rollertt_details
                    WHERE ${searchCondition} 
                    ORDER BY entry_id ASC 
                    ${pageSet};`

    const countQuery = `SELECT COUNT(*) AS totalCount 
              FROM mv_rollertt_details
              WHERE ${searchCondition}`;

    const getLastEntryQuery = `
      SELECT entry_no 
      FROM mv_rollertt_details 
      WHERE ${searchCondition}
      ORDER BY entry_no DESC 
      LIMIT 1;
    `;

    const [lastEntryResult, totalCountResult, result] = await Promise.all([
      lib.queryExecute(getLastEntryQuery),
      lib.queryExecute(countQuery),
      lib.queryExecute(queryStr)
    ]);

    const lastEntryNo = lastEntryResult.length > 0 ? lastEntryResult[0].entry_no : null;
    const totalCount = Number(totalCountResult?.[0]?.totalCount || 0);

    res.set('X-Total-Count', String(totalCount));
    res.set('X-Last-Entry-No', lastEntryNo || '');
    res.status(200).send(result);

  } catch (error) {
    console.error('Error in material_entry:', error);
    res.status(500).send({ message: error.message });
  }
};

service.updateDeleteMVRTEntry = async (req, res, next) => {
  try {
    console.log('Request body:', req.body);

    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const entry_id = req.body.entry_id;

    if (changedUpdatedValue === 'edit') {
      const {
        entry_no = '',
        entry_date = '',
        site_code = '',
        party_name = '',
        site_name = '',
        partner_name = '',
        machinery_name = '',
        machinery_no = '' ,
        trip= '',
        rate = '',
        other_charges = '',
        total_amount = ''
      } = req.body;

      // Validate mandatory fields
      if (!entry_date || !party_name || !site_code || !site_name || !machinery_name || 
          !trip || !rate || !total_amount) {
        return res.status(400).send({ 
          error: 'Mandatory fields missing: Entry Date, Name of Party, Site Code, Site Name, Name of Machinery, No of Trips/Day, Rate, and Amount are required.' 
        });
      }

      const queryStr = `UPDATE mv_rollertt_details SET 
          entry_no = '${entry_no}',
          entry_date = '${entry_date}',
          site_code = '${site_code}',
          party_name = '${party_name}',
          site_name = '${site_name}',
          partner_name = '${partner_name}',
          machinery_name = '${machinery_name}',
          machinery_no = '${machinery_no}',
          trip = ${numVal(trip)},
          rate = ${numVal(rate)},
          other_charges = ${numVal(other_charges)},
          total_amount = ${numVal(total_amount)}
          WHERE entry_id = ${entry_id}`;

      console.log('Generated SQL query:', queryStr);
      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'mvjcb detials Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      const queryStr = `UPDATE mv_rollertt_details SET 
          is_deleted = 1
          WHERE entry_id = ${entry_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'mvjcb detials Deleted Successfully!' });
    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }
  } catch (error) {
    console.error('Error in mvjcb detials:', error);
    res.status(500).send({ error: error.message || error });
  }
};

module.exports = service;