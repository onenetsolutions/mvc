const lib = require('../libs/index');
let service = {};

const getNextMaterialEntryNo = async () => {
  try {
    const query = `
      SELECT entry_no 
      FROM material_entry    
      WHERE is_deleted = 0 
      AND entry_no LIKE 'MAT%'
      ORDER BY entry_no DESC 
      LIMIT 1;
    `;
    
    const result = await lib.queryExecute(query);
    
    if (result.length > 0) {
      const lastEntry = result[0].entry_no;
      const numericPart = lastEntry.substring(3); // Skip 'MAT'
      const lastNumber = parseInt(numericPart, 10);
      const newNumber = (lastNumber + 1).toString().padStart(4, '0');
      return `MAT${newNumber}`;
    } else {
      return 'MAT0001';
    }
  } catch (error) {
    console.error('Error generating next material entry no:', error);
    throw error;
  }
};


service.insertMaterialEntry = async (req, res, next) => {
  try {
    const {
      entry_date = '',
      site_code = '',
      site_name = '',
      work_name = '',
      supplier = '',
      challan_no = '',
      challan_date = '',
      material_name = '',
      quantity = '',
      unit = '',
      rate = '',
      other_charges = '0',
      remark = '',
      machinery_type = '',
      owner = '',
      start_reading = '',
      end_reading = '',
      machinery_rate = '',
      total_reading = '',
      machinery_total = '',
      deduct_charges = '',
      deduct_amout = '',
      description = '',
      partner_name = ''
    } = req.body;
  const material_details = (req.body.material_details || []);
  const no_of_trips = (req.body.no_of_trips || '');

  // Ensure quantity is integer (no decimals)
  if (quantity !== '') {
    quantity = Math.floor(Number(quantity));
  }

    // Check if this is a Machinery Entry or Material Entry
    if (machinery_type) {
      // Machinery Entry Validation
      if (!entry_date || !site_code || !owner || !machinery_type || !remark) {
        return res.status(400).send({ 
          error: 'Mandatory fields missing: Entry Date, Site Code, Machinery Owner, Machinery Type, and Remark are required for machinery entry.' 
        });
      }

      // Conditional validation based on machinery type
      if (machinery_type === 'JCB-Pokline') {
        if (!start_reading || !end_reading || !total_reading || !machinery_rate) {
          return res.status(400).send({ 
            error: 'For JCB-Pokline machinery: Start Reading, End Reading, Total Reading, and Rate are required.' 
          });
        }
      } else if (['Tractor', 'Tanker', 'Roller'].includes(machinery_type)) {
        if (!no_of_trips || !machinery_rate) {
          return res.status(400).send({ 
            error: `For ${machinery_type} machinery: No of Trips and Rate are required.` 
          });
        }
      }
    } else {
      // Material Entry Validation
      if (!entry_date || !site_code || !supplier || !remark) {
        return res.status(400).send({ 
          error: 'Mandatory fields missing: Entry Date, Site Code, Supplier, and Remark are required.' 
        });
      }

      // Validate material_details table is not empty
      if (!material_details || material_details.length === 0) {
        return res.status(400).send({ 
          error: 'Material details table is mandatory. Please add at least one material entry.' 
        });
      }
    }
    // console.log('Received Request Body:', req.body);

    // Generate next entry number using helper
    const entry_no = await getNextMaterialEntryNo();

    // Calculate total amount from material_details
    let totalAmount = 0;
    try {
      const details = Array.isArray(material_details) ? material_details : JSON.parse(material_details || '[]');
      if (Array.isArray(details)) {
        totalAmount = details.reduce((total, item) => {
          const quantity = parseFloat(item.quantity) || 0;
          const rate = parseFloat(item.rate) || 0;
          return total + (quantity * rate);
        }, 0);
      }
    } catch (error) {
      console.error('Error calculating amount from material_details:', error);
      totalAmount = 0;
    }

    const queryStr = `INSERT INTO material_entry 
      (entry_no, entry_date, site_code, site_name, work_name, 
       supplier, challan_no, challan_date, material_name, quantity, 
       unit, rate, other_charges, remark, material_details,
       machinery_type, owner, start_reading, end_reading, machinery_rate,
       total_reading, machinery_total, deduct_charges, deduct_amout, description, amount, no_of_trips, partner_name) 
      VALUES 
      ('${entry_no}', '${entry_date}', '${site_code}', 
       '${site_name}', '${work_name}', '${supplier}', 
       '${challan_no}', '${challan_date}', '${material_name}', 
       '${quantity}', '${unit}', '${rate}', '${other_charges}', 
       '${remark}', '${material_details}',
       '${machinery_type}', '${owner}', '${start_reading}', '${end_reading}',
       '${machinery_rate}', '${total_reading}', '${machinery_total}', 
       '${deduct_charges}', '${deduct_amout}', '${description}', ${totalAmount}, '${no_of_trips}', '${partner_name}')`;

    // console.log('Insert Query:', queryStr);

    await lib.queryExecute(queryStr);

    res.status(200).send({ result: req.body, message: 'Material Entry Added Successfully!', entry_no });
  } catch (error) {
    console.error('Error inserting material entry:', error);
    res.status(500).send(error);
  }
};


service.materialEntryList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = String(req.query.searchKey || '').trim();
    let searchCondition = 'is_deleted = 0';
    const machineryOnly = String(req.query.machineryOnly || '').toLowerCase() === 'true';

    if (machineryOnly) {
      searchCondition += ` AND machinery_type IS NOT NULL AND machinery_type != ''`;
    }

    const allColumns = [
      'entry_no', 'entry_date', 'site_code', 'site_name',
      'work_name', 'supplier', 'challan_no', 'challan_date', 
      'material_name', 'quantity', 'unit', 'rate', 'other_charges', 
      'amount', 'remark'
    ];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');

      searchCondition += ` AND (${searchConditions})`;
    }

    const page = Math.max(parseInt(req.query.page, 10) || 0, 0);
    const size = Math.max(parseInt(req.query.size, 10) || 10, 1);

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                    FROM material_entry
                    WHERE ${searchCondition} 
                    ORDER BY entry_date DESC, material_entry_id DESC 
                    ${pageSet};`

    const countQuery = `SELECT COUNT(*) AS totalCount 
              FROM material_entry
              WHERE ${searchCondition}`;

    const getLastEntryQuery = `
      SELECT entry_no 
      FROM material_entry 
      WHERE ${searchCondition}
      ORDER BY entry_no DESC 
      LIMIT 1;
    `;

    const [lastEntryResult, totalCountResult, result] = await Promise.all([
      lib.queryExecute(getLastEntryQuery),
      lib.queryExecute(countQuery),
      lib.queryExecute(queryStr)
    ]);

    const lastEntryNo = lastEntryResult.length > 0 ? lastEntryResult[0].entry_no : null;
    const totalCount = Number(totalCountResult?.[0]?.totalCount || 0);

    res.set('X-Total-Count', String(totalCount));
    res.set('X-Last-Entry-No', lastEntryNo || '');
    res.status(200).send(result);

  } catch (error) {
    console.error('Error in material_entry:', error);
    res.status(500).send({ message: error.message });
  }
};

service.updateDeleteMaterialEntry = async (req, res, next) => {
  try {
    console.log('Request body:', req.body);

    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const material_entry_id = req.body.material_entry_id;

    if (changedUpdatedValue === 'edit') {
      const {
        entry_no = '',
        entry_date = '',
        site_code = '',
        site_name = '',
        work_name = '',
        supplier = '',
        challan_no = '',
        challan_date = '',
        material_name = '',
        quantity = '',
        unit = '',
        rate = '',
        other_charges = '0',
        remark = '',
        material_details = [],
        machinery_type = '',
        owner = '',
        start_reading = '',
        end_reading = '',
        machinery_rate = '',
        total_reading = '',
        machinery_total = '',
        deduct_charges = '',
        deduct_amout = '',
        description = '',
        partner_name = ''
      } = req.body;
      const no_of_trips = (req.body.no_of_trips || '');

      // Check if this is a Machinery Entry or Material Entry
      if (machinery_type) {
        // Machinery Entry Validation
        if (!entry_date || !site_code || !owner || !machinery_type || !remark) {
          return res.status(400).send({ 
            error: 'Mandatory fields missing: Entry Date, Site Code, Machinery Owner, Machinery Type, and Remark are required for machinery entry.' 
          });
        }

        // Conditional validation based on machinery type
        if (machinery_type === 'JCB-Pokline') {
          if (!start_reading || !end_reading || !total_reading || !machinery_rate) {
            return res.status(400).send({ 
              error: 'For JCB-Pokline machinery: Start Reading, End Reading, Total Reading, and Rate are required.' 
            });
          }
        } else if (['Tractor', 'Tanker', 'Roller'].includes(machinery_type)) {
          if (!no_of_trips || !machinery_rate) {
            return res.status(400).send({ 
              error: `For ${machinery_type} machinery: No of Trips and Rate are required.` 
            });
          }
        }
      } else {
        // Material Entry Validation
        if (!entry_date || !site_code || !supplier || !remark) {
          return res.status(400).send({ 
            error: 'Mandatory fields missing: Entry Date, Site Code, Supplier, and Remark are required.' 
          });
        }
      }

      // Calculate total amount from material_details
      let totalAmount = 0;
      try {
        const details = Array.isArray(material_details) ? material_details : JSON.parse(material_details || '[]');
        if (Array.isArray(details)) {
          totalAmount = details.reduce((total, item) => {
            const quantity = parseFloat(item.quantity) || 0;
            const rate = parseFloat(item.rate) || 0;
            return total + (quantity * rate);
          }, 0);
        }
      } catch (error) {
        console.error('Error calculating amount from material_details:', error);
        totalAmount = 0;
      }

      const queryStr = `UPDATE material_entry SET 
          entry_no = '${entry_no}',
          entry_date = '${entry_date}',
          site_code = '${site_code}',
          site_name = '${site_name}',
          work_name = '${work_name}',
          supplier = '${supplier}',
          challan_no = '${challan_no}',
          challan_date = '${challan_date}',
          material_name = '${material_name}',
          quantity = '${quantity}',
          unit = '${unit}',
          rate = '${rate}',
          other_charges = '${other_charges}',
          remark = '${remark}',
          material_details = '${material_details}',
          machinery_type = '${machinery_type}',
          owner = '${owner}',
          start_reading = '${start_reading}',
          end_reading = '${end_reading}',
          machinery_rate = '${machinery_rate}',
          total_reading = '${total_reading}',
          machinery_total = '${machinery_total}',
          amount = ${totalAmount},
          deduct_charges = '${deduct_charges}',
          deduct_amout = '${deduct_amout}',
          description = '${description}',
          no_of_trips = '${no_of_trips}',
          partner_name = '${partner_name}'
          WHERE material_entry_id = ${material_entry_id}`;

      console.log('Generated SQL query:', queryStr);
      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Material Entry Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      const queryStr = `UPDATE material_entry SET 
          is_deleted = 1
          WHERE material_entry_id = ${material_entry_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Material Entry Deleted Successfully!' });
    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }
  } catch (error) {
    console.error('Error in updateMaterialEntry:', error);
    res.status(500).send({ error: error.message || error });
  }
};

service.getNextEntryNo = async (req, res, next) => {
  try {
    const nextEntryNo = await getNextMaterialEntryNo();
    res.status(200).send({ result: nextEntryNo, message: 'Next entry no generated successfully' });
  } catch (error) {
    console.error('Error fetching next entry no:', error);
    res.status(500).send({ error: error.message || error });
  }
};

module.exports = service;