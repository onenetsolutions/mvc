const lib = require('../libs/index');
let service = {};

// Insert a new attendance entry
service.insertAttendanceEntry = async (req, res, next) => {
  try {
    const {
      date,
      employee_name,
      employee_id,
      absent_present,
      site_code,
      in_time,
      out_time
    } = req.body;

    // Validate mandatory fields
    if (!date || !employee_name || !absent_present || !site_code) {
      return res.status(400).send({
        error: 'Mandatory fields missing: Date, Employee Name, Status, and Site Code are required.'
      });
    }

    // Step 1: Check if record already exists
    const checkQuery = `
      SELECT * FROM attendance_entry 
      WHERE employee_id = '${employee_id}' AND date = '${date}' AND is_deleted = 0
    `;
    const existingRecords = await lib.queryExecute(checkQuery);

    if (existingRecords.length > 0) {
      return res.status(400).send({
        error: 'Attendance for this employee on this date already exists. Please change employee or date.'
      });
    }

    // Step 2: Insert if not found
    const insertQuery = `
      INSERT INTO attendance_entry 
        (date, employee_name, employee_id, absent_present, site_code, in_time, out_time) 
      VALUES 
        ('${date}', '${employee_name}', '${employee_id}', '${absent_present}', '${site_code}', '${in_time || ''}', '${out_time || ''}')
    `;

    await lib.queryExecute(insertQuery);

    res.status(200).send({ result: req.body, message: 'Attendance Added Successfully!' });

  } catch (error) {
    res.status(500).send({ error: error.message || error });
  }
};


// Get the list of attendance entries
service.AttendanceEntryList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = req.query.searchKey || '';
    let searchCondition = 'is_deleted = 0';

    const allColumns = ['date', 'employee_name', 'absent_present', 'site_code'];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');

      searchCondition += ` AND (${searchConditions})`;
    }

    const page = parseInt(req.query.page, 10) || 0;
    const size = parseInt(req.query.size, 10) || 10;

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                    FROM attendance_entry
                    WHERE ${searchCondition} 
                    ORDER BY attendance_id ASC 
                    ${pageSet}`;

    const countQuery = `SELECT COUNT(*) AS totalCount 
                        FROM attendance_entry
                        WHERE is_deleted = 0`;

    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = totalCountResult[0].totalCount;

    const result = await lib.queryExecute(queryStr);

    // Include total count in the response
    const response = result.map(item => ({
      ...item,
      totalCount
    }));

    res.status(200).send(response);

  } catch (error) {
    console.error('Error in attendance_entry:', error);
    res.status(500).send({ message: error.message });
  }
};

// Update or delete attendance entry
// service.updateDeleteAttendanceEntry = async (req, res, next) => {
//   try {
//     console.log('Request body:', req.body);

//     const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
//     const attendance_id = req.body.attendance_id;

//     if (changedUpdatedValue === 'edit') {
//       const {
//         date = '',
//         employee_name = '',
//         employee_id = '',
//         absent_present = '',
//         site = '',
//         in_time = '',
//         out_time = ''
//       } = req.body;

//       const queryStr = `UPDATE attendance_entry SET 
//                 date = '${date}',
//                 employee_name = '${employee_name}',
//                 employee_id = '${employee_id}',
//                 absent_present = '${absent_present}',
//                 site = '${site}',
//                 in_time = '${in_time}',
//                 out_time = '${out_time}'
//                 WHERE attendance_id = ${attendance_id}`;

//       console.log('Generated SQL query:', queryStr);
//       await lib.queryExecute(queryStr);
//       res.status(200).send({ message: 'Attendance Updated Successfully!' });

//     } else if (changedUpdatedValue === 'delete') {
//       const queryStr = `UPDATE attendance_entry SET 
//                 is_deleted = 1
//                 WHERE attendance_id = ${attendance_id}`;

//       await lib.queryExecute(queryStr);
//       res.status(200).send({ message: 'Attendance Deleted Successfully!' });
//     } else {
//       res.status(400).send({ error: 'Invalid changed update value' });
//     }
//   } catch (error) {
//     console.error('Error in update Attendance Entry:', error);
//     res.status(500).send({ error: error.message || error });
//   }
// };
service.updateDeleteAttendanceEntry = async (req, res, next) => {
  try {
    console.log('Request body:', req.body);

    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const attendance_id = req.body.attendance_id;

    if (changedUpdatedValue === 'edit') {
      const {
        date = '',
        employee_name = '',
        employee_id = '',
        absent_present = '',
        site_code = '',
        in_time = '',
        out_time = ''
      } = req.body;

      // Validate mandatory fields
      if (!date || !employee_name || !absent_present || !site_code) {
        return res.status(400).send({
          error: 'Mandatory fields missing: Date, Employee Name, Status, and Site Code are required.'
        });
      }

      // Step 1: Check if updated record would create a duplicate
      const checkDuplicateQuery = `
        SELECT * FROM attendance_entry 
        WHERE employee_id = '${employee_id}' 
          AND date = '${date}'
          AND attendance_id != ${attendance_id} 
          AND is_deleted != 1
      `;

      const duplicateRecords = await lib.queryExecute(checkDuplicateQuery);

      if (duplicateRecords.length > 0) {
        return res.status(400).send({
          error: 'Another attendance record already exists for this employee on this date. Please choose a different date or employee.'
        });
      }

      // Step 2: Proceed with update
      const updateQuery = `
        UPDATE attendance_entry SET 
          date = '${date}',
          employee_name = '${employee_name}',
          employee_id = '${employee_id}',
          absent_present = '${absent_present}',
          site_code = '${site_code}',
          in_time = '${in_time || ''}',
          out_time = '${out_time || ''}'
        WHERE attendance_id = ${attendance_id}
      `;

      console.log('Generated SQL query:', updateQuery);
      await lib.queryExecute(updateQuery);

      res.status(200).send({ message: 'Attendance Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      const deleteQuery = `
        UPDATE attendance_entry SET 
          is_deleted = 1
        WHERE attendance_id = ${attendance_id}
      `;

      await lib.queryExecute(deleteQuery);
      res.status(200).send({ message: 'Attendance Deleted Successfully!' });

    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }

  } catch (error) {
    console.error('Error in update Attendance Entry:', error);
    res.status(500).send({ error: error.message || error });
  }
};


module.exports = service;
