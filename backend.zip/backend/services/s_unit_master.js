const lib = require('../libs/index');
let service = {};

const sqlValue = (value) => {
  if (value === undefined || value === null || value === '') {
    return 'NULL';
  }
  return `'${value}'`;
};


service.insertunitMaster = async (req, res, next) => {
  try {


    const unit_name = req.body.unit_name || '';

        const queryStr = `INSERT INTO unit_master 
          (unit_name) 
          VALUES 
          (${sqlValue(unit_name)})`;


    await lib.queryExecute(queryStr);


    res.status(200).send({ result: req.body, message: 'Added Successfully!' });
  } catch (error) {
    // Handling any errors
    res.status(500).send(error);
  }
};



service.unitMasterList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = req.query.searchKey || '';
    let searchCondition = 'is_deleted = 0';

    const allColumns = ['unit_name'];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');


      searchCondition += ` AND (${searchConditions})`;
    }

    const page = parseInt(req.query.page, 10) || 0;
    const size = parseInt(req.query.size, 10) || 10;

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                      FROM unit_master
                      WHERE ${searchCondition} 
                      ORDER BY unit_id ASC 
                      ${pageSet}`;

    const countQuery = `SELECT COUNT(*) AS totalCount 
                          FROM unit_master
                          WHERE is_deleted = 0`;

    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = totalCountResult[0].totalCount;

    const result = await lib.queryExecute(queryStr);

    // Include total count in the response
    const response = result.map(item => ({
      ...item,
      totalCount
    }));

    res.status(200).send(response);

  } catch (error) {
    console.error('Error in unit_master_List:', error);
    res.status(500).send({ message: error.message });
  }
};



// Update or delete cylinder_master entry

service.updateDeleteunitMaster = async (req, res, next) => {
    try {
        console.log('Request body:', req.body);
        
        const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
        const unit_id = req.body.unit_id;

        if (changedUpdatedValue === 'edit') {
            const {
              unit_name = ''
            } = req.body;

            const queryStr = `UPDATE unit_master SET 
              unit_name = ${sqlValue(unit_name)}
                WHERE unit_id = ${unit_id}`;

            console.log('Generated SQL query:', queryStr);
            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Updated Successfully!' });

        } else if (changedUpdatedValue === 'delete') {
            const queryStr = `UPDATE unit_master SET 
                is_deleted = 1
                WHERE unit_id = ${unit_id}`;

            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Deleted Successfully!' });
        } else {
            res.status(400).send({ error: 'Invalid changed update value' });
        }
    } catch (error) {
        console.error('Error in updateUnitMaster:', error);
        res.status(500).send({ error: error.message || error });
    }
};



module.exports = service;


