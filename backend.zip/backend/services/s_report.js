const { queryExecute } = require('../libs/dbRequest');
const exceljs = require('exceljs');
const { generatePDF: generatePuppeteerPDF, commonStyles, esc } = require('../libs/pdfGenerator');

const applyMultiLike = (sql, field, value) => {
    if (!value) return sql;
    if (Array.isArray(value)) {
        if (value.includes('All') || value.length === 0) return sql;
        const conditions = value.map(v => `${field} LIKE '%${v}%'`).join(' OR ');
        return sql + ` AND (${conditions})`;
    }
    if (value === 'All') return sql;
    return sql + ` AND ${field} LIKE '%${value}%'`;
};

// === ALL REPORT QUERIES MAPPED TO YOUR DATABASE === //
const reportQueries = {

    // 1. DASHBOARD OVERVIEW
    dashboard: async () => {
        const sql = `
            SELECT 
                (SELECT COUNT(*) FROM tender WHERE is_deleted=0) as 'Total Tenders',
                (SELECT COUNT(*) FROM work_order WHERE is_deleted=0) as 'Total Work Orders',
                (SELECT COUNT(*) FROM employee_master WHERE is_deleted=0) as 'Active Employees',
                (SELECT IFNULL(SUM(amount),0) FROM payment_entry WHERE is_deleted=0) as 'Total Payments',
                (SELECT IFNULL(SUM(amount),0) FROM daily_expenses WHERE is_deleted=0) as 'Total Expenses'
        `;
        return await queryExecute(sql);
    },

    // 2. TENDER REPORT
    tender: async ({
        from_date, to_date, department, contractor, paid_by, work_order_received
    }) => {
        const colsRes = await queryExecute(`
            SELECT COLUMN_NAME AS col 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tender'
        `);
        const has = (c) => colsRes.some(r => r.col === c);

        const selectParts = [];
        selectParts.push(has('sr_no') ? 'sr_no as sr_no' : 'NULL as sr_no');
        selectParts.push(has('entry_date') ? "DATE_FORMAT(entry_date, '%d-%m-%Y') as entry_date" : 'NULL as entry_date');
        selectParts.push(has('department_name') ? 'department_name as department' : 'NULL as department');
        selectParts.push(has('work_name') ? 'work_name as work_name' : 'NULL as work_name');
        selectParts.push(has('tender_amount') ? 'tender_amount as tender_amount' : 'NULL as tender_amount');
        selectParts.push(has('tender_id_user') ? 'tender_id_user as tender_id_user' : 'NULL as tender_id_user');
        selectParts.push(has('contractor_details') ? 'contractor_details as contractor' : 'NULL as contractor');
        selectParts.push(has('work_order_amount') ? 'work_order_amount as work_order_amount' : 'NULL as work_order_amount');
        selectParts.push(has('work_order_received')
            ? "CASE WHEN work_order_received = 1 THEN 'Yes' ELSE 'No' END as work_order_received"
            : "NULL as work_order_received");
        selectParts.push(has('tender_fee') ? 'tender_fee as tender_fee' : 'NULL as tender_fee');
        selectParts.push(has('emd_amount') ? 'emd_amount as emd_amount' : 'NULL as emd_amount');
        selectParts.push(has('paid_by') ? 'paid_by as paid_by' : 'NULL as paid_by');

        let sql = `
            SELECT 
                ${selectParts.join(',\n                ')}
            FROM tender 
            WHERE is_deleted = 0
        `;

        if (from_date && to_date && has('entry_date')) {
            sql += ` AND entry_date BETWEEN '${from_date}' AND '${to_date}'`;
        }

        if (has('department_name')) {
            sql = applyMultiLike(sql, 'department_name', department);
        }

        // Contractor filter: search inside contractor_details if available
        if (contractor && has('contractor_details')) {
            if (Array.isArray(contractor)) {
                const conditions = contractor.map(c => `contractor_details LIKE '%${c}%'`).join(' OR ');
                sql += ` AND (${conditions})`;
            } else {
                sql += ` AND contractor_details LIKE '%${contractor}%'`;
            }
        }

        // paid_by filter: prefer direct column if exists; otherwise search inside contractor_details
        if (paid_by) {
            if (has('paid_by')) {
                sql += ` AND paid_by LIKE '%${paid_by}%'`;
            } else if (has('contractor_details')) {
                sql += ` AND contractor_details LIKE '%${paid_by}%'`;
            }
        }

        if ((work_order_received === 'true' || work_order_received === true) && has('work_order_received')) {
            sql += ` AND work_order_received = 1`;
        } else if ((work_order_received === 'false' || work_order_received === false) && has('work_order_received')) {
            // sql += ` AND work_order_received = 0`;
        }

        if (has('entry_date')) {
            sql += ` ORDER BY entry_date DESC`;
        }

        const rows = await queryExecute(sql);

        // Post-process JSON fields
        return rows.map(row => {
            try {
                if (row.contractor) {
                    const parsed = JSON.parse(row.contractor);
                    if (Array.isArray(parsed)) {
                        row.contractor = parsed.map(p => p.name || p.contractor_name).join(', ');
                    }
                }
            } catch (e) { }
            return row;
        });
    },

    // 3. WORK ORDER REPORT
    workOrder: async ({
        from_date, to_date, department, contractor, work_year, work_head,
        security_refund_status, add_security_refund_status, fdr_paid_by, work_done_by
    }) => {
        let sql = `
            SELECT 
                sr_no as sr_no,
                site_code as site_code,
                site_name as site_name,
                DATE_FORMAT(work_order_date, '%d-%m-%Y') as work_order_date,
                order_year as work_year,
                department_name as department,
                contractor_name as contractor,
                agreement_no as agreement_no,
                work_order_amount as work_order_amount,
                work_head as work_head,
                security_deposit_amount as security_deposit_amount,
                security_amount_refund_status as security_amount_refund_status,
                additional_security_deposit_amount as additional_security_deposit_amount,
                additional_security_amount_refund_status as additional_security_amount_refund_status,
                security_deposit as security_deposit,
                workdone_by as work_done_by
            FROM work_order 
            WHERE is_deleted = 0
        `;

        if (from_date && to_date) sql += ` AND work_order_date BETWEEN '${from_date}' AND '${to_date}'`;

        sql = applyMultiLike(sql, 'order_year', work_year);
        sql = applyMultiLike(sql, 'department_name', department);
        sql = applyMultiLike(sql, 'contractor_name', contractor);

        if (work_head) sql += ` AND work_head LIKE '%${work_head}%'`;
        if (security_refund_status) sql += ` AND security_amount_refund_status LIKE '%${security_refund_status}%'`;
        if (add_security_refund_status) sql += ` AND additional_security_amount_refund_status LIKE '%${add_security_refund_status}%'`;
        if (work_done_by) sql += ` AND workdone_by LIKE '%${work_done_by}%'`;
        if (fdr_paid_by) sql += ` AND security_deposit LIKE '%${fdr_paid_by}%'`;

        sql += ` ORDER BY work_order_date DESC`;

        const rows = await queryExecute(sql);

        // Post-process JSON fields
        return rows.map(row => {
            try {
                if (row.security_deposit) {
                    const parsed = JSON.parse(row.security_deposit);
                    if (Array.isArray(parsed)) {
                        row.security_deposit = parsed.map(p => Object.values(p).join(' - ')).join('; ');
                    }
                }
                if (row.work_done_by && typeof row.work_done_by === 'string' && row.work_done_by.startsWith('[')) {
                    const parsed = JSON.parse(row.work_done_by);
                    if (Array.isArray(parsed)) row.work_done_by = parsed.join(', ');
                }
            } catch (e) {
                // Keep original
            }
            return row;
        });
    },

    // 4. BILL DETAILS REPORT
    billDetails: async ({ from_date, to_date, site_code, year, department, contractor, work_done_by }) => {
        let sql = `
            SELECT 
                bill_details_id as bill_id,
                site_code as site_code,
                site_name as site_name,
                order_year as year,
                DATE_FORMAT(entry_date, '%d-%m-%Y') as entry_date,
                department_name as department,
                contractor_name as contractor,
                agreement_no as agreement_no,
                work_name as work_name,
                total_bill_amount as total_bill_amount,
                deduction_amount as deduction_amount,
                net_bill_amount as net_bill_amount,
                workdone_by as work_done_by
            FROM bill_details
            WHERE is_deleted = 0
        `;

        if (from_date && to_date) sql += ` AND entry_date BETWEEN '${from_date}' AND '${to_date}'`;
        if (site_code) sql += ` AND site_code LIKE '%${site_code}%'`;

        sql = applyMultiLike(sql, 'order_year', year);
        sql = applyMultiLike(sql, 'department_name', department);
        sql = applyMultiLike(sql, 'contractor_name', contractor);

        // workdone_by is a JSON array in DB (stringified), so we search within it
        if (work_done_by) sql += ` AND workdone_by LIKE '%${work_done_by}%'`;

        const rows = await queryExecute(sql);

        // Post-process JSON fields
        return rows.map(row => {
            try {
                if (row.deduction_amount && typeof row.deduction_amount === 'string' && (row.deduction_amount.startsWith('{') || row.deduction_amount.startsWith('['))) {
                    const parsed = JSON.parse(row.deduction_amount);
                    if (Array.isArray(parsed)) {
                        row.deduction_amount = parsed.map(d => `${d.type || 'Deduction'}: ${d.amount}`).join(', ');
                    } else if (typeof parsed === 'object') {
                        row.deduction_amount = Object.entries(parsed).map(([k, v]) => `${k}: ${v}`).join(', ');
                    }
                }
                if (row.work_done_by && typeof row.work_done_by === 'string' && row.work_done_by.startsWith('[')) {
                    const parsed = JSON.parse(row.work_done_by);
                    if (Array.isArray(parsed)) row.work_done_by = parsed.join(', ');
                }
            } catch (e) {
                // Keep original
            }
            return row;
        });
    },

    // 5. DAILY EXPENSES REPORT
    dailyExpenses: async ({ from_date, to_date, site_code, voucher_no, paid_to, paid_by }) => {
        let sql = `
            SELECT 
                site_code as site_code,
                site_name as site_name,
                DATE_FORMAT(expense_date, '%d-%m-%Y') as expense_date,
                voucher_no as voucher_no,
                paid_to as paid_to,
                amount as amount,
                description as description,
                paid_by as paid_by
            FROM daily_expenses
            WHERE is_deleted = 0
        `;

        if (from_date && to_date) sql += ` AND expense_date BETWEEN '${from_date}' AND '${to_date}'`;
        if (site_code) sql += ` AND site_code LIKE '%${site_code}%'`;
        if (voucher_no) sql += ` AND voucher_no LIKE '%${voucher_no}%'`;
        if (paid_to) sql += ` AND paid_to LIKE '%${paid_to}%'`;
        if (paid_by) sql += ` AND paid_by LIKE '%${paid_by}%'`;

        return await queryExecute(sql);
    },

    // 6. CREDIT ENTRY REPORT
    creditEntry: async ({ from_date, to_date, party_name }) => {
        let sql = `
            SELECT 
                DATE_FORMAT(date, '%d-%m-%Y') as date,
                party_name as party_name,
                amount as amount,
                ref as ref,
                description as description,
                credited_to as credited_to
            FROM credit_entry
            WHERE is_deleted = 0
        `;

        if (from_date && to_date) sql += ` AND date BETWEEN '${from_date}' AND '${to_date}'`;
        if (party_name) sql += ` AND party_name LIKE '%${party_name}%'`;

        return await queryExecute(sql);
    },

    // 7. MATERIAL ENTRY REPORT
    materialEntry: async ({ from_date, to_date, site_code, supplier_name, material_name }) => {
        let sql = `
            SELECT 
                m.challan_no as challan_no,
                DATE_FORMAT(m.challan_date, '%d-%m-%Y') as challan_date,
                m.site_code as site_code,
                m.site_name as site_name,
                m.supplier as supplier_name,
                m.material_name as material_name,
                m.quantity as quantity,
                m.unit as unit,
                m.rate as rate,
                m.amount as amount,
                m.other_charges as other_charges,
                m.remark as remark
            FROM material_entry m
            WHERE m.is_deleted = 0
        `;

        if (from_date && to_date) sql += ` AND m.challan_date BETWEEN '${from_date}' AND '${to_date}'`;
        if (site_code) sql += ` AND m.site_code LIKE '%${site_code}%'`;
        if (supplier_name) sql += ` AND m.supplier LIKE '%${supplier_name}%'`;
        if (material_name) sql += ` AND m.material_name LIKE '%${material_name}%'`;

        return await queryExecute(sql);
    },

    // 8. PAYMENT ENTRY REPORT
    paymentEntry: async ({ from_date, to_date, paid_to, paid_by, mode_of_payment }) => {
        let sql = `
            SELECT 
                DATE_FORMAT(entry_date, '%d-%m-%Y') as entry_date,
                paid_to as paid_to,
                amount as amount,
                gst_amount as gst_amount,
                other_charges as other_charges,
                total_amount as total_amount,
                description as description,
                paid_by as paid_by,
                payment_mode as payment_mode
            FROM payment_entry
            WHERE is_deleted = 0
        `;

        if (from_date && to_date) sql += ` AND entry_date BETWEEN '${from_date}' AND '${to_date}'`;
        if (paid_to) sql += ` AND paid_to LIKE '%${paid_to}%'`;
        if (paid_by) sql += ` AND paid_by LIKE '%${paid_by}%'`;
        if (mode_of_payment) sql += ` AND payment_mode LIKE '%${mode_of_payment}%'`;

        return await queryExecute(sql);
    },

    // 9. BILL ADJUSTMENT REPORT
    billAdjustment: async ({ from_date, to_date, beneficiary_name, paid_by }) => {
        let sql = `
            SELECT 
                DATE_FORMAT(entry_date, '%d-%m-%Y') as entry_date,
                bank_name as bank_name,
                account_no as account_no,
                beneficiary_name as beneficiary_name,
                person_name as person_name,
                paid_by as paid_by,
                rtgs_amount as rtgs_amount,
                comission_rate as comission_rate,
                net_amount as net_amount,
                amount_received_details as amount_received_details,
                bal_amount as bal_amount
            FROM bill_adjustment
            WHERE is_deleted = 0
        `;

        if (from_date && to_date) sql += ` AND entry_date BETWEEN '${from_date}' AND '${to_date}'`;
        if (beneficiary_name) sql += ` AND beneficiary_name LIKE '%${beneficiary_name}%'`;
        if (paid_by) sql += ` AND paid_by LIKE '%${paid_by}%'`;

        return await queryExecute(sql);
    },

    // 10. SUMMARY: FINANCIAL YEAR WISE
    summaryFinancialYear: async () => {
        const sql = `
            SELECT 
                w.order_year as 'Financial Year',
                COUNT(w.work_order_id) as 'Total Works',
                IFNULL(SUM(w.work_order_amount),0) as 'Total WO Amount',
                (SELECT IFNULL(SUM(b.net_bill_amount),0) FROM bill_details b 
                 WHERE b.order_year = w.order_year AND b.is_deleted = 0) as 'Total Bill Amount'
            FROM work_order w
            WHERE w.is_deleted = 0
            GROUP BY w.order_year
            ORDER BY w.order_year DESC
        `;
        return await queryExecute(sql);
    },

    // 11. SUMMARY: CONTRACTOR WISE
    summaryContractorWise: async () => {
        const sql = `
            SELECT 
                w.contractor_name as 'Contractor Name',
                COUNT(w.work_order_id) as 'Total Works',
                IFNULL(SUM(w.work_order_amount),0) as 'Total WO Amount',
                (SELECT IFNULL(SUM(b.net_bill_amount),0) FROM bill_details b 
                 WHERE b.contractor_name = w.contractor_name AND b.is_deleted = 0) as 'Total Bill Amount'
            FROM work_order w
            WHERE w.is_deleted = 0
            GROUP BY w.contractor_name
            ORDER BY w.contractor_name ASC
        `;
        return await queryExecute(sql);
    },

    // 12. SUMMARY: DEPARTMENT WISE
    summaryDepartmentWise: async () => {
        const sql = `
            SELECT 
                w.department_name as 'Department Name',
                COUNT(w.work_order_id) as 'Total Works',
                IFNULL(SUM(w.work_order_amount),0) as 'Total WO Amount',
                (SELECT IFNULL(SUM(b.net_bill_amount),0) FROM bill_details b 
                 WHERE b.department_name = w.department_name AND b.is_deleted = 0) as 'Total Bill Amount'
            FROM work_order w
            WHERE w.is_deleted = 0
            GROUP BY w.department_name
            ORDER BY w.department_name ASC
        `;
        return await queryExecute(sql);
    },

    // 13. SUMMARY: TENDER LEDGER (All Fields with Date Range Filter)
    summaryTenderLedger: async ({ from_date, to_date }) => {
        let sql = `
            SELECT 
                sr_no as 'SR No',
                DATE_FORMAT(entry_date, '%d-%m-%Y') as 'Entry Date',
                entry_year as 'Entry Year',
                tender_id_user as 'Tender ID',
                department_name as 'Department Name',
                work_name as 'Work Name',
                tender_amount as 'Tender Amount',
                work_order_amount as 'Work Order Amount',
                DATE_FORMAT(work_time_limit, '%d-%m-%Y') as 'Work Time Limit',
                days_months as 'Days/Months',
                dlp_period as 'DLP Period',
                contractor_details as 'Contractor Details',
                CASE WHEN work_order_received = 1 THEN 'Yes' ELSE 'No' END as 'Work Order Received'
            FROM tender
            WHERE is_deleted = 0
        `;

        if (from_date && to_date) {
            sql += ` AND entry_date BETWEEN '${from_date}' AND '${to_date}'`;
        }

        sql += ` ORDER BY entry_date DESC, sr_no`;

        const rows = await queryExecute(sql);

        // Post-process JSON fields
        return rows.map(row => {
            try {
                if (row['Contractor Details']) {
                    const parsed = JSON.parse(row['Contractor Details']);
                    if (Array.isArray(parsed)) {
                        row['Contractor Details'] = parsed.map(p =>
                            `${p.name || p.contractor_name || ''} - Fee: ${p.tender_fee || 0}, EMD: ${p.emd_amount || 0}, Paid By: ${p.paid_by || ''}`
                        ).join(' | ');
                    }
                }
            } catch (e) {
                // Keep original
            }
            return row;
        });
    },

    // 14. SUMMARY: WORK ORDER LEDGER (All Fields with Date Range Filter)
    summaryWorkOrderLedger: async ({ from_date, to_date }) => {
        let sql = `
            SELECT 
                sr_no as 'SR No',
                site_code as 'Site Code',
                site_name as 'Site Name',
                DATE_FORMAT(entry_date, '%d-%m-%Y') as 'Entry Date',
                DATE_FORMAT(work_order_date, '%d-%m-%Y') as 'Work Order Date',
                order_year as 'Order Year',
                department_name as 'Department Name',
                contractor_name as 'Contractor Name',
                sub_contractor_name as 'Sub Contractor Name',
                work_name as 'Work Name',
                work_head as 'Work Head',
                workdone_by as 'Work Done By',
                agreement_no as 'Agreement No',
                work_order_no as 'Work Order No',
                work_order_amount as 'Work Order Amount',
                DATE_FORMAT(work_time_limit, '%d-%m-%Y') as 'Work Time Limit',
                dlp_period as 'DLP Period',
                security_deposit_amount as 'Security Deposit Amount',
                security_amount_refund_status as 'Security Refund Status',
                additional_security_deposit_amount as 'Additional Security Deposit Amount',
                additional_security_amount_refund_status as 'Additional Security Refund Status',
                security_deposit as 'Security Deposit Details',
                additionalsecurity_deposit as 'Additional Security Deposit Details'
            FROM work_order
            WHERE is_deleted = 0
        `;

        if (from_date && to_date) {
            sql += ` AND work_order_date BETWEEN '${from_date}' AND '${to_date}'`;
        }

        sql += ` ORDER BY work_order_date DESC, sr_no`;

        const rows = await queryExecute(sql);

        // Post-process JSON fields
        return rows.map(row => {
            try {
                if (row['Security Deposit Details']) {
                    const parsed = JSON.parse(row['Security Deposit Details']);
                    if (Array.isArray(parsed)) {
                        row['Security Deposit Details'] = parsed.map(p => Object.values(p).join(' - ')).join(' | ');
                    }
                }
                if (row['Additional Security Deposit Details']) {
                    const parsed = JSON.parse(row['Additional Security Deposit Details']);
                    if (Array.isArray(parsed)) {
                        row['Additional Security Deposit Details'] = parsed.map(p => Object.values(p).join(' - ')).join(' | ');
                    }
                }
                if (row['Work Done By'] && typeof row['Work Done By'] === 'string' && row['Work Done By'].startsWith('[')) {
                    const parsed = JSON.parse(row['Work Done By']);
                    if (Array.isArray(parsed)) row['Work Done By'] = parsed.join(', ');
                }
            } catch (e) {
                // Keep original
            }
            return row;
        });
    },

    // 15. SUMMARY: BILLS DETAIL LEDGER (All Fields with Date, FY, Supplier Filter)
    summaryBillsDetailLedger: async ({ from_date, to_date, order_year, supplier, contractor }) => {
        let sql = `
            SELECT 
                bill_details_id as 'Bill ID',
                site_code as 'Site Code',
                site_name as 'Site Name',
                DATE_FORMAT(entry_date, '%d-%m-%Y') as 'Entry Date',
                order_year as 'Order Year',
                department_name as 'Department Name',
                contractor_name as 'Contractor Name',
                sub_contractor_name as 'Sub Contractor Name',
                work_name as 'Work Name',
                bank_name as 'Bank Name',
                workdone_by as 'Work Done By',
                agreement_no as 'Agreement No',
                bill_no as 'Bill No',
                work_order_amount as 'Work Order Amount',
                total_bill_amount as 'Total Bill Amount',
                deduction_amount as 'Deduction Amount',
                net_bill_amount as 'Net Bill Amount',
                description as 'Description',
                remark as 'Remark'
            FROM bill_details
            WHERE is_deleted = 0
        `;

        if (from_date && to_date) {
            sql += ` AND entry_date BETWEEN '${from_date}' AND '${to_date}'`;
        }

        if (order_year) {
            sql = applyMultiLike(sql, 'order_year', order_year);
        }

        if (supplier || contractor) {
            // Bill details uses contractor_name field
            sql = applyMultiLike(sql, 'contractor_name', contractor || supplier);
        }

        sql += ` ORDER BY entry_date DESC, bill_details_id`;

        const rows = await queryExecute(sql);

        // Post-process JSON fields
        return rows.map(row => {
            try {
                if (row['Deduction Amount'] && typeof row['Deduction Amount'] === 'string' &&
                    (row['Deduction Amount'].startsWith('{') || row['Deduction Amount'].startsWith('['))) {
                    const parsed = JSON.parse(row['Deduction Amount']);
                    if (Array.isArray(parsed)) {
                        row['Deduction Amount'] = parsed.map(d => `${d.type || 'Deduction'}: ${d.amount}`).join(', ');
                    } else if (typeof parsed === 'object') {
                        row['Deduction Amount'] = Object.entries(parsed).map(([k, v]) => `${k}: ${v}`).join(', ');
                    }
                }
                if (row['Work Done By'] && typeof row['Work Done By'] === 'string' && row['Work Done By'].startsWith('[')) {
                    const parsed = JSON.parse(row['Work Done By']);
                    if (Array.isArray(parsed)) row['Work Done By'] = parsed.join(', ');
                }
            } catch (e) {
                // Keep original
            }
            return row;
        });
    },

    // 16. SUMMARY: MATERIAL ENTRY LEDGER (All Fields with Date, FY, Supplier Filter)
    summaryMaterialEntryLedger: async ({ from_date, to_date, supplier }) => {
        let sql = `
            SELECT 
                material_entry_id as 'Material Entry ID',
                entry_no as 'Entry No',
                DATE_FORMAT(entry_date, '%d-%m-%Y') as 'Entry Date',
                site_code as 'Site Code',
                site_name as 'Site Name',
                work_name as 'Work Name',
                supplier as 'Supplier',
                challan_no as 'Challan No',
                DATE_FORMAT(challan_date, '%d-%m-%Y') as 'Challan Date',
                material_name as 'Material Name',
                quantity as 'Quantity',
                unit as 'Unit',
                rate as 'Rate',
                material_details as 'Material Details',
                other_charges as 'Other Charges',
                amount as 'Amount',
                remark as 'Remark'
            FROM material_entry
            WHERE is_deleted = 0 
            AND (machinery_type IS NULL OR machinery_type = '')
        `;

        if (from_date && to_date) {
            sql += ` AND entry_date BETWEEN '${from_date}' AND '${to_date}'`;
        }

        if (supplier) {
            sql = applyMultiLike(sql, 'supplier', supplier);
        }

        sql += ` ORDER BY entry_date DESC, material_entry_id`;

        const rows = await queryExecute(sql);

        // Post-process JSON fields
        return rows.map(row => {
            try {
                if (row['Material Details'] && typeof row['Material Details'] === 'string' && row['Material Details'].startsWith('[')) {
                    const parsed = JSON.parse(row['Material Details']);
                    if (Array.isArray(parsed)) {
                        row['Material Details'] = parsed.map(m =>
                            `${m.material_name || ''}: ${m.quantity || 0} ${m.unit || ''} @ ${m.rate || 0}`
                        ).join(' | ');
                    }
                }
            } catch (e) {
                // Keep original
            }
            return row;
        });
    },

    // 17. SUMMARY: PAYMENT ENTRY LEDGER (All Fields with Date and Paid To Filter)
    summaryPaymentEntryLedger: async ({ from_date, to_date, paid_to }) => {
        let sql = `
            SELECT 
                payment_entry_id as 'Payment Entry ID',
                DATE_FORMAT(entry_date, '%d-%m-%Y') as 'Entry Date',
                paid_to as 'Paid To',
                description as 'Description',
                amount as 'Amount',
                gst_amount as 'GST Amount',
                other_charges as 'Other Charges',
                total_amount as 'Total Amount',
                payment_mode as 'Payment Mode',
                sub_payment_mode as 'Sub Payment Mode',
                beneficiary_name as 'Beneficiary Name',
                paid_by as 'Paid By',
                bank_name as 'Bank Name',
                account_name as 'Account Name',
                reference as 'Reference',
                remarks as 'Remarks'
            FROM payment_entry
            WHERE is_deleted = 0
        `;

        if (from_date && to_date) {
            sql += ` AND entry_date BETWEEN '${from_date}' AND '${to_date}'`;
        }

        if (paid_to) {
            sql = applyMultiLike(sql, 'paid_to', paid_to);
        }

        sql += ` ORDER BY entry_date DESC, payment_entry_id`;

        return await queryExecute(sql);
    },

    // 18. SUMMARY: BILL ADJUSTMENT LEDGER (All Fields with Date Filter)
    summaryBillAdjustmentLedger: async ({ from_date, to_date }) => {
        let sql = `
            SELECT 
                bill_adjustment_id as 'Bill Adjustment ID',
                DATE_FORMAT(entry_date, '%d-%m-%Y') as 'Entry Date',
                bank_name as 'Bank Name',
                account_no as 'Account No',
                beneficiary_name as 'Beneficiary Name',
                person_name as 'Person Name',
                paid_by as 'Paid By',
                rtgs_amount as 'RTGS Amount',
                comission_rate as 'Commission Rate',
                net_amount as 'Net Amount',
                amount_received_details as 'Amount Received Details',
                bal_amount as 'Balance Amount'
            FROM bill_adjustment
            WHERE is_deleted = 0
        `;

        if (from_date && to_date) {
            sql += ` AND entry_date BETWEEN '${from_date}' AND '${to_date}'`;
        }

        sql += ` ORDER BY entry_date DESC, bill_adjustment_id`;

        const rows = await queryExecute(sql);

        // Post-process JSON fields
        return rows.map(row => {
            try {
                if (row['Amount Received Details'] && typeof row['Amount Received Details'] === 'string' && row['Amount Received Details'].startsWith('[')) {
                    const parsed = JSON.parse(row['Amount Received Details']);
                    if (Array.isArray(parsed)) {
                        row['Amount Received Details'] = parsed.map(d =>
                            `SR ${d.sr_no || d.srno || ''}: ₹${d.received_amount || 0} on ${d.received_date || ''} - ${d.remarks || ''}`
                        ).join(' | ');
                    }
                }
            } catch (e) {
                // Keep original
            }
            return row;
        });
    }
};

// === SERVICE METHODS === //
const getReportData = async (type, filters, columns = []) => {
    if (!reportQueries[type]) {
        throw new Error(`Report type '${type}' not found`);
    }
    const data = await reportQueries[type](filters || {});
    if (Array.isArray(columns) && columns.length > 0 && Array.isArray(data)) {
        return data.map(row => {
            const filtered = {};
            columns.forEach(col => {
                if (Object.prototype.hasOwnProperty.call(row, col)) {
                    filtered[col] = row[col];
                }
            });
            return filtered;
        });
    }
    return data;
};

const formatFilterDate = (dateStr) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
};

const formatFilterLabel = (key) => {
    return key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
};

const generateExcel = async (type, data, res, columns = [], filters = {}) => {
    const workbook = new exceljs.Workbook();
    const worksheet = workbook.addWorksheet('Report');

    const headers = (Array.isArray(columns) && columns.length > 0)
        ? columns
        : (data.length > 0 ? Object.keys(data[0]) : []);

    // Page setup: landscape and fit to page
    worksheet.pageSetup = {
        orientation: 'landscape',
        fitToPage: true,
        fitToWidth: 1,
        fitToHeight: 1,
        margins: { left: 0.3, right: 0.3, top: 0.5, bottom: 0.5, header: 0.2, footer: 0.2 }
    };

    // Helper to convert index to Excel column letter
    const toColLetter = (num) => {
        let s = '';
        while (num > 0) {
            let mod = (num - 1) % 26;
            s = String.fromCharCode(65 + mod) + s;
            num = Math.floor((num - mod) / 26);
        }
        return s || 'A';
    };

    const lastCol = toColLetter(headers.length || 1);
    const title = String(type || 'Report')
        .replace(/[_-]/g, ' ')
        .replace(/\b\w/g, (c) => c.toUpperCase());

    // Title row (merged)
    const titleRow = worksheet.addRow([title]);
    worksheet.mergeCells(`A1:${lastCol}1`);
    titleRow.font = { size: 16, bold: true };
    titleRow.alignment = { vertical: 'middle', horizontal: 'center' };
    titleRow.height = 24;

    // Filter info rows
    let currentRow = 2;

    // From / To dates
    if (filters.from_date || filters.to_date) {
        const dateRow = worksheet.addRow([`From: ${formatFilterDate(filters.from_date) || '-'}          To: ${formatFilterDate(filters.to_date) || '-'}`]);
        worksheet.mergeCells(`A${currentRow}:${lastCol}${currentRow}`);
        dateRow.font = { size: 11, bold: true };
        dateRow.alignment = { vertical: 'middle', horizontal: 'center' };
        currentRow++;
    }

    // Other applied filters
    const filterEntries = Object.entries(filters).filter(([key, value]) => {
        if (key === 'from_date' || key === 'to_date') return false;
        if (!value || (Array.isArray(value) && value.length === 0)) return false;
        return true;
    });
    if (filterEntries.length > 0) {
        const filterTexts = filterEntries.map(([key, value]) => {
            const label = formatFilterLabel(key);
            const displayVal = Array.isArray(value) ? value.join(', ') : value;
            return `${label}: ${displayVal}`;
        });
        const filterRow = worksheet.addRow([filterTexts.join('    |    ')]);
        worksheet.mergeCells(`A${currentRow}:${lastCol}${currentRow}`);
        filterRow.font = { size: 10, italic: true };
        filterRow.alignment = { vertical: 'middle', horizontal: 'center' };
        currentRow++;
    }

    // Generated on date
    const subRow = worksheet.addRow([`Generated on: ${new Date().toLocaleDateString('en-GB')}`]);
    worksheet.mergeCells(`A${currentRow}:${lastCol}${currentRow}`);
    subRow.font = { size: 10, italic: true, color: { argb: 'FF666666' } };
    subRow.alignment = { vertical: 'middle', horizontal: 'center' };
    currentRow++;

    // Header row
    const headerRow = worksheet.addRow(headers);
    headerRow.font = { bold: true, color: { argb: 'FF000000' } };
    headerRow.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    headerRow.height = 18;
    headerRow.eachCell((cell) => {
        cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFE8EEF7' }
        };
        cell.border = {
            top: { style: 'thin', color: { argb: 'FFB0B0B0' } },
            left: { style: 'thin', color: { argb: 'FFB0B0B0' } },
            bottom: { style: 'thin', color: { argb: 'FFB0B0B0' } },
            right: { style: 'thin', color: { argb: 'FFB0B0B0' } }
        };
    });

    // Data rows
    data.forEach((rowObj, idx) => {
        const rowValues = headers.map(h => rowObj[h]);
        const row = worksheet.addRow(rowValues);
        row.alignment = { vertical: 'middle' };
        // zebra striping
        if (idx % 2 === 1) {
            row.eachCell((cell) => {
                cell.fill = {
                    type: 'pattern',
                    pattern: 'solid',
                    fgColor: { argb: 'FFF9FBFD' }
                };
            });
        }
        // borders
        row.eachCell((cell) => {
            cell.border = {
                top: { style: 'thin', color: { argb: 'FFE0E0E0' } },
                left: { style: 'thin', color: { argb: 'FFE0E0E0' } },
                bottom: { style: 'thin', color: { argb: 'FFE0E0E0' } },
                right: { style: 'thin', color: { argb: 'FFE0E0E0' } }
            };
        });
    });

    // Column widths auto-ish
    headers.forEach((h, i) => {
        let maxLen = Math.max(h.length, ...data.map(r => String(r[h] ?? '').length));
        worksheet.getColumn(i + 1).width = Math.min(Math.max(maxLen + 4, 12), 40);
    });

    // Freeze top rows (title + subtitle + headers)
    worksheet.views = [{ state: 'frozen', ySplit: currentRow }];

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=${title.replace(/\s+/g, '_')}.xlsx`);

    await workbook.xlsx.write(res);
    res.end();
};

const generatePDF = async (type, data, res, columns = [], filters = {}) => {
    const title = String(type || 'Report')
        .replace(/[_-]/g, ' ')
        .replace(/\b\w/g, (c) => c.toUpperCase());

    const headers = (Array.isArray(columns) && columns.length > 0)
        ? columns
        : (data && data.length > 0 ? Object.keys(data[0]) : []);

    // Build filter info HTML
    let filterHtml = '';
    if (filters.from_date || filters.to_date) {
        filterHtml += `<div class="report-subtitle">From: ${formatFilterDate(filters.from_date) || '-'} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; To: ${formatFilterDate(filters.to_date) || '-'}</div>`;
    }
    const filterEntries = Object.entries(filters).filter(([key, value]) => {
        if (key === 'from_date' || key === 'to_date') return false;
        if (!value || (Array.isArray(value) && value.length === 0)) return false;
        return true;
    });
    if (filterEntries.length > 0) {
        filterHtml += filterEntries.map(([key, value]) => {
            const label = formatFilterLabel(key);
            const displayVal = Array.isArray(value) ? value.join(', ') : value;
            return `<div class="report-subtitle">${esc(label)}: ${esc(String(displayVal))}</div>`;
        }).join('');
    }

    const html = `<!DOCTYPE html><html><head><style>
      ${commonStyles}
      table { font-size: ${headers.length > 15 ? '6px' : headers.length > 10 ? '7px' : headers.length > 6 ? '8px' : '9px'}; }
      th, td { padding: ${headers.length > 10 ? '2px 3px' : '4px 6px'}; word-break: break-word; }
    </style></head><body>
      <div class="report-title">${esc(title)}</div>
      ${filterHtml}
      <div class="report-subtitle">Generated on: ${new Date().toLocaleDateString('en-GB')}</div>
      ${!data || data.length === 0 ? '<div class="no-data">No data available for the selected filters.</div>' : `
      <table>
        <thead><tr>${headers.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead>
        <tbody>
          ${data.map((row, idx) => `<tr>${headers.map(h => `<td>${esc(String(row[h] || ''))}</td>`).join('')}</tr>`).join('')}
        </tbody>
      </table>
      <div class="total-records">Total Records: ${data.length}</div>`}
    </body></html>`;

    const filename = `${title.replace(/\s+/g, '_')}.pdf`;
    await generatePuppeteerPDF(html, res, filename, { layout: 'landscape' });
};

module.exports = { getReportData, generateExcel, generatePDF };
