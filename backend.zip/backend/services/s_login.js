
const auth = require('../libs/auth');
const lib = require('../libs/index');
let service = {};

const bcrypt = require('bcryptjs');

service.login = async (req, res, next) => {
    try {
        // Destructure the incoming fields from frontend
        const { userName, loginPassword } = req.body;

        // Validate user input
        if (!userName || userName === "") throw "User name cannot be empty";
        if (!loginPassword || loginPassword === "") throw "Login Password cannot be empty";

        // Use parameterized query to prevent SQL injection
        const queryStr = `SELECT user_name, user_id, password, role FROM user_master WHERE user_name = ?`;
        
        // Get connection pool for parameterized queries
        const pool = await require('../libs/dbConnection').initConnection();
        const [result] = await pool.query(queryStr, [userName]);

        // If no result, send response with user not found message
        if (result.length === 0) {
            console.log("User not found");
            return res.status(200).send({
                result: null,
                message: "User not found"
            });
        }

        // Check if password matches (using bcrypt compare)
        console.log("Checking password for user:", userName);
        const isPasswordValid = await bcrypt.compare(loginPassword, result[0].password);

        if (isPasswordValid && userName === result[0].user_name) {
            // Log success and generate the token
            console.log("Password matches, generating token...");
            let authToken = await lib.sign(result[0]);

            console.log("Login successful, returning token and user info");
            res.status(200).send({
                result: { authToken, userInfo: { ...result[0] } },
                message: "User found and login successful"
            });
        } else {
            console.log("Invalid username or password");
            return res.status(200).send({
                result: null,
                message: "Invalid username or password"
            });
        }
    } catch (error) {
        // Catch any other errors
        console.error("Unexpected error:", error);
        res.status(500).send({
            result: null,
            message: error.message || error
        });
    }
};





// service.login = (req, res, next) => {
//     try {
//         // Destructure the incoming fields from frontend
//         const { userName, loginPassword } = req.body;

//         // Validate user input
//         if (!userName || userName === "") throw "User name cannot be empty";
//         if (!loginPassword || loginPassword === "") throw "Login Password cannot be empty";

//         // Map frontend fields to database column names
//         const dbUserName = userName;
//         const dbPassword = loginPassword;

//         // Dynamically construct the query string using the correct DB column name
//         let queryStr = `SELECT user_name,user_id, password, role FROM user_master WHERE user_name = '${dbUserName}'`;

//         // Log the query string for debugging
//         console.log("Generated login query:", queryStr);

//         // Execute the query
//         lib.queryExecute(queryStr)
//             .then(async result => {
//                 // Log the result of the query
//                 console.log("Query result:", result);

//                 // If no result, send response with user not found message
//                 if (result.length === 0) {
//                     console.log("User not found");
//                     return res.status(200).send({
//                         result: null,
//                         message: "User not found"
//                     });
//                 }

//                 // Check if password matches (using bcrypt compare)
//                 console.log("Checking password for user:", dbUserName);
//                 const isPasswordValid = await bcrypt.compare(dbPassword, result[0].password);

//                 if (isPasswordValid && dbUserName === result[0].user_name) {
//                     // Log success and generate the token
//                     console.log("Password matches, generating token...");
//                     let authToken = await lib.sign(result[0]);

//                     // Invalidate previous sessions (if any)
//                     console.log("Invalidating previous sessions...");
//                     let invalidateOldSessionsQuery = `UPDATE sessions SET status = 'inactive', logout_time = NOW() WHERE user_id = ${result[0].user_id} AND status = 'active'`;
//                     await lib.queryExecute(invalidateOldSessionsQuery);

//                     // Create a new session
//                     console.log("Creating a new session...");
//                     let insertSessionQuery = `
//                         INSERT INTO sessions (user_id, session_token, login_time, status)
//                         VALUES (${result[0].user_id}, '${authToken}', NOW(), 'active')
//                     `;
//                     await lib.queryExecute(insertSessionQuery);

//                     console.log("Login successful, returning token and user info");
//                     res.status(200).send({
//                         result: { authToken, userInfo: { ...result[0] } },
//                         message: "User found and login successful"
//                     });
//                 } else {
//                     console.log("Invalid username or password");
//                     res.status(200).send({
//                         result: null,
//                         message: "Invalid username or password"
//                     });
//                 }
//             })
//             .catch(e => {
//                 // Log error if query fails
//                 console.error("Error executing query:", e);
//                 res.status(500).send({
//                     result: null,
//                     message: e.message
//                 });
//             });
//     } catch (error) {
//         res.status(500).send({
//             result: null,
//             message: error
//         });
//         console.error("Unexpected error:", error);
//     }
// };




service.logout = async (req, res, next) => {
    try {
        // For stateless JWT, logout is handled on the client side
        // The server just returns a success message
        console.log("Logout successful");
        res.status(200).send({
            result: { message: "Logged out successfully" },
            message: "You have successfully logged out."
        });
    } catch (error) {
        console.error("Unexpected error during logout:", error);
        res.status(500).send({
            result: null,
            message: error.message || error
        });
    }
}

// service.logout = (req, res, next) => {
//     console.log("Logout function triggered");  // Add this log to check if it's called
//     try {
//         const { token } = req.body;

//         if (!token) {
//             return res.status(400).send({
//                 result: null,
//                 message: "Token is required for logout"
//             });
//         }

//         // Validate the token
//         let decodedToken = auth.verify(token);

//         if (!decodedToken) {
//             return res.status(400).send({
//                 result: null,
//                 message: "Invalid or expired token"
//             });
//         }

//         // Check if the session exists
//         let checkSessionQuery = `SELECT * FROM sessions WHERE session_token = '${token}'`;

//         console.log("Checking session with token:", token);  // Added logging

//         lib.queryExecute(checkSessionQuery)
//             .then((sessionData) => {
//                 console.log("Session data:", sessionData);  // Added logging
//                 if (sessionData.length === 0) {
//                     console.log("No active session found");  // Added logging
//                     return res.status(400).send({
//                         result: null,
//                         message: "No session found"
//                     });
//                 }

//                 console.log("Session found, logging out...");  // Added logging
//                 // Proceed to update the session status and logout time
//                 let logoutQuery = `UPDATE sessions SET status = 'inactive', logout_time = NOW() WHERE session_token = '${token}'`;

//                 return lib.queryExecute(logoutQuery);
//             })
//             .then(() => {
//                 console.log("Logout successful");  // Added logging
//                 res.status(200).send({
//                     result: { message: "Logged out successfully" },
//                     message: "You have successfully logged out."
//                 });
//             })
//             .catch((e) => {
//                 console.error("Error during logout:", e);  // Added error logging
//                 res.status(500).send({
//                     result: null,
//                     message: e.message
//                 });
//             });
//     } catch (error) {
//         console.error("Unexpected error during logout:", error);  // Added error logging
//         res.status(500).send({
//             result: null,
//             message: error
//         });
//     }
// };








module.exports = service;
