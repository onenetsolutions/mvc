const lib = require('../libs/index');
let service = {};

const sqlValue = (value) => {
  if (value === undefined || value === null || value === '') {
    return 'NULL';
  }
  return `'${value}'`;
};


service.insertpartnerMaster = async (req, res, next) => {
  try {


        const partner_name = req.body.partner_name || '';
        const mobile_no = req.body.mobile_no || '';

    const queryStr = `INSERT INTO partner_master 
          (partner_name,mobile_no) 
          VALUES 
          (${sqlValue(partner_name)},${sqlValue(mobile_no)})`;


    await lib.queryExecute(queryStr);


    res.status(200).send({ result: req.body, message: 'Added Successfully!' });
  } catch (error) {
    // Handling any errors
    res.status(500).send(error);
  }
};



service.partnerMasterList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = req.query.searchKey || '';
    let searchCondition = 'is_deleted = 0';

    const allColumns = ['partner_name','mobile_no'];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');


      searchCondition += ` AND (${searchConditions})`;
    }

    const page = parseInt(req.query.page, 10) || 0;
    const size = parseInt(req.query.size, 10) || 10;

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                      FROM partner_master
                      WHERE ${searchCondition} 
                      ORDER BY partner_id ASC 
                      ${pageSet}`;

    const countQuery = `SELECT COUNT(*) AS totalCount 
                          FROM partner_master
                          WHERE is_deleted = 0`;

    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = totalCountResult[0].totalCount;

    const result = await lib.queryExecute(queryStr);

    // Include total count in the response
    const response = result.map(item => ({
      ...item,
      totalCount
    }));

    res.status(200).send(response);

  } catch (error) {
    console.error('Error in partner_master:', error);
    res.status(500).send({ message: error.message });
  }
};



// Update or delete cylinder_master entry

service.updateDeletepartnerMaster = async (req, res, next) => {
    try {
        console.log('Request body:', req.body);
        
        const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
        const partner_id = req.body.partner_id;

        if (changedUpdatedValue === 'edit') {
            const {
              partner_name = '',
              mobile_no = ''
            } = req.body;

            const queryStr = `UPDATE partner_master SET 
              partner_name = ${sqlValue(partner_name)},
              mobile_no = ${sqlValue(mobile_no)}
                WHERE partner_id = ${partner_id}`;

            console.log('Generated SQL query:', queryStr);
            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Updated Successfully!' });

        } else if (changedUpdatedValue === 'delete') {
            const queryStr = `UPDATE partner_master SET 
                is_deleted = 1
                WHERE partner_id = ${partner_id}`;

            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Deleted Successfully!' });
        } else {
            res.status(400).send({ error: 'Invalid changed update value' });
        }
    } catch (error) {
        console.error('Error in updatePartnerMaster:', error);
        res.status(500).send({ error: error.message || error });
    }
};



module.exports = service;


