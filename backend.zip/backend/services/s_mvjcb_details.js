const lib = require('../libs/index');
let service = {};

const numVal = (v) => (v === '' || v === null || v === undefined) ? 'NULL' : v;

// Convert "HH:MM" time string to decimal hours (e.g., "12:31" -> 12.52)
const timeToDecimal = (timeStr) => {
  if (!timeStr || typeof timeStr !== 'string' || !timeStr.includes(':')) return timeStr;
  const [h, m] = timeStr.split(':').map(Number);
  return (h + m / 60).toFixed(2);
};

// Convert decimal hours back to "HH:MM" string (e.g., 12.52 -> "12:31")
const decimalToTime = (decimal) => {
  if (decimal === null || decimal === undefined || decimal === '') return '';
  const num = parseFloat(decimal);
  if (isNaN(num)) return decimal;
  const h = Math.floor(num);
  const m = Math.round((num - h) * 60);
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
};


service.insertMvJCB = async (req, res, next) => {
  try {
    const {
      entry_date = '',
      site_code = '',
      party_name = '',
      site_name = '',
      partner_name = '',
      start_reading= '',
      end_reading = '',
      total_reading= '',
      rate = '',
      other_charges = '',
      total_amount = '',
    } = req.body;
    // Validate mandatory fields
    if (!entry_date || !party_name || !site_code || !site_name || !start_reading || 
        !end_reading || !total_reading || !rate || !total_amount) {
      return res.status(400).send({ 
        error: 'Mandatory fields missing: Entry Date, Name of Party, Site Code, Site Name, Start Reading, End Reading, Total Hours, Rate, and Amount are required.' 
      });
    }
 

      const getLastEntryQuery = `
      SELECT entry_no 
      FROM mvjcb_detials    
      WHERE is_deleted = 0 
      AND entry_no LIKE 'MVJ%'
      ORDER BY entry_no DESC 
      LIMIT 1;
    `;
      const lastEntryResult = await lib.queryExecute(getLastEntryQuery);
 let entry_no;
    if (lastEntryResult.length > 0) {
      const lastEntry = lastEntryResult[0].entry_no;
      // console.log('Last entry_no from DB:', lastEntry);

      const numericPart = lastEntry.substring(3); // Should skip 'MAT'
      // console.log('Extracted numeric part:', numericPart);

      const lastNumber = parseInt(numericPart, 10);
      // console.log('Parsed last number:', lastNumber);

      const newNumber = (lastNumber + 1).toString().padStart(4, '0');
      // console.log('Generated new number:', newNumber);

      entry_no = `MVJ${newNumber}`;
    } else {
      // console.log('No previous entries found. Starting fresh.');
      entry_no = 'MVJ0001';
    }


   
    const queryStr = `
      INSERT INTO mvjcb_detials
        (entry_no, entry_date, site_code, party_name, site_name, partner_name, start_reading, 
         end_reading, total_reading, rate, other_charges, total_amount)
      VALUES 
        ('${entry_no}', '${entry_date}', '${site_code}', '${party_name}', 
         '${site_name}', '${partner_name}', '${start_reading}', '${end_reading}', 
         ${numVal(total_reading)}, ${numVal(rate)}, ${numVal(other_charges)}, ${numVal(total_amount)})
    `;

    await lib.queryExecute(queryStr);
     console.log(queryStr,"query responce ")

    res.status(200).send({
      result: req.body,
      message: 'MV JCB Entry Added Successfully!',
      entry_no
    });
  } catch (error) {
    console.error('Error inserting MV JCB:', error);
    res.status(500).send({ message: 'Error inserting MV JCB', error });
  }
};

service.getmvjcbList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = String(req.query.searchKey || '').trim();
    let searchCondition = 'is_deleted = 0';

    const allColumns = [
      'entry_no', "DATE_FORMAT(entry_date, '%d %m %Y')", 'party_name', 'site_name',
      'start_reading', 'end_reading', 'total_reading', 'rate', 'other_charges',
      'total_amount'
    ];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');

      searchCondition += ` AND (${searchConditions})`;
    }

    const page = Math.max(parseInt(req.query.page, 10) || 0, 0);
    const size = Math.max(parseInt(req.query.size, 10) || 10, 1);

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT
                      entry_id,
                      entry_no,
                      DATE_FORMAT(entry_date, '%Y-%m-%d') AS entry_date,
                      site_code,
                      party_name,
                      site_name,
                      partner_name,
                      start_reading,
                      end_reading,
                      total_reading,
                      rate,
                      other_charges,
                      total_amount,
                      is_deleted
                    FROM mvjcb_detials
                    WHERE ${searchCondition}
                    ORDER BY entry_id ASC
                    ${pageSet};`

    const countQuery = `SELECT COUNT(*) AS totalCount 
              FROM mvjcb_detials
              WHERE ${searchCondition}`;

    const getLastEntryQuery = `
      SELECT entry_no 
      FROM mvjcb_detials 
      WHERE ${searchCondition}
      ORDER BY entry_no DESC 
      LIMIT 1;
    `;

    const [lastEntryResult, totalCountResult, result] = await Promise.all([
      lib.queryExecute(getLastEntryQuery),
      lib.queryExecute(countQuery),
      lib.queryExecute(queryStr)
    ]);

    const lastEntryNo = lastEntryResult.length > 0 ? lastEntryResult[0].entry_no : null;
    const totalCount = Number(totalCountResult?.[0]?.totalCount || 0);

    res.set('X-Total-Count', String(totalCount));
    res.set('X-Last-Entry-No', lastEntryNo || '');
    res.status(200).send(result);

  } catch (error) {
    console.error('Error in material_entry:', error);
    res.status(500).send({ message: error.message });
  }
};

service.updateDeleteMVjcbEntry = async (req, res, next) => {
  try {
    console.log('Request body:', req.body);

    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const entry_id = req.body.entry_id;

    if (changedUpdatedValue === 'edit') {
      const {
        entry_no = '',
        entry_date = '',
        site_code = '',
        party_name = '',
        site_name = '',
        partner_name = '',
        start_reading = '',
        end_reading = '' ,
        total_reading = '',
        rate = '',
        other_charges = '',
        total_amount = ''
      } = req.body;

      // Validate mandatory fields
      if (!entry_date || !party_name || !site_code || !site_name || !start_reading || 
          !end_reading || !total_reading || !rate || !total_amount) {
        return res.status(400).send({ 
          error: 'Mandatory fields missing: Entry Date, Name of Party, Site Code, Site Name, Start Reading, End Reading, Total Hours, Rate, and Amount are required.' 
        });
      }

      const queryStr = `UPDATE mvjcb_detials SET 
          entry_no = '${entry_no}',
          entry_date = '${entry_date}',
          site_code = '${site_code}',
          party_name = '${party_name}',
          site_name = '${site_name}',
          partner_name = '${partner_name}',
          start_reading = '${start_reading}',
          end_reading = '${end_reading}',
          total_reading = ${numVal(total_reading)},
          rate = ${numVal(rate)},
          other_charges = ${numVal(other_charges)},
          total_amount = ${numVal(total_amount)}
          WHERE entry_id = ${entry_id}`;

      console.log('Generated SQL query:', queryStr);
      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'mvjcb detials Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      const queryStr = `UPDATE mvjcb_detials SET 
          is_deleted = 1
          WHERE entry_id = ${entry_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'mvjcb detials Deleted Successfully!' });
    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }
  } catch (error) {
    console.error('Error in mvjcb detials:', error);
    res.status(500).send({ error: error.message || error });
  }
};

module.exports = service;