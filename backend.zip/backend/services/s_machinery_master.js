const lib = require('../libs/index');
let service = {};

const sqlValue = (value) => {
  if (value === undefined || value === null || value === '') {
    return 'NULL';
  }
  return `'${value}'`;
};

// Insert machinery master entry
service.insertMachineryMaster = async (req, res, next) => {
  try {
    const {
      machinery_name = '',
      machinery_type = '',
      owner_name = '',
      rto_no = '',
      engine_no = '',
      chassis_no = '',
      insurance_company = '',
      insurance_policy_no = '',
      insurance_start_date = '',
      insurance_expiry_date = '',
      tax_valid_upto = '',
      pucc_valid_upto = '',
      permit_valid_upto = '',
      fitness_valid_upto = '',
      operator_name = ''
    } = req.body;

    const queryStr = `INSERT INTO machinery_master 
      (machinery_name, machinery_type, owner_name, rto_no, engine_no, chassis_no, 
       insurance_company, insurance_policy_no, insurance_start_date, 
       insurance_expiry_date, tax_valid_upto, pucc_valid_upto, 
       permit_valid_upto, fitness_valid_upto, operator_name) 
      VALUES 
      (${sqlValue(machinery_name)}, ${sqlValue(machinery_type)}, ${sqlValue(owner_name)}, ${sqlValue(rto_no)}, ${sqlValue(engine_no)}, 
       ${sqlValue(chassis_no)}, ${sqlValue(insurance_company)}, ${sqlValue(insurance_policy_no)}, 
       ${sqlValue(insurance_start_date)}, 
       ${sqlValue(insurance_expiry_date)}, 
       ${sqlValue(tax_valid_upto)}, 
       ${sqlValue(pucc_valid_upto)}, 
       ${sqlValue(permit_valid_upto)}, 
       ${sqlValue(fitness_valid_upto)}, 
       ${sqlValue(operator_name)})`;

    await lib.queryExecute(queryStr);

    res.status(200).send({ result: req.body, message: 'Machinery Added Successfully!' });
  } catch (error) {
    res.status(500).send(error);
  }
};


service.machineryMasterList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = req.query.searchKey || '';
    let searchCondition = 'is_deleted = 0';

    const allColumns = [ 'machinery_name', 'owner_name', 'rto_no', 'engine_no', 
      'chassis_no', 'insurance_company', 'insurance_policy_no',
      'operator_name'];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');


      searchCondition += ` AND (${searchConditions})`;
    }

    const page = parseInt(req.query.page, 10) || 0;
    const size = parseInt(req.query.size, 10) || 10;

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                      FROM machinery_master
                      WHERE ${searchCondition} 
                      ORDER BY machinery_id ASC 
                      ${pageSet}`;

    const countQuery = `SELECT COUNT(*) AS totalCount 
                          FROM machinery_master
                          WHERE is_deleted = 0`;

    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = totalCountResult[0].totalCount;

    const result = await lib.queryExecute(queryStr);

    // Include total count in the response
    const response = result.map(item => ({
      ...item,
      totalCount
    }));

    res.status(200).send(response);

  } catch (error) {
    console.error('Error in machinery_master_List:', error);
    res.status(500).send({ message: error.message });
  }
};


// Update or delete machinery master entry
service.updateDeleteMachineryMaster = async (req, res, next) => {
  try {
    console.log('Request body:', req.body);
    
    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const machinery_id = req.body.machinery_id;

    if (changedUpdatedValue === 'edit') {
      const {
        machinery_name = '',
        machinery_type = '',
        owner_name = '',
        rto_no = '',
        engine_no = '',
        chassis_no = '',
        insurance_company = '',
        insurance_policy_no = '',
        insurance_start_date = '',
        insurance_expiry_date = '',
        tax_valid_upto = '',
        pucc_valid_upto = '',
        permit_valid_upto = '',
        fitness_valid_upto = '',
        operator_name = ''
      } = req.body;

      const queryStr = `UPDATE machinery_master SET 
        machinery_name = ${sqlValue(machinery_name)},
        machinery_type = ${sqlValue(machinery_type)},
        owner_name = ${sqlValue(owner_name)},
        rto_no = ${sqlValue(rto_no)},
        engine_no = ${sqlValue(engine_no)},
        chassis_no = ${sqlValue(chassis_no)},
        insurance_company = ${sqlValue(insurance_company)},
        insurance_policy_no = ${sqlValue(insurance_policy_no)},
        insurance_start_date = ${sqlValue(insurance_start_date)},
        insurance_expiry_date = ${sqlValue(insurance_expiry_date)},
        tax_valid_upto = ${sqlValue(tax_valid_upto)},
        pucc_valid_upto = ${sqlValue(pucc_valid_upto)},
        permit_valid_upto = ${sqlValue(permit_valid_upto)},
        fitness_valid_upto = ${sqlValue(fitness_valid_upto)},
        operator_name = ${sqlValue(operator_name)}
        WHERE machinery_id = ${machinery_id}`;

      console.log('Generated SQL query:', queryStr);
      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Machinery Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      const queryStr = `UPDATE machinery_master SET 
        is_deleted = 1
        WHERE machinery_id = ${machinery_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Machinery Deleted Successfully!' });
    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }
  } catch (error) {
    console.error('Error in updateDeleteMachineryMaster:', error);
    res.status(500).send({ error: error.message || error });
  }
};

module.exports = service;