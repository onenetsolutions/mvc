const lib = require('../libs/index');
let service = {};

const sqlValue = (value) => {
  if (value === undefined || value === null || value === '') {
    return 'NULL';
  }
  return `'${value}'`;
};


service.insertdepartmentMaster = async (req, res, next) => {
  try {


        const department_name = req.body.department_name || '';
        const gst_no = req.body.gst_no || '';
        const tan_no = req.body.tan_no || '';
        const pan_no = req.body.pan_no || '';

    const queryStr = `INSERT INTO department_master 
          (department_name,gst_no,tan_no,pan_no) 
          VALUES 
          (${sqlValue(department_name)},${sqlValue(gst_no)},${sqlValue(tan_no)},${sqlValue(pan_no)})`;


    await lib.queryExecute(queryStr);


    res.status(200).send({ result: req.body, message: 'Added Successfully!' });
  } catch (error) {
    // Handling any errors
    res.status(500).send(error);
  }
};



service.departmentMasterList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = req.query.searchKey || '';
    let searchCondition = 'is_deleted = 0';

    const allColumns = ['department_name','gst_no','tan_no','pan_no'];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');


      searchCondition += ` AND (${searchConditions})`;
    }

    const page = parseInt(req.query.page, 10) || 0;
    const size = parseInt(req.query.size, 10) || 10;

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                      FROM department_master
                      WHERE ${searchCondition} 
                      ORDER BY department_id ASC 
                      ${pageSet}`;

    const countQuery = `SELECT COUNT(*) AS totalCount 
                          FROM department_master
                          WHERE is_deleted = 0`;

    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = totalCountResult[0].totalCount;

    const result = await lib.queryExecute(queryStr);

    // Include total count in the response
    const response = result.map(item => ({
      ...item,
      totalCount
    }));

    res.status(200).send(response);

  } catch (error) {
    console.error('Error in department_master:', error);
    res.status(500).send({ message: error.message });
  }
};



// Update or delete cylinder_master entry

service.updateDeletedepartmentMaster = async (req, res, next) => {
    try {
        console.log('Request body:', req.body);
        
        const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
        const department_id = req.body.department_id;

        if (changedUpdatedValue === 'edit') {
            const {
              department_name = '',
              gst_no = '',
              tan_no = '',
              pan_no = ''
            } = req.body;

            const queryStr = `UPDATE department_master SET 
              department_name = ${sqlValue(department_name)},
              gst_no = ${sqlValue(gst_no)},
              tan_no = ${sqlValue(tan_no)},
              pan_no = ${sqlValue(pan_no)}
                WHERE department_id = ${department_id}`;

            console.log('Generated SQL query:', queryStr);
            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Updated Successfully!' });

        } else if (changedUpdatedValue === 'delete') {
            const queryStr = `UPDATE department_master SET 
                is_deleted = 1
                WHERE department_id = ${department_id}`;

            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Deleted Successfully!' });
        } else {
            res.status(400).send({ error: 'Invalid changed update value' });
        }
    } catch (error) {
        console.error('Error in updateDepartmentMaster:', error);
        res.status(500).send({ error: error.message || error });
    }
};



module.exports = service;


