const lib = require('../libs/index');
const { getCashBucket, validateDebitChange } = require('../libs/officeCashBalance');
let service = {};

const getNextDailyExpenseEntryNo = async () => {
  const getMaxEntryQuery = `
      SELECT MAX(CAST(SUBSTRING(entry_no, 3) AS UNSIGNED)) AS maxEntryNo
      FROM daily_expenses
      WHERE entry_no LIKE 'DE%';
    `;
  const maxEntryResult = await lib.queryExecute(getMaxEntryQuery);

  const maxEntryNo = Number(maxEntryResult?.[0]?.maxEntryNo || 0);
  const nextNumber = maxEntryNo + 1;
  return `DE${String(nextNumber).padStart(3, '0')}`;
};


service.insertDailyExpenses = async (req, res, next) => {
  try {
    const entry_date = req.body.entry_date || '';
    const expense_date = req.body.expense_date || '';
    const site_code = req.body.site_code || '';
    const site_name = req.body.site_name || '';
    const work_name = req.body.work_name || '';
    const description = req.body.description || '';
    const paid_to = req.body.paid_to || '';
    const payment_through = req.body.payment_through || '';
    const amount = req.body.amount || '';
    const payment_mode = req.body.payment_mode || '';
    const sub_payment_mode = req.body.sub_payment_mode || '';
    const voucher_book_no = req.body.voucher_book_no || '';
    const voucher_no = req.body.voucher_no || '';
    const paid_by = req.body.paid_by || '';
    const expense_type = req.body.expense_type || '';
    const receipt_no = req.body.receipt_no || '';

    const entry_no = await getNextDailyExpenseEntryNo();

    // ── Office Cash Balance Validation (New Debit) ──
    // FORMULA: DIFF = NEW_DEBIT − 0; NEW_BAL = CURRENT_BAL − DIFF
    if (String(payment_mode).toUpperCase().includes('OFFICE CASH')) {
      const bucket = getCashBucket(sub_payment_mode);
      const debitAmt = parseFloat(amount || 0);
      const check = await validateDebitChange(bucket, 0, debitAmt);
      if (!check.valid) {
        return res.status(400).send({ error: check.message });
      }
    }

    const queryStr = `INSERT INTO daily_expenses 
      (entry_no, entry_date, expense_date, site_code, site_name, work_name, 
       description, paid_to, payment_through, amount, payment_mode, sub_payment_mode,
       voucher_book_no, voucher_no, paid_by, expense_type, receipt_no) 
      VALUES 
      ('${entry_no}', '${entry_date}', '${expense_date}', '${site_code}', 
       '${site_name}', '${work_name}', '${description}', '${paid_to}', 
       '${payment_through}', '${amount}', '${payment_mode}', '${sub_payment_mode}',
       '${voucher_book_no}', '${voucher_no}', '${paid_by}', '${expense_type}', '${receipt_no}')`;

    await lib.queryExecute(queryStr);

    res.status(200).send({ result: req.body, message: 'Daily Expense Added Successfully!' });
  } catch (error) {
    res.status(500).send(error);
  }
};

service.dailyExpensesList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = String(req.query.searchKey || '').trim();
    let searchCondition = 'is_deleted = 0';

    const allColumns = [
      'entry_no', 'entry_date', 'expense_date', 'site_code', 'site_name',
      'work_name', 'description', 'paid_to', 'payment_through', 'amount',
      'payment_mode', 'sub_payment_mode', 'voucher_book_no', 'voucher_no', 'paid_by', 'expense_type', 'receipt_no'
    ];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');

      searchCondition += ` AND (${searchConditions})`;
    }

    const page = Math.max(parseInt(req.query.page, 10) || 0, 0);
    const size = Math.max(parseInt(req.query.size, 10) || 10, 1);

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                    FROM daily_expenses
                    WHERE ${searchCondition} 
                    ORDER BY daily_expenses_id ASC 
                    ${pageSet};`

    const countQuery = `SELECT COUNT(*) AS totalCount 
              FROM daily_expenses
              WHERE ${searchCondition}`;

    const getLastEntryQuery = `
                SELECT entry_no 
                FROM daily_expenses 
                WHERE is_deleted = 0 
                ORDER BY entry_no DESC 
                LIMIT 1;
            `;

    const [lastEntryResult, totalCountResult, result] = await Promise.all([
      lib.queryExecute(getLastEntryQuery),
      lib.queryExecute(countQuery),
      lib.queryExecute(queryStr)
    ]);

    const lastEntryNo = lastEntryResult.length > 0 ? lastEntryResult[0].entry_no : null;
    const totalCount = Number(totalCountResult?.[0]?.totalCount || 0);

    res.set('X-Total-Count', String(totalCount));
    res.set('X-Last-Entry-No', lastEntryNo || '');
    res.status(200).send(result);

  } catch (error) {
    console.error('Error in daily_expenses:', error);
    res.status(500).send({ message: error.message });
  }
};

service.updateDeleteDailyExpenses = async (req, res, next) => {
  try {
    console.log('Request body:', req.body);

    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const daily_expenses_id = req.body.daily_expenses_id;

    // Fetch old record for balance adjustment
    const oldRecordResult = await lib.queryExecute(
      `SELECT amount, payment_mode, sub_payment_mode FROM daily_expenses WHERE daily_expenses_id = ${daily_expenses_id}`
    );
    const oldRecord = oldRecordResult[0] || {};

    if (changedUpdatedValue === 'edit') {
      const {
        entry_no = '',
        entry_date = '',
        expense_date = '',
        site_code = '',
        site_name = '',
        work_name = '',
        description = '',
        paid_to = '',
        payment_through = '',
        amount = '',
        payment_mode = '',
        sub_payment_mode = '',
        voucher_book_no = '',
        voucher_no = '',
        paid_by = '',
        expense_type = '',
        receipt_no= ''
      } = req.body;

      // ── Office Cash Balance Adjustment (Expense Edit) ──
      // FORMULA: DIFF = NEW_DEBIT − OLD_DEBIT; NEW_BAL = CURRENT_BAL − DIFF
      const oldIsOfficeCash = String(oldRecord.payment_mode || '').toUpperCase().includes('OFFICE CASH');
      const newIsOfficeCash = String(payment_mode).toUpperCase().includes('OFFICE CASH');
      const oldBucket = oldIsOfficeCash ? getCashBucket(oldRecord.sub_payment_mode) : '';
      const newBucket = newIsOfficeCash ? getCashBucket(sub_payment_mode) : '';
      const oldAmount = oldIsOfficeCash ? parseFloat(oldRecord.amount || 0) : 0;
      const newAmount = newIsOfficeCash ? parseFloat(amount || 0) : 0;

      if (oldBucket === newBucket && oldBucket) {
        // Same bucket — simple diff
        const check = await validateDebitChange(oldBucket, oldAmount, newAmount);
        if (!check.valid) return res.status(400).send({ error: check.message });
      } else {
        // Bucket changed: release from old, debit from new
        if (oldBucket) {
          const releaseCheck = await validateDebitChange(oldBucket, oldAmount, 0);
          if (!releaseCheck.valid) return res.status(400).send({ error: releaseCheck.message });
        }
        if (newBucket) {
          const debitCheck = await validateDebitChange(newBucket, 0, newAmount);
          if (!debitCheck.valid) return res.status(400).send({ error: debitCheck.message });
        }
      }

      const queryStr = `UPDATE daily_expenses SET 
          entry_no = '${entry_no}',
          entry_date = '${entry_date}',
          expense_date = '${expense_date}',
          site_code = '${site_code}',
          site_name = '${site_name}',
          work_name = '${work_name}',
          description = '${description}',
          paid_to = '${paid_to}',
          payment_through = '${payment_through}',
          amount = '${amount}',
          payment_mode = '${payment_mode}',
          sub_payment_mode = '${sub_payment_mode}',
          voucher_book_no = '${voucher_book_no}',
          voucher_no = '${voucher_no}',
          paid_by = '${paid_by}',
          expense_type = '${expense_type}',
          receipt_no = '${receipt_no}'
          WHERE daily_expenses_id = ${daily_expenses_id}`;

      console.log('Generated SQL query:', queryStr);
      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Daily Expense Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      // ── Office Cash Balance Adjustment (Expense Delete) ──
      // Deleting a debit = setting debit to 0, balance increases
      // No validation needed (balance can only increase), but we log it

      const queryStr = `UPDATE daily_expenses SET 
          is_deleted = 1
          WHERE daily_expenses_id = ${daily_expenses_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Daily Expense Deleted Successfully!' });
    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }
  } catch (error) {
    console.error('Error in updateDailyExpenses:', error);
    res.status(500).send({ error: error.message || error });
  }
};

// Get party ledger for daily expenses
service.getPartyLedger = async (req, res, next) => {
  try {
    const paid_to = req.query.paid_to || '';
    const site_code = req.query.site_code || '';
    const year = req.query.year || new Date().getFullYear();
    const month = req.query.month || new Date().getMonth() + 1;
    
    // Format month to YYYY-MM
    const monthStr = `${year}-${String(month).padStart(2, '0')}`;

    if (!paid_to) {
      return res.status(400).send({ error: 'Paid to party is required' });
    }

    let whereCondition = `
      de.paid_to = '${paid_to}'
      AND de.is_deleted = 0
      AND DATE_FORMAT(de.expense_date, '%Y-%m') = '${monthStr}'
    `;

    if (site_code) {
      whereCondition += ` AND de.site_code = '${site_code}'`;
    }

    const queryStr = `
      SELECT 
        de.daily_expenses_id,
        de.expense_date,
        de.amount,
        de.paid_by,
        de.payment_mode,
        de.description,
        de.site_code,
        de.site_name
      FROM daily_expenses de
      WHERE ${whereCondition}
      ORDER BY de.expense_date ASC, de.daily_expenses_id ASC
    `;

    const result = await lib.queryExecute(queryStr);

    // Calculate totals
    const totalAmount = result.reduce((sum, row) => sum + (parseFloat(row.amount) || 0), 0);

    res.status(200).send({ 
      success: true, 
      data: result,
      totalAmount: totalAmount
    });
  } catch (error) {
    console.error('Error fetching party ledger:', error);
    res.status(500).send({ error: error.message });
  }
};

module.exports = service;

service.getNextEntryNo = async (req, res, next) => {
  try {
    const entry_no = await getNextDailyExpenseEntryNo();
    res.status(200).send({ entry_no });
  } catch (error) {
    console.error('Error generating next daily expense entry no:', error);
    res.status(500).send({ error: error.message });
  }
};