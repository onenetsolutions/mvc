const lib = require('../libs/index');
let service = {};

const numVal = (v) => (v === '' || v === null || v === undefined) ? 'NULL' : v;


service.insertMvTipper = async (req, res, next) => {
  try {
    const {
      entry_date = '',
      site_code = '',
      crusher_owner = '',
      site_name = '',
      party_name = '',
      partner_name = '',
      material_name = '',
      qty = '',
      rate = '',
      total_amount = '',
      description = ''
    } = req.body;

    // Validate mandatory fields
    if (!entry_date || !crusher_owner || !site_code || !site_name || !party_name || 
        !material_name || !qty || !rate || !total_amount) {
      return res.status(400).send({ 
        error: 'Mandatory fields missing: Entry Date, Crusher Owner, Site Code, Site Name, Name of Party, Material Name, Qty, Rate, and Amount are required.' 
      });
    }

 

      const getLastEntryQuery = `
      SELECT entry_no 
      FROM mvtipper_details    
      WHERE is_deleted = 0 
      AND entry_no LIKE 'MVT%'
      ORDER BY entry_no DESC 
      LIMIT 1;
    `;
      const lastEntryResult = await lib.queryExecute(getLastEntryQuery);
 let entry_no;
    if (lastEntryResult.length > 0) {
      const lastEntry = lastEntryResult[0].entry_no;
      // console.log('Last entry_no from DB:', lastEntry);

      const numericPart = lastEntry.substring(3); // Should skip 'MAT'
      // console.log('Extracted numeric part:', numericPart);

      const lastNumber = parseInt(numericPart, 10);
      // console.log('Parsed last number:', lastNumber);

      const newNumber = (lastNumber + 1).toString().padStart(4, '0');
      // console.log('Generated new number:', newNumber);

      entry_no = `MVT${newNumber}`;
    } else {
      // console.log('No previous entries found. Starting fresh.');
      entry_no = 'MVT0001';
    }


   
    const queryStr = `
      INSERT INTO mvtipper_details
        (entry_no, entry_date, site_code, crusher_owner, site_name, party_name, partner_name,
         material_name, qty, rate, total_amount, description)
      VALUES 
        ('${entry_no}', '${entry_date}', '${site_code}', '${crusher_owner}', 
         '${site_name}', '${party_name}', '${partner_name}', '${material_name}', 
         ${numVal(qty)}, ${numVal(rate)}, ${numVal(total_amount)}, '${description}')
    `;

    await lib.queryExecute(queryStr);
     console.log(queryStr,"query responce ")

    res.status(200).send({
      result: req.body,
      message: 'MV Tipper Entry Added Successfully!',
      entry_no
    });
  } catch (error) {
    console.error('Error inserting MV Tipper:', error);
    res.status(500).send({ message: 'Error inserting MV Tipper', error });
  }
};

service.getmvtipperList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = String(req.query.searchKey || '').trim();
    let searchCondition = 'is_deleted = 0';

    const allColumns = [
      'entry_no', 'entry_date', 'crusher_owner', 'site_name',
      'party_name', 'material_name', 'qty', 'rate', 
      'total_amount', 'description'
    ];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');

      searchCondition += ` AND (${searchConditions})`;
    }

    const page = Math.max(parseInt(req.query.page, 10) || 0, 0);
    const size = Math.max(parseInt(req.query.size, 10) || 10, 1);

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                    FROM mvtipper_details
                    WHERE ${searchCondition} 
                    ORDER BY entry_no DESC 
                    ${pageSet};`

    const countQuery = `SELECT COUNT(*) AS totalCount 
              FROM mvtipper_details
              WHERE ${searchCondition}`;

    const getLastEntryQuery = `
      SELECT entry_no 
      FROM mvtipper_details 
      WHERE ${searchCondition}
      ORDER BY entry_no DESC 
      LIMIT 1;
    `;

    const [lastEntryResult, totalCountResult, result] = await Promise.all([
      lib.queryExecute(getLastEntryQuery),
      lib.queryExecute(countQuery),
      lib.queryExecute(queryStr)
    ]);

    const lastEntryNo = lastEntryResult.length > 0 ? lastEntryResult[0].entry_no : null;
    const totalCount = Number(totalCountResult?.[0]?.totalCount || 0);

    res.set('X-Total-Count', String(totalCount));
    res.set('X-Last-Entry-No', lastEntryNo || '');
    res.status(200).send(result);

  } catch (error) {
    console.error('Error in mvtipper_details:', error);
    res.status(500).send({ message: error.message });
  }
};

service.updateDeleteMVtipperEntry = async (req, res, next) => {
  try {
    console.log('Request body:', req.body);

    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const entry_id = req.body.entry_id;

    if (changedUpdatedValue === 'edit') {
      const {
        entry_no = '',
        entry_date = '',
        site_code = '',
        crusher_owner = '',
        site_name = '',
        party_name = '',
        partner_name = '',
        material_name = '' ,
        qty = '',
        rate = '',
        total_amount = '',
        description = ''
      } = req.body;

      // Validate mandatory fields
      if (!entry_date || !crusher_owner || !site_code || !site_name || !party_name || 
          !material_name || !qty || !rate || !total_amount) {
        return res.status(400).send({ 
          error: 'Mandatory fields missing: Entry Date, Crusher Owner, Site Code, Site Name, Name of Party, Material Name, Qty, Rate, and Amount are required.' 
        });
      }

      const queryStr = `UPDATE mvtipper_details SET 
          entry_no = '${entry_no}',
          entry_date = '${entry_date}',
          site_code = '${site_code}',
          crusher_owner = '${crusher_owner}',
          site_name = '${site_name}',
          party_name = '${party_name}',
          partner_name = '${partner_name}',
          material_name = '${material_name}',
          qty = ${numVal(qty)},
          rate = ${numVal(rate)},
          total_amount = ${numVal(total_amount)},
          description = '${description}'
          WHERE entry_id = ${entry_id}`;

      console.log('Generated SQL query:', queryStr);
      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'mvtipper details Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      const queryStr = `UPDATE mvtipper_details SET 
          is_deleted = 1
          WHERE entry_id = ${entry_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'mvtipper details Deleted Successfully!' });
    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }
  } catch (error) {
    console.error('Error in updateMaterialEntry:', error);
    res.status(500).send({ error: error.message || error });
  }
};

module.exports = service;
