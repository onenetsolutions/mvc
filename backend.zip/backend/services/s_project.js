const lib = require('../libs/index');
let service = {};

service.insertProject = async (req, res, next) => {
  try {
    const project_name = req.body.project_name || '';
    const description = req.body.description || '';
    const status = req.body.status || '';
    const assigned_employee_id = req.body.assigned_employee_id || '';
    const start_date = req.body.start_date || '';
    const end_date = req.body.end_date || '';

    const queryStr = `INSERT INTO project_master
          (project_name, description, status, assigned_employee_id, start_date, end_date)
          VALUES
          ('${project_name}', '${description}', '${status}', '${assigned_employee_id}', '${start_date}', '${end_date}')`;

    await lib.queryExecute(queryStr);

    res.status(200).send({ result: req.body, message: 'Project Added Successfully!' });
  } catch (error) {
    res.status(500).send(error);
  }
};

service.ProjectList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = req.query.searchKey || '';
    let searchCondition = 'is_deleted = 0';

    const allColumns = ['project_name', 'description', 'status', 'start_date', 'end_date'];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');

      searchCondition += ` AND (${searchConditions})`;
    }

    const page = parseInt(req.query.page, 10) || 0;
    const size = parseInt(req.query.size, 10) || 10;

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT *
                      FROM project_master
                      WHERE ${searchCondition}
                      ORDER BY project_id ASC
                      ${pageSet}`;

    const countQuery = `SELECT COUNT(*) AS totalCount
                          FROM project_master
                          WHERE is_deleted = 0`;

    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = totalCountResult[0].totalCount;

    const result = await lib.queryExecute(queryStr);

    const response = result.map(item => ({
      ...item,
      totalCount
    }));

    res.status(200).send(response);

  } catch (error) {
    console.error('Error in project list:', error);
    res.status(500).send({ message: error.message });
  }
};

service.updateDeleteProject = async (req, res, next) => {
  try {
    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const project_id = req.body.project_id;

    if (changedUpdatedValue === 'edit') {
      const {
        project_name = '',
        description = '',
        status = '',
        assigned_employee_id = '',
        start_date = '',
        end_date = ''
      } = req.body;

      const queryStr = `UPDATE project_master SET
                project_name = '${project_name}',
                description = '${description}',
                status = '${status}',
                assigned_employee_id = '${assigned_employee_id}',
                start_date = '${start_date}',
                end_date = '${end_date}'
                WHERE project_id = ${project_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Project Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      const queryStr = `UPDATE project_master SET
                is_deleted = 1
                WHERE project_id = ${project_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Project Deleted Successfully!' });
    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }
  } catch (error) {
    console.error('Error in update/delete Project:', error);
    res.status(500).send({ error: error.message || error });
  }
};

module.exports = service;