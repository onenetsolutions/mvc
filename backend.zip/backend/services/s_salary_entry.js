const lib = require('../libs/index');
const { getCashBucket, validateDebitChange } = require('../libs/officeCashBalance');
let service = {};

const decimalFields = new Set(['advance_payment', 'deduction', 'reimbursement', 'total_salary', 'salary_paid', 'no_days_present', 'no_days_absent']);
const numVal = (value) => (value === '' || value === null || value === undefined) ? 'NULL' : value;

// Insert a new salary entry
service.insertSalaryEntry = async (req, res, next) => {
  try {
    const payload = {
      date: req.body.date || '',
      employee_name: req.body.employee_name || '',
      employee_id: req.body.employee_id || '',
      pay_scale_type: req.body.pay_scale_type || '',
      from_to_date: req.body.from_to_date || '',
      month_year: req.body.month_year || '',
      no_days_present: req.body.no_days_present ?? '',
      no_days_absent: req.body.no_days_absent || '',
      total_salary: req.body.total_salary || '',
      advance_payment: req.body.advance_payment || '',
      deduction: req.body.deduction || '',
      reimbursement: req.body.reimbursement || '',
      salary_paid: req.body.salary_paid || '',
      remark: req.body.remark || '',
      paid_by: req.body.paid_by || '',
      payment_mode: req.body.payment_mode || '',
      sub_payment_mode: req.body.sub_payment_mode || '',
      site_code: req.body.site_code || '',
      site_name: req.body.site_name || ''
    };

    // Validate mandatory fields
    const noDaysEmpty = payload.no_days_present === '' || payload.no_days_present === null || payload.no_days_present === undefined;
    const paidByMissing = !payload.paid_by && payload.payment_mode !== 'Office Cash';
    if (!payload.date || !payload.employee_name || !payload.pay_scale_type ||
      noDaysEmpty || !payload.total_salary || !payload.payment_mode ||
      paidByMissing || !payload.salary_paid || !payload.remark) {
      return res.status(400).send({
        error: 'Mandatory fields missing: Date, Employee Name, Pay Scale Type, No of Days Present, Total Salary, Mode of Payment, Paid By, Salary Paid, and Remarks are required.'
      });
    }

    // ── Office Cash Balance Validation (New Salary Debit) ──
    // FORMULA: DIFF = NEW_DEBIT − 0; NEW_BAL = CURRENT_BAL − DIFF
    if (String(payload.payment_mode).toUpperCase().includes('OFFICE CASH')) {
      const bucket = getCashBucket(payload.sub_payment_mode);
      const debitAmt = parseFloat(payload.salary_paid || 0);
      const check = await validateDebitChange(bucket, 0, debitAmt);
      if (!check.valid) {
        return res.status(400).send({ error: check.message });
      }
    }

    const columnsQuery = `
      SELECT COLUMN_NAME AS col
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = 'salary_entry'
    `;
    const columnsResult = await lib.queryExecute(columnsQuery);
    const existingCols = new Set(columnsResult.map(r => r.col));

    const allowedKeys = Object.keys(payload).filter(k => existingCols.has(k));
    const colsPart = allowedKeys.join(', ');
    const valsPart = allowedKeys.map(k => {
      const v = payload[k];
      if (decimalFields.has(k)) return numVal(v);
      return `'${v}'`;
    }).join(', ');

    const insertQuery = `
      INSERT INTO salary_entry (${colsPart})
      VALUES (${valsPart})
    `;

    await lib.queryExecute(insertQuery);

    res.status(200).send({ result: req.body, message: 'Salary Entry Added Successfully!' });
  } catch (error) {
    res.status(500).send({ error: error.message || error });
  }
};

// Get list of salary entries
service.salaryEntryList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = String(req.query.searchKey || '').trim();
    let searchCondition = 'is_deleted = 0';

    const allColumns = ['date', 'employee_name', 'employee_id', 'pay_scale_type', 'from_to_date', 'month_year', 'no_days_present', 'no_days_absent', 'total_salary', 'advance_payment', 'deduction', 'reimbursement', 'salary_paid', 'remark', 'paid_by', 'payment_mode', 'sub_payment_mode', 'site_code', 'site_name'];


    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');

      searchCondition += ` AND (${searchConditions})`;
    }

    const page = Math.max(parseInt(req.query.page, 10) || 0, 0);
    const size = Math.max(parseInt(req.query.size, 10) || 10, 1);

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    const countQuery = `SELECT COUNT(*) AS totalCount FROM salary_entry WHERE ${searchCondition}`;
    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = Number(totalCountResult?.[0]?.totalCount || 0);

    const queryStr = `SELECT * FROM salary_entry WHERE ${searchCondition} ORDER BY salary_id DESC ${pageSet}`;
    const result = await lib.queryExecute(queryStr);

    res.set('X-Total-Count', String(totalCount));
    res.status(200).send(result);

  } catch (error) {
    res.status(500).send({ error: error.message || error });
  }
};

// Update or soft-delete salary entry
service.updateDeleteSalaryEntry = async (req, res, next) => {
  try {
    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const salary_id = req.body.salary_id;

    // Fetch old record for balance adjustment
    const oldRecordResult = await lib.queryExecute(
      `SELECT salary_paid, payment_mode, sub_payment_mode FROM salary_entry WHERE salary_id = ${salary_id}`
    );
    const oldRecord = oldRecordResult[0] || {};

    if (changedUpdatedValue === 'edit') {
      const {
        date = '',
        employee_name = '',
        employee_id = '',
        pay_scale_type = '',
        from_to_date = '',
        month_year = '',
        no_days_present = '',
        no_days_absent = '',
        total_salary = '',
        advance_payment = '',
        deduction = '',
        reimbursement = '',
        salary_paid = '',
        remark = '',
        paid_by = '',
        payment_mode = '',
        sub_payment_mode = '',
        site_code = '',
        site_name = ''
      } = req.body;

      // Validate mandatory fields
      const noDaysPresentEmpty = no_days_present === '' || no_days_present === null || no_days_present === undefined;
      const paidByMissingEdit = !paid_by && payment_mode !== 'Office Cash';
      if (!date || !employee_name || !pay_scale_type || noDaysPresentEmpty ||
        !total_salary || !payment_mode || paidByMissingEdit || !salary_paid || !remark) {
        return res.status(400).send({
          error: 'Mandatory fields missing: Date, Employee Name, Pay Scale Type, No of Days Present, Total Salary, Mode of Payment, Paid By, Salary Paid, and Remarks are required.'
        });
      }

      // ── Office Cash Balance Adjustment (Salary Edit) ──
      // FORMULA: DIFF = NEW_DEBIT − OLD_DEBIT; NEW_BAL = CURRENT_BAL − DIFF
      const oldIsOfficeCash = String(oldRecord.payment_mode || '').toUpperCase().includes('OFFICE CASH');
      const newIsOfficeCash = String(payment_mode).toUpperCase().includes('OFFICE CASH');
      const oldBucket = oldIsOfficeCash ? getCashBucket(oldRecord.sub_payment_mode) : '';
      const newBucket = newIsOfficeCash ? getCashBucket(sub_payment_mode) : '';
      const oldSalaryAmt = oldIsOfficeCash ? parseFloat(oldRecord.salary_paid || 0) : 0;
      const newSalaryAmt = newIsOfficeCash ? parseFloat(salary_paid || 0) : 0;

      if (oldBucket === newBucket && oldBucket) {
        const check = await validateDebitChange(oldBucket, oldSalaryAmt, newSalaryAmt);
        if (!check.valid) return res.status(400).send({ error: check.message });
      } else {
        if (oldBucket) {
          const releaseCheck = await validateDebitChange(oldBucket, oldSalaryAmt, 0);
          if (!releaseCheck.valid) return res.status(400).send({ error: releaseCheck.message });
        }
        if (newBucket) {
          const debitCheck = await validateDebitChange(newBucket, 0, newSalaryAmt);
          if (!debitCheck.valid) return res.status(400).send({ error: debitCheck.message });
        }
      }

      const queryStr = `UPDATE salary_entry SET 
        date = '${date}',
        employee_name = '${employee_name}',
        employee_id = '${employee_id}',
        pay_scale_type = '${pay_scale_type}',
        from_to_date = '${from_to_date}',
        month_year = '${month_year}',
        no_days_present = ${numVal(no_days_present)},
        no_days_absent = ${numVal(no_days_absent)},
        total_salary = ${numVal(total_salary)},
        advance_payment = ${numVal(advance_payment)},
        deduction = ${numVal(deduction)},
        reimbursement = ${numVal(reimbursement)},
        salary_paid = ${numVal(salary_paid)},
        remark = '${remark}',
        paid_by = '${paid_by}',
        payment_mode = '${payment_mode}',
        sub_payment_mode = '${sub_payment_mode}',
        site_code = '${site_code}',
        site_name = '${site_name}'
        WHERE salary_id = ${salary_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Salary Entry Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      // ── Office Cash Balance Adjustment (Salary Delete) ──
      // Deleting a debit = setting debit to 0, balance increases

      const queryStr = `UPDATE salary_entry SET is_deleted = 1 WHERE salary_id = ${salary_id}`;
      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Salary Entry Deleted Successfully!' });

    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }
  } catch (error) {
    res.status(500).send({ error: error.message || error });
  }
};

// NEW GET

service.getAttendanceCount = async (req, res, next) => {
  try {
    let { employee_id, from_date, to_date, month_year } = req.query;

    // Validate input
    if (!employee_id) {
      return res.status(400).send({ error: "employee_id is required" });
    }

    // Clean up 'undefined' values passed as strings
    if (from_date === 'undefined') from_date = null;
    if (to_date === 'undefined') to_date = null;
    if (month_year === 'undefined') month_year = null;

    let dateCondition = '';
    if (from_date && to_date) {
      dateCondition = `AND a.date BETWEEN '${from_date}' AND '${to_date}'`;
    } else if (month_year) {
      const [year, month] = month_year.split('-');
      dateCondition = `AND YEAR(a.date) = ${year} AND MONTH(a.date) = ${month}`;
    }

    const queryStr = `
      SELECT 
        c.employee_name,
        COALESCE(SUM(CASE WHEN a.absent_present = 'Present' THEN 1 ELSE 0 END), 0) AS present_count,
        COALESCE(SUM(CASE WHEN a.absent_present = 'Absent' THEN 1 ELSE 0 END), 0) AS absent_count
      FROM attendance_entry a
      JOIN employee_master c ON a.employee_id = c.employee_id
      WHERE a.employee_id = '${employee_id}' 
        AND a.is_deleted = 0
        ${dateCondition}
      GROUP BY c.employee_name
    `;

    const result = await lib.queryExecute(queryStr);

    if (result.length > 0) {
      res.status(200).send(result[0]); // send { employee_name, present_count, absent_count }
    } else {
      res.status(200).send({
        employee_name: null,
        present_count: 0,
        absent_count: 0
      });
    }

  } catch (error) {
    console.error("Error in getAttendanceCount:", error);
    res.status(500).send({ error: error.message || "Internal Server Error" });
  }
};




module.exports = service;
