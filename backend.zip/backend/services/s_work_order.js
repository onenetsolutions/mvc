const lib = require('../libs/index');
let service = {};

// Returns NULL for empty/null/undefined values so DECIMAL columns don't get ''
const numVal = (value) => (value === '' || value === null || value === undefined) ? 'NULL' : value;

const getNextSiteCodeValue = async () => {
    const getLastSiteCodeQuery = `
        SELECT site_code FROM work_order
        WHERE site_code LIKE 'SC%' AND is_deleted = 0
        ORDER BY work_order_id DESC LIMIT 1;
    `;
    const lastSiteCodeResult = await lib.queryExecute(getLastSiteCodeQuery);

    let site_code = 'SC001';
    if (lastSiteCodeResult.length > 0) {
        const lastSite = lastSiteCodeResult[0].site_code || 'SC000';
        const numericPart = parseInt(String(lastSite).replace(/^SC/, ''), 10);
        const nextNumber = Number.isNaN(numericPart) ? 1 : numericPart + 1;
        site_code = 'SC' + String(nextNumber).padStart(3, '0');
    }

    return site_code;
};

service.getNextSiteCode = async (req, res, next) => {
    try {
        const site_code = await getNextSiteCodeValue();
        res.status(200).send({ site_code });
    } catch (error) {
        console.error('Get Next Work Order Site Code Error:', error);
        res.status(500).send({ message: error.message });
    }
};

/**
 * INSERT Production Entry
 */
service.insertWorkOrder = async (req, res, next) => {
    try {
        const {
            sr_no = '',
            site_name = '',
            entry_date = new Date().toISOString().split('T')[0],
            order_year = '',
            department_name = '',
            contractor_name = '',
            sub_contractor_name = '',
            work_name = '',
            work_head = '',
            workdone_by = [],
            agreement_no = '',
            work_order_no = '',
            work_order_date = new Date().toISOString().split('T')[0],
            work_order_amount = '',
            work_time_limit = new Date().toISOString().split('T')[0],
            dlp_period = '',
            security_deposit_amount = '',
            security_amount_refund_status = '',
            additional_security_deposit_amount = '',
            additional_security_amount_refund_status = '',
            security_deposit = [],
            additionalsecurity_deposit = []
        } = req.body;

        const site_code = await getNextSiteCodeValue();

        // Convert arrays to JSON for longtext fields
        // const securityDepositJSON = JSON.stringify(security_deposit);
        // const additionalSecurityDepositJSON = JSON.stringify(additionalsecurity_deposit);

        const insertQuery = `
            INSERT INTO work_order (
                site_code,
                site_name,
                sr_no,
                entry_date,
                order_year,
                department_name,
                contractor_name,
                sub_contractor_name,
                work_name,
                work_head,
                workdone_by,
                agreement_no,
                work_order_no,
                work_order_date,
                work_order_amount,
                work_time_limit,
                dlp_period,
                security_deposit_amount,
                security_amount_refund_status,
                additional_security_deposit_amount,
                additional_security_amount_refund_status,
                security_deposit,
                additionalsecurity_deposit,
                is_deleted
            ) VALUES (
                '${site_code}',
                '${site_name}',
                '${sr_no}',
                '${entry_date}',
                '${order_year}',
                '${department_name}',
                '${contractor_name}',
                '${sub_contractor_name}',
                '${work_name}',
                '${work_head}',
                '${JSON.stringify(workdone_by)}',
                '${agreement_no}',
                '${work_order_no}',
                '${work_order_date}',
                ${numVal(work_order_amount)},
                '${work_time_limit}',
                '${dlp_period}',
                ${numVal(security_deposit_amount)},
                '${security_amount_refund_status}',
                ${numVal(additional_security_deposit_amount)},
                '${additional_security_amount_refund_status}',
                '${security_deposit}',
                '${additionalsecurity_deposit}',
                0
            );
        `;

        await lib.queryExecute(insertQuery);
        res.status(200).send({ message: 'Work Order inserted successfully.', site_code });
    } catch (error) {
        console.error('Insert Work Order Error:', error);
        res.status(500).send({ message: error.message });
    }
};


/**
 * GET Production Entry List
 */
service.workOrderList = async (req, res, next) => {
    try {
        let pageSet = '';
        const searchKey = req.query.searchKey || '';
        let searchCondition = 'is_deleted = 0';
        const allColumns = ['sr_no', 'site_code', 'work_name', 'department_name'];

        if (searchKey) {
            const searchConditions = allColumns
                .map(col => `${col} LIKE '%${searchKey}%'`)
                .join(' OR ');
            searchCondition += ` AND (${searchConditions})`;
        }

        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        if (size > 0) {
            pageSet = `LIMIT ${size} OFFSET ${page * size}`;
        }

        const queryStr = `
            SELECT * FROM work_order
            WHERE ${searchCondition}
            ORDER BY work_order_id DESC
            ${pageSet};
        `;
const countQuery = `
            SELECT COUNT(*) AS totalCount 
            FROM work_order 
            WHERE ${searchCondition};
        `;

        const getLastEntryQuery = `
            SELECT sr_no, site_code 
            FROM work_order 
            WHERE is_deleted = 0 
            ORDER BY work_order_id DESC 
            LIMIT 1;
        `;

        const [lastEntryResult, totalCountResult, result] = await Promise.all([
            lib.queryExecute(getLastEntryQuery),
            lib.queryExecute(countQuery),
            lib.queryExecute(queryStr)
        ]);

        const lastEntryNo = lastEntryResult.length > 0 ? lastEntryResult[0].site_code : null;
        const totalCount = totalCountResult[0].totalCount;

        const response = result.map(item => ({
            ...item,
            totalCount,
            lastEntryNo
        }));

        res.status(200).send(response);
    } catch (error) {
        console.error('Error in workorder EntryList:', error);
        res.status(500).send({ message: error.message });
    }
};
//         const countQuery = `SELECT COUNT(*) AS totalCount FROM work_order WHERE is_deleted = 0;`;

//         const [totalCountResult, result] = await Promise.all([
//             lib.queryExecute(countQuery),
//             lib.queryExecute(queryStr)
//         ]);

//         const totalCount = totalCountResult[0].totalCount;

//         const response = result.map(item => ({
//             ...item,
//             totalCount
//         }));

//         res.status(200).send(response);
//     } catch (error) {
//         console.error('Work Order List Error:', error);
//         res.status(500).send({ message: error.message });
//     }
// };


/**
 * UPDATE or DELETE Production Entry
 */
service.updateDeleteWorkOrder = async (req, res, next) => {
    try {
        const { changedUpdatedValue = 'edit', work_order_id } = req.body;

        if (!work_order_id) {
            return res.status(400).send({ error: 'Missing work_order_id' });
        }

        if (changedUpdatedValue === 'edit') {
            const {
                site_code = '',
                site_name = '',
                entry_date = new Date().toISOString().split('T')[0],
                order_year = '',
                department_name = '',
                contractor_name = '',
                sub_contractor_name = '',
                work_name = '',
                work_head = '',
                workdone_by = [],
                agreement_no = '',
                work_order_no = '',
                work_order_date = new Date().toISOString().split('T')[0],
                work_order_amount = '',
                work_time_limit = new Date().toISOString().split('T')[0],
                dlp_period = '',
                security_deposit_amount = '',
                security_amount_refund_status = '',
                additional_security_deposit_amount = '',
                additional_security_amount_refund_status = '',
                security_deposit = [],
                additionalsecurity_deposit = []
            } = req.body;

            // const security_deposit = JSON.stringify(contractor_details[0] || {});
            // const additionalsecurity_deposit = JSON.stringify(contractor_details[1] || {});

            const updateQuery = `
                UPDATE work_order SET
                    site_code = '${site_code}',
                    site_name = '${site_name}',
                    entry_date = '${entry_date}',
                    order_year = '${order_year}',
                    department_name = '${department_name}',
                    contractor_name = '${contractor_name}',
                    sub_contractor_name = '${sub_contractor_name}',
                    work_name = '${work_name}',
                    work_head = '${work_head}',
                    workdone_by = '${JSON.stringify(workdone_by)}',
                    agreement_no = '${agreement_no}',
                    work_order_no = '${work_order_no}',
                    work_order_date = '${work_order_date}',
                    work_order_amount = ${numVal(work_order_amount)},
                    work_time_limit = '${work_time_limit}',
                    dlp_period = '${dlp_period}',
                    security_deposit_amount = ${numVal(security_deposit_amount)},
                    security_amount_refund_status = '${security_amount_refund_status}',
                    additional_security_deposit_amount = ${numVal(additional_security_deposit_amount)},
                    additional_security_amount_refund_status = '${additional_security_amount_refund_status}',
                    security_deposit = '${security_deposit}',
                    additionalsecurity_deposit = '${additionalsecurity_deposit}'
                WHERE work_order_id = ${work_order_id};
            `;

            await lib.queryExecute(updateQuery);
            return res.status(200).send({ message: 'Work Order Updated Successfully!', result: req.body });

        } else if (changedUpdatedValue === 'delete') {
            const deleteQuery = `
                UPDATE work_order SET is_deleted = 1
                WHERE work_order_id = ${work_order_id};
            `;
            await lib.queryExecute(deleteQuery);
            return res.status(200).send({ message: 'Work Order Deleted Successfully!' });

        } else {
            return res.status(400).send({ error: 'Invalid changedUpdatedValue' });
        }
    } catch (error) {
        console.error('Update/Delete Work Order Error:', error);
        return res.status(500).send({ message: error.message || 'Internal server error' });
    }
};



module.exports = service;
