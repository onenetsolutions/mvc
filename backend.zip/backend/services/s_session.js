const lib = require('../libs/index');
let service = {};


const auth = require('../libs/auth'); // Import the auth module

// service.sessionlist = async (req, res, next) => {
//     try {
//         // The session token will be extracted from the Authorization header
//         const sessionToken = req.headers['authorization']?.split(' ')[1]; // Extract token from Authorization header

//         // The user ID will now be available in req.user from the auth.verify middleware
//         const userId = req.user?.user_id;  // Ensure you access the user_id from req.user

//         if (!sessionToken) {
//             return res.status(400).send({ message: 'Session token is required' });
//         }

//         if (!userId) {
//             return res.status(400).send({ message: 'User ID is missing or not authenticated' });
//         }

//         // Query to check the session status in the database
//         const queryStr = `
//             SELECT status 
//             FROM sessions 
//             WHERE user_id = ? AND session_token = ? 
//             LIMIT 1
//         `;

//         // Execute the query to check if the session exists for the given user and token
//         const result = await lib.queryExecute(queryStr, [userId, sessionToken]);

//         if (result.length === 0) {
//             return res.status(404).send({ message: 'Session not found' });
//         }

//         // If session found, get the status (active/inactive)
//         const sessionStatus = result[0].status;

//         // Respond with the session status
//         res.status(200).send({
//             userId: userId,
//             sessionToken: sessionToken,
//             status: sessionStatus // 'active' or 'inactive'
//         });

//     } catch (error) {
//         console.error('Error in session status check:', error);
//         res.status(500).send({ message: error.message });
//     }
// };


service.sessionlist = async (req, res, next) => {
    try {
        const sessionToken = req.headers['authorization']?.split(' ')[1]; // Extract token from Authorization header
        const userId = req.user.user_id; // Assuming user ID is available in req.user after authentication

        if (!sessionToken) {
            return res.status(400).send({ message: 'Session token is required' });
        }

        // Query to check the session status in the database
        const queryStr = `
            SELECT status 
            FROM sessions 
            WHERE user_id = ? AND session_token = ? 
            LIMIT 1
        `;

        const result = await lib.queryExecute(queryStr, [userId, sessionToken]);

        if (result.length === 0) {
            return res.status(404).send({ message: 'Session not found' });
        }

        const sessionStatus = result[0].status;

        res.status(200).send({
            userId: userId,
            sessionToken: sessionToken,
            status: sessionStatus // 'active' or 'inactive'
        });

    } catch (error) {
        console.error('Error in session status check:', error);
        res.status(500).send({ message: error.message });
    }
};

module.exports = service;