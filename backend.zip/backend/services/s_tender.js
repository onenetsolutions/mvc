const lib = require('../libs/index');
let service = {};

/**
 * INSERT Production Entry
 */
service.insertTender = async (req, res, next) => {
    try {
        // console.log(req.body,'sadas')
        const entry_date = req.body.entry_date || new Date().toISOString().split('T')[0];
        const entry_year = req.body.entry_year || '';
        const work_time_limit = req.body.work_time_limit || new Date().toISOString().split('T')[0];
        const tender_id_user = req.body.tender_id_user || '';
        const department_name = req.body.department_name || '';
        const work_name = req.body.work_name || '';
        const tender_amount = req.body.tender_amount || 0;
        const work_order_amount = req.body.work_order_amount || 0;
        const days_months = req.body.days_months || '';
        const dlp_period = req.body.dlp_period || '';
        const work_order_received = req.body.work_order_received || 0;


        const contractor_details = (req.body.contractor_details || []);


        // Get the last entry number
        const getLastEntryQuery = `
            SELECT sr_no 
            FROM tender    
            WHERE is_deleted = 0 
            ORDER BY sr_no DESC 
            LIMIT 1;
        `;
        const lastEntryResult = await lib.queryExecute(getLastEntryQuery);

        let sr_no = 'T001';
        // if (lastEntryResult.length > 0) {
        //     sr_no = (parseInt(lastEntryResult[0].sr_no, 10) + 1).toString().padStart(5, '0');
        // }
        if (lastEntryResult.length > 0 && lastEntryResult[0].sr_no) {
            const lastSrNo = lastEntryResult[0].sr_no;
            const numericPart = parseInt(String(lastSrNo).replace(/^T/, ''), 10);

            // Check if numericPart is a valid number
            if (!isNaN(numericPart) && numericPart > 0) {
                const newNumber = (numericPart + 1).toString().padStart(3, '0');
                sr_no = `T${newNumber}`;
            }
        }

        const insertQuery = `
    INSERT INTO tender (
    sr_no,
        entry_date,
        entry_year,
        work_time_limit,
        tender_id_user,
        department_name,
        work_name,
        tender_amount,
        work_order_amount,
        days_months,
        dlp_period,
        work_order_received,
        contractor_details
    ) VALUES (
     '${sr_no}',
        '${entry_date}',
        '${entry_year}',
        '${work_time_limit}',
        '${tender_id_user}',
        '${department_name}',
        '${work_name}',
        '${tender_amount}',
        '${work_order_amount}',
        '${days_months}',
        '${dlp_period}',
        '${work_order_received}',
        '${JSON.stringify(contractor_details)}'
    );
`;


        await lib.queryExecute(insertQuery);
        res.status(200).send({ result: req.body, message: 'Tender Entry Added Successfully!' });
    } catch (error) {
        res.status(500).send(error);
    }
};

/**
 * GET Production Entry List
 */
service.TenderList = async (req, res, next) => {
    try {
        let pageSet = '';
        const searchKey = req.query.searchKey || '';
        let searchCondition = 'is_deleted = 0';
        const allColumns = ['sr_no'];

        if (searchKey) {
            const searchConditions = allColumns
                .map(col => `${col} LIKE '%${searchKey}%'`)
                .join(' OR ');
            searchCondition += ` AND (${searchConditions})`;
        }

        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        if (size > 0) {
            pageSet = `LIMIT ${size} OFFSET ${page * size}`;
        }

        const queryStr = `
            SELECT * FROM tender
            WHERE ${searchCondition}
            ORDER BY tender_id ASC
            ${pageSet};
        `;

        const countQuery = `
            SELECT COUNT(*) AS totalCount 
            FROM tender 
            WHERE is_deleted = 0;
        `;

        const getLastEntryQuery = `
            SELECT sr_no 
            FROM tender 
            WHERE is_deleted = 0 
            ORDER BY sr_no DESC 
            LIMIT 1;
        `;

        const [lastEntryResult, totalCountResult, result] = await Promise.all([
            lib.queryExecute(getLastEntryQuery),
            lib.queryExecute(countQuery),
            lib.queryExecute(queryStr)
        ]);

        const lastEntryNo = lastEntryResult.length > 0 ? lastEntryResult[0].sr_no : null;
        const totalCount = totalCountResult[0].totalCount;

        const response = result.map(item => ({
            ...item,
            totalCount,
            lastEntryNo
        }));

        res.status(200).send(response);
    } catch (error) {
        console.error('Error in tenderEntryList:', error);
        res.status(500).send({ message: error.message });
    }
};

/**
 * UPDATE or DELETE Production Entry
 */
service.updateDeleteTender = async (req, res, next) => {
    try {
        const { changedUpdatedValue = 'edit', tender_id } = req.body;

        // Validation: Ensure product_entry_id is provided
        if (!tender_id) {
            return res.status(400).send({ error: 'Missing tender_id' });
        }

        if (changedUpdatedValue === 'edit') {
            const {
                // sr_no = '',
                entry_date = new Date().toISOString().split('T')[0],
                entry_year = '',
                work_time_limit = new Date().toISOString().split('T')[0],
                tender_id_user = '',
                department_name = '',
                work_name = '',
                tender_amount = 0,
                work_order_amount = 0,
                days_months = '',
                dlp_period = '',
                work_order_received = 0,
                contractor_details = [] // default as empty array
            } = req.body || {};


            // Convert contractor_details to JSON string
            const contractorDetailsString = JSON.stringify(contractor_details);

            const updateQuery = `
    UPDATE tender SET
        entry_date = '${entry_date}',
        entry_year = '${entry_year}',
        work_time_limit = '${work_time_limit}',
        tender_id_user = '${tender_id_user}',
        department_name = '${department_name}',
        work_name = '${work_name}',
        tender_amount = '${tender_amount}',
        work_order_amount = '${work_order_amount}',
        days_months = '${days_months}',
        dlp_period = '${dlp_period}',
        work_order_received = '${work_order_received}',
        contractor_details = '${contractorDetailsString}'
    WHERE tender_id = ${tender_id};
`;

            // Execute the query
            await lib.queryExecute(updateQuery);
            return res.status(200).send({ message: 'Updated Successfully!', result: req.body });

        } else if (changedUpdatedValue === 'delete') {
            const deleteQuery = `
          UPDATE tender SET is_deleted = 1
          WHERE tender_id = ${tender_id};
        `;
            await lib.queryExecute(deleteQuery);
            return res.status(200).send({ message: 'Deleted Successfully!' });

        } else {
            return res.status(400).send({ error: 'Invalid changedUpdatedValue' });
        }

    } catch (error) {
        console.error('Error in updateDeleteTenderEntry:', error);
        return res.status(500).send({ message: error.message || 'Internal server error' });
    }
};


module.exports = service;
