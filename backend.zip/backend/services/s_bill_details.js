const lib = require('../libs/index');
let service = {};

// Insert bill details
service.insertBillDetails = async (req, res, next) => {
  try {
    const {
      site_code = '',
      site_name = '',
      entry_date = '',
      order_year = '',
      department_name = '',
      contractor_name = '',
      sub_contractor_name = '',
      work_name = '',
      bank_name = '',
      workdone_by = [],
      agreement_no = '',
      bill_no = '',
      work_order_amount = '',
      total_bill_amount = '',
      deduction_amount = '',
      net_bill_amount = '',
      security_deposit = '',
      insurance = '',
      gst = '',
      surcharge = '',
      cess = '',
      tds = '',
      royalty = '',
      fine = '',
      other = '',
      bank_charges = '',
      stamp_duty = '',
      other_charges = '',
      description = '',
      remark = ''
    } = req.body;

    const queryStr = `INSERT INTO bill_details 
      (site_code, site_name, entry_date, order_year, department_name, 
       contractor_name, sub_contractor_name, work_name, bank_name, 
       workdone_by, agreement_no, bill_no, work_order_amount, 
       total_bill_amount, deduction_amount, net_bill_amount, 
       security_deposit, insurance, gst, surcharge, cess, tds, 
       royalty, fine, other, bank_charges, stamp_duty, other_charges, 
       description, remark) 
      VALUES 
      ('${site_code}', '${site_name}', '${entry_date}', '${order_year}', '${department_name}', 
       '${contractor_name}', '${sub_contractor_name}', '${work_name}', '${bank_name}', 
        ${JSON.stringify(workdone_by)}, '${agreement_no}', '${bill_no}', '${work_order_amount}', 
       '${total_bill_amount}', '${deduction_amount}', '${net_bill_amount}', 
       '${security_deposit}', '${insurance}', '${gst}', '${surcharge}', '${cess}', '${tds}', 
       '${royalty}', '${fine}', '${other}', '${bank_charges}', '${stamp_duty}', '${other_charges}', 
       '${description}', '${remark}')`;

    await lib.queryExecute(queryStr);

    res.status(200).send({ result: req.body, message: 'Bill Details Added Successfully!' });
  } catch (error) {
    res.status(500).send(error);
  }
};

// Get bill details list with pagination and search
service.billDetailsList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = req.query.searchKey || '';
    let searchCondition = 'is_deleted = 0';

    const allColumns = [
      'site_code', 'site_name', 'entry_date', 'order_year', 'department_name',
      'contractor_name', 'sub_contractor_name', 'work_name', 'bank_name',
      'workdone_by', 'agreement_no', 'bill_no', 'work_order_amount',
      'total_bill_amount', 'net_bill_amount', 'description', 'remark'
    ];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');

      searchCondition += ` AND (${searchConditions})`;
    }

    const page = parseInt(req.query.page, 10) || 0;
    const size = parseInt(req.query.size, 10) || 10;

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                    FROM bill_details
                    WHERE ${searchCondition} 
                    ORDER BY bill_details_id ASC 
                    ${pageSet}`;

    const countQuery = `SELECT COUNT(*) AS totalCount 
              FROM bill_details
              WHERE ${searchCondition}`;

    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = totalCountResult[0].totalCount;

    const result = await lib.queryExecute(queryStr);

    const response = result.map(item => ({
      ...item,
      totalCount
    }));

    res.status(200).send(response);

  } catch (error) {
    console.error('Error in bill_details:', error);
    res.status(500).send({ message: error.message });
  }
};

// Update or delete bill details
service.updateDeleteBillDetails = async (req, res, next) => {
  try {
    console.log('Request body:', req.body);
    
    const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
    const bill_details_id = req.body.bill_details_id;

    if (changedUpdatedValue === 'edit') {
      const {
        site_code = '',
        site_name = '',
        entry_date = '',
        order_year = '',
        department_name = '',
        contractor_name = '',
        sub_contractor_name = '',
        work_name = '',
        bank_name = '',
        workdone_by = [],
        agreement_no = '',
        bill_no = '',
        work_order_amount = '',
        total_bill_amount = '',
        deduction_amount = '',
        net_bill_amount = '',
        security_deposit = '',
        insurance = '',
        gst = '',
        surcharge = '',
        cess = '',
        tds = '',
        royalty = '',
        fine = '',
        other = '',
        bank_charges = '',
        stamp_duty = '',
        other_charges = '',
        description = '',
        remark = ''
      } = req.body;

      const queryStr = `UPDATE bill_details SET 
        site_code = '${site_code}',
        site_name = '${site_name}',
        entry_date = '${entry_date}',
        order_year = '${order_year}',
        department_name = '${department_name}',
        contractor_name = '${contractor_name}',
        sub_contractor_name = '${sub_contractor_name}',
        work_name = '${work_name}',
        bank_name = '${bank_name}',
        workdone_by =  ${JSON.stringify(workdone_by)},
        agreement_no = '${agreement_no}',
        bill_no = '${bill_no}',
        work_order_amount = '${work_order_amount}',
        total_bill_amount = '${total_bill_amount}',
        deduction_amount = '${deduction_amount}',
        net_bill_amount = '${net_bill_amount}',
        security_deposit = '${security_deposit}',
        insurance = '${insurance}',
        gst = '${gst}',
        surcharge = '${surcharge}',
        cess = '${cess}',
        tds = '${tds}',
        royalty = '${royalty}',
        fine = '${fine}',
        other = '${other}',
        bank_charges = '${bank_charges}',
        stamp_duty = '${stamp_duty}',
        other_charges = '${other_charges}',
        description = '${description}',
        remark = '${remark}'
        WHERE bill_details_id = ${bill_details_id}`;

      console.log('Generated SQL query:', queryStr);
      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Bill Details Updated Successfully!' });

    } else if (changedUpdatedValue === 'delete') {
      const queryStr = `UPDATE bill_details SET 
        is_deleted = 1
        WHERE bill_details_id = ${bill_details_id}`;

      await lib.queryExecute(queryStr);
      res.status(200).send({ message: 'Bill Details Deleted Successfully!' });
    } else {
      res.status(400).send({ error: 'Invalid changed update value' });
    }
  } catch (error) {
    console.error('Error in updateBillDetails:', error);
    res.status(500).send({ error: error.message || error });
  }
};

module.exports = service;