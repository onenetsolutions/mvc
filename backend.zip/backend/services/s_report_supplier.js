const { queryExecute } = require("../libs/dbRequest");
const { generatePDF, commonStyles, formatCurrency, formatDate, esc } = require('../libs/pdfGenerator');

const getSupplierReport = async (supplierId, siteCode = null) => {
  try {
    // Get Supplier details
    const supplierQuery = `
      SELECT 
        party_id,
        party_name,
        party_address,
        mobile_no as mobile
      FROM party_master
      WHERE party_id = '${supplierId}' AND party_type = 'Supplier' AND is_deleted = 0
    `;
    const supplier = await queryExecute(supplierQuery);

    if (!supplier || supplier.length === 0) {
      return { success: false, message: 'Supplier not found' };
    }

    const supplierName = supplier[0].party_name;
    const siteFilter = siteCode ? ` AND site_code = '${siteCode}'` : '';

    // ── 1. Material Entry ────────────────────────────────────────────────────
    const materialEntryQuery = `
      SELECT
        entry_date AS date,
        site_code,
        site_name,
        material_details,
        amount,
        other_charges,
        remark,
        partner_name,
        challan_no
      FROM material_entry
      WHERE supplier = '${supplierName}' AND is_deleted = 0
        AND (machinery_type IS NULL OR machinery_type = '')
      ${siteFilter}
      ORDER BY site_code, entry_date
    `;
    const materialEntriesTemp = await queryExecute(materialEntryQuery);

    // Process JSON to expand material_details
    const materialEntries = [];
    materialEntriesTemp.forEach(row => {
      let details = [];
      try {
        if (row.material_details && typeof row.material_details === 'string') {
          details = JSON.parse(row.material_details);
        } else if (Array.isArray(row.material_details)) {
          details = row.material_details;
        }
      } catch (e) {
        console.error("Error parsing material_details:", e);
      }

      if (details.length > 0) {
        details.forEach((item, idx) => {
          materialEntries.push({
            ...row,
            material_name: item.material_name || '-',
            quantity: parseFloat(item.quantity) || 0,
            rate: parseFloat(item.rate) || 0,
            amount: (parseFloat(item.quantity) || 0) * (parseFloat(item.rate) || 0),
            total_amount: ((parseFloat(item.quantity) || 0) * (parseFloat(item.rate) || 0)) + (idx === 0 ? (parseFloat(row.other_charges) || 0) : 0),
            other_charges: idx === 0 ? (parseFloat(row.other_charges) || 0) : 0
          });
        });
      } else {
        // Fallback if no details
        materialEntries.push({
          ...row,
          material_name: '-',
          quantity: 0,
          rate: 0,
          total_amount: parseFloat(row.amount) || 0
        });
      }
    });

    // ── 2. Daily Expenses  (paid_to = supplier name) ─────────────────────────
    const dailyExpensesQuery = `
      SELECT
        expense_date AS date,
        site_code,
        site_name,
        description,
        paid_to,
        payment_through,
        amount,
        payment_mode,
        paid_by,
        expense_type,
        voucher_no
      FROM daily_expenses
      WHERE paid_to = '${supplierName}' AND is_deleted = 0
      ${siteFilter}
      ORDER BY site_code, expense_date
    `;
    const dailyExpenses = await queryExecute(dailyExpensesQuery);

    // ── 3. MV Tipper  (crusher_owner = supplier name) ────────────────────────
    const mvTipperQuery = `
      SELECT
        entry_date AS date,
        site_code,
        site_name,
        crusher_owner,
        party_name,
        material_name,
        qty,
        rate,
        (COALESCE(qty, 0) * COALESCE(rate, 0)) AS total_amount,
        description,
        partner_name
      FROM mvtipper_details
      WHERE crusher_owner = '${supplierName}' AND is_deleted = 0
      ${siteFilter}
      ORDER BY site_code, entry_date
    `;
    const mvTippers = await queryExecute(mvTipperQuery);

    // ── Helper: group rows by site_code ──────────────────────────────────────
    const collectSites = (rows) => {
      const map = {};
      rows.forEach(r => {
        const key = r.site_code || 'Unknown';
        if (!map[key]) map[key] = { site_code: r.site_code || 'Unknown', site_name: r.site_name || '' };
      });
      return map;
    };

    // Build unified site map
    const allSites = {
      ...collectSites(materialEntries),
      ...collectSites(dailyExpenses),
      ...collectSites(mvTippers),
    };

    // ── Build per-site breakdown ──────────────────────────────────────────────
    const siteList = Object.values(allSites).map(site => {
      const sk = site.site_code;

      // Material entries for this site, grouped by material
      const materialRows = materialEntries.filter(r => (r.site_code || 'Unknown') === sk);
      const materialsByName = {};
      let siteMaterialTotal = 0;
      materialRows.forEach(r => {
        const mk = r.material_name || 'Unknown';
        if (!materialsByName[mk]) materialsByName[mk] = { material_name: mk, entries: [], totalQty: 0, totalAmount: 0 };
        materialsByName[mk].entries.push(r);
        materialsByName[mk].totalQty += parseFloat(r.quantity) || 0;
        materialsByName[mk].totalAmount += parseFloat(r.total_amount) || parseFloat(r.amount) || 0;
        siteMaterialTotal += parseFloat(r.total_amount) || parseFloat(r.amount) || 0;
      });

      // Daily expenses for this site
      const expenseRows = dailyExpenses.filter(r => (r.site_code || 'Unknown') === sk);
      let siteExpenseTotal = 0;
      expenseRows.forEach(r => { siteExpenseTotal += parseFloat(r.amount) || 0; });

      // MV Tipper rows for this site
      const tipperRows = mvTippers.filter(r => (r.site_code || 'Unknown') === sk);
      let siteTipperTotal = 0;
      tipperRows.forEach(r => { siteTipperTotal += parseFloat(r.total_amount) || 0; });

      return {
        site_code: sk,
        site_name: site.site_name,
        // Material supply
        materials: Object.values(materialsByName),
        siteMaterialTotal,
        // Daily expenses
        dailyExpenses: expenseRows,
        siteExpenseTotal,
        // MV Tipper
        mvTippers: tipperRows,
        siteTipperTotal,
        // Grand total for this site
        siteGrandTotal: siteMaterialTotal + siteExpenseTotal + siteTipperTotal,
      };
    });

    // ── Grand totals ──────────────────────────────────────────────────────────
    const grandMaterialTotal = siteList.reduce((s, x) => s + x.siteMaterialTotal, 0);
    const grandExpenseTotal = siteList.reduce((s, x) => s + x.siteExpenseTotal, 0);
    const grandTipperTotal = siteList.reduce((s, x) => s + x.siteTipperTotal, 0);

    return {
      success: true,
      data: {
        supplier: supplier[0],
        site_data: siteList,
        summary: {
          grand_material_total: grandMaterialTotal,
          grand_expense_total: grandExpenseTotal,
          grand_tipper_total: grandTipperTotal,
          grand_total: grandMaterialTotal + grandExpenseTotal + grandTipperTotal,
        }
      }
    };
  } catch (error) {
    console.error("Error in getSupplierReport:", error);
    return { success: false, message: error.message };
  }
};

// Get list of suppliers for dropdown
const getSuppliers = async () => {
  try {
    const query = `
      SELECT 
        party_id,
        party_name
      FROM party_master
      WHERE party_type = 'Supplier' AND is_deleted = 0
      ORDER BY party_name
    `;
    const suppliers = await queryExecute(query);
    return {
      success: true,
      data: suppliers
    };
  } catch (error) {
    console.error("Error in getSuppliers:", error);
    return {
      success: false,
      message: error.message
    };
  }
};

// Get site codes for dropdown
const getSiteCodes = async () => {
  try {
    const query = `
      SELECT DISTINCT 
        site_code,
        site_name
      FROM work_order
      WHERE site_code IS NOT NULL AND site_code != ''
      ORDER BY site_code
    `;
    const sites = await queryExecute(query);
    return {
      success: true,
      data: sites
    };
  } catch (error) {
    console.error("Error in getSiteCodes:", error);
    return {
      success: false,
      message: error.message
    };
  }
};

const generateSupplierReportPDF = async (supplierId, siteCode, data, res) => {
  const html = `<!DOCTYPE html><html><head><style>${commonStyles}</style></head><body>
    <div class="report-title">Supplier Wise Report</div>

    <div class="section-header">Supplier Details</div>
    <div class="info-row"><span class="info-label">Name:</span> ${esc(data.supplier.party_name)}</div>
    <div class="info-row"><span class="info-label">Address:</span> ${esc(data.supplier.party_address)}</div>
    <div class="info-row"><span class="info-label">Mobile:</span> ${esc(data.supplier.mobile)}</div>
    ${siteCode ? `<div class="info-row"><span class="info-label">Site Code:</span> ${esc(siteCode)}</div>` : ''}
    <div class="info-row"><span class="info-label">Generated on:</span> ${new Date().toLocaleDateString('en-GB')}</div>

    <div class="summary-bar">
      <div class="summary-chip"><span class="label">Material Total: </span><span class="value">${formatCurrency(data.summary.grand_material_total)}</span></div>
      <div class="summary-chip"><span class="label">Daily Expenses Total: </span><span class="value">${formatCurrency(data.summary.grand_expense_total)}</span></div>
      <div class="summary-chip"><span class="label">MV Tipper Total: </span><span class="value">${formatCurrency(data.summary.grand_tipper_total)}</span></div>
      <div class="summary-chip highlight"><span class="label">Grand Total: </span><span class="value">${formatCurrency(data.summary.grand_total)}</span></div>
    </div>

    ${data.site_data.length > 0 ? data.site_data.map(site => `
      <div class="site-header">Site: ${esc(site.site_code)} ${site.site_name ? '&mdash; ' + esc(site.site_name) : ''}</div>

      ${site.materials && site.materials.length > 0 ? site.materials.map(material => `
        <div class="sub-header">Material: ${esc(material.material_name)}</div>
        <table>
          <thead><tr>
            <th>Date</th><th class="text-right">Quantity</th><th class="text-right">Rate</th>
            <th class="text-right">Amount</th><th>Paid By (Partner)</th><th>Remark</th>
          </tr></thead>
          <tbody>
            ${material.entries.map(e => `<tr>
              <td>${esc(formatDate(e.date))}</td><td class="text-right">${esc(e.quantity)}</td>
              <td class="text-right">${formatCurrency(e.rate)}</td>
              <td class="text-right">${formatCurrency(e.total_amount || e.amount)}</td>
              <td>${esc(e.partner_name)}</td><td>${esc(e.remark)}</td>
            </tr>`).join('')}
            <tr class="total-row">
              <td colspan="3" class="text-right">Material Total:</td>
              <td class="text-right">${formatCurrency(material.totalAmount)}</td><td colspan="2"></td>
            </tr>
          </tbody>
        </table>
      `).join('') + `<div style="text-align:right;font-weight:bold;color:#1976d2;margin:5px 0;">Site Material Total: ${formatCurrency(site.siteMaterialTotal)}</div>` : ''}

      ${site.dailyExpenses && site.dailyExpenses.length > 0 ? `
        <div class="sub-header">Daily Expenses</div>
        <table>
          <thead><tr>
            <th>Date</th><th>Description</th><th>Payment Through</th>
            <th class="text-right">Amount</th><th>Payment Mode</th><th>Paid By</th><th>Expense Type</th>
          </tr></thead>
          <tbody>
            ${site.dailyExpenses.map(e => `<tr>
              <td>${esc(formatDate(e.date))}</td><td>${esc(e.description)}</td><td>${esc(e.payment_through)}</td>
              <td class="text-right">${formatCurrency(e.amount)}</td><td>${esc(e.payment_mode)}</td>
              <td>${esc(e.paid_by)}</td><td>${esc(e.expense_type)}</td>
            </tr>`).join('')}
            <tr class="total-row">
              <td colspan="3" class="text-right">Expense Total:</td>
              <td class="text-right">${formatCurrency(site.siteExpenseTotal)}</td><td colspan="3"></td>
            </tr>
          </tbody>
        </table>` : ''}

      ${site.mvTippers && site.mvTippers.length > 0 ? `
        <div class="sub-header">MV Tipper</div>
        <table>
          <thead><tr>
            <th>Date</th><th>Party</th><th>Material</th><th class="text-right">Qty</th>
            <th class="text-right">Rate</th><th class="text-right">Amount</th><th>Paid By</th><th>Description</th>
          </tr></thead>
          <tbody>
            ${site.mvTippers.map(t => `<tr>
              <td>${esc(formatDate(t.date))}</td><td>${esc(t.party_name)}</td><td>${esc(t.material_name)}</td>
              <td class="text-right">${esc(t.qty)}</td><td class="text-right">${formatCurrency(t.rate)}</td>
              <td class="text-right">${formatCurrency(t.total_amount)}</td><td>${esc(t.partner_name)}</td>
              <td>${esc(t.description)}</td>
            </tr>`).join('')}
            <tr class="total-row">
              <td colspan="5" class="text-right">MV Tipper Total:</td>
              <td class="text-right">${formatCurrency(site.siteTipperTotal)}</td><td colspan="2"></td>
            </tr>
          </tbody>
        </table>` : ''}

      <div style="text-align:right;font-weight:bold;font-size:11px;margin:8px 0;">Site Grand Total: ${formatCurrency(site.siteGrandTotal)}</div>
    `).join('') : '<div class="no-data">No records found for this supplier.</div>'}
  </body></html>`;

  const filename = `Supplier_Report_${(data.supplier.party_name || '').replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.pdf`;
  await generatePDF(html, res, filename, { layout: 'landscape' });
};

module.exports = {
  getSupplierReport,
  getSuppliers,
  getSiteCodes,
  generateSupplierReportPDF
};
