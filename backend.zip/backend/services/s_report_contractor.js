const { queryExecute } = require("../libs/dbRequest");
const { generatePDF, commonStyles, formatCurrency, formatDate, esc } = require('../libs/pdfGenerator');

// For Contractors – Combined ledger view
// - Amount to be given  : credit_entry WHERE party_name = contractor
// - Amount given        : daily_expenses + payment_entry WHERE paid_to = contractor
// - Returns a single combined ledger sorted by date
const getContractorReport = async (siteCode, contractorId = null) => {
  try {
    if (!contractorId) {
      return { success: false, message: 'Contractor is required' };
    }

    // Contractor details
    const contractorQuery = `
      SELECT party_id, party_name, party_address, mobile_no, party_type
      FROM party_master
      WHERE party_type = 'Contractor' AND is_deleted = 0 AND party_id = '${contractorId}'
      LIMIT 1
    `;
    const contractors = await queryExecute(contractorQuery);
    if (!contractors || contractors.length === 0) {
      return { success: false, message: 'Contractor not found' };
    }
    const contractor = contractors[0];
    const contractorName = contractor.party_name;

    // ── Amount to be given: credit entries for this contractor ────────────
    const creditQuery = `
      SELECT
        ce.credit_entry_id,
        ce.date,
        ce.party_name,
        ce.ref,
        ce.description,
        ce.amount,
        ce.credited_to
      FROM credit_entry ce
      WHERE ce.party_name = '${contractorName}' AND ce.is_deleted = 0
      ORDER BY ce.date ASC
    `;
    const creditEntries = await queryExecute(creditQuery);
    const creditTotal = creditEntries.reduce((s, r) => s + (parseFloat(r.amount) || 0), 0);

    // ── Amount given: daily_expenses for this contractor ─────────────────
    const siteFilterDE = siteCode ? `AND de.site_code = '${siteCode}'` : '';
    const expenseQuery = `
      SELECT
        de.expense_date AS date,
        de.paid_to,
        de.description,
        de.amount,
        de.paid_by
      FROM daily_expenses de
      WHERE de.paid_to = '${contractorName}' AND de.is_deleted = 0
      ${siteFilterDE}
      ORDER BY de.expense_date ASC
    `;
    const expenseRows = await queryExecute(expenseQuery);

    // ── Amount given: payment_entry for this contractor ──────────────────
    const paymentQuery = `
      SELECT
        pe.entry_date AS date,
        pe.paid_to,
        pe.description,
        pe.total_amount AS amount,
        pe.paid_by
      FROM payment_entry pe
      WHERE pe.paid_to = '${contractorName}' AND pe.is_deleted = 0
      ORDER BY pe.entry_date ASC
    `;
    const paymentRows = await queryExecute(paymentQuery);

    // ── Build combined ledger rows ───────────────────────────────────────
    const ledgerRows = [];

    // Credit entries → amount_to_be_given
    creditEntries.forEach(ce => {
      ledgerRows.push({
        date: ce.date,
        contractor_name: contractorName,
        amount_to_be_given: parseFloat(ce.amount) || 0,
        amount_given: 0,
        paid_by: '-',
        remark: ce.description || '-',
        source: 'credit_entry'
      });
    });

    // Daily expenses → amount_given
    expenseRows.forEach(de => {
      ledgerRows.push({
        date: de.date,
        contractor_name: contractorName,
        amount_to_be_given: 0,
        amount_given: parseFloat(de.amount) || 0,
        paid_by: de.paid_by || '-',
        remark: de.description || '-',
        source: 'daily_expenses'
      });
    });

    // Payment entries → amount_given
    paymentRows.forEach(pe => {
      ledgerRows.push({
        date: pe.date,
        contractor_name: contractorName,
        amount_to_be_given: 0,
        amount_given: parseFloat(pe.amount) || 0,
        paid_by: pe.paid_by || '-',
        remark: pe.description || '-',
        source: 'payment_entry'
      });
    });

    // Sort by date ascending
    ledgerRows.sort((a, b) => new Date(a.date) - new Date(b.date));

    // Calculate running balance
    let runningToBeGiven = 0;
    let runningGiven = 0;
    ledgerRows.forEach(row => {
      runningToBeGiven += row.amount_to_be_given;
      runningGiven += row.amount_given;
      row.balance_amount = runningToBeGiven - runningGiven;
    });

    const totalGiven = runningGiven;

    return {
      success: true,
      data: {
        contractor: {
          party_id: contractor.party_id,
          contractor_name: contractorName,
          party_address: contractor.party_address,
          mobile_no: contractor.mobile_no,
        },
        rows: ledgerRows,
        summary: {
          total_amount_to_be_given: creditTotal,
          total_amount_given: totalGiven,
          balance_amount: creditTotal - totalGiven
        }
      }
    };
  } catch (error) {
    console.error("Error in getContractorReport:", error);
    return { success: false, message: error.message };
  }
};

// For Labour Contractors - with manual entry form
const getLabourContractorReport = async (siteCode, labourContractorId = null, manualEntry = null) => {
  try {
    if (!siteCode) {
      return { success: false, message: 'Site Code is required' };
    }
    if (!labourContractorId) {
      return { success: false, message: 'Labour Contractor is required' };
    }

    const siteQuery = `
      SELECT site_code, site_name
      FROM work_order
      WHERE site_code = '${siteCode}' AND is_deleted = 0
      LIMIT 1
    `;
    const siteRows = await queryExecute(siteQuery);
    const site = siteRows[0] || { site_code: siteCode, site_name: '' };

    // Get the selected labour contractor
    const labourContractorQuery = `
      SELECT party_id, party_name, party_type, party_address, mobile_no
      FROM party_master
      WHERE party_type = 'Labour Contractor' AND is_deleted = 0 AND party_id = '${labourContractorId}'
      LIMIT 1
    `;
    const labourContractors = await queryExecute(labourContractorQuery);

    if (!labourContractors || labourContractors.length === 0) {
      return {
        success: true,
        data: {
          site,
          labour_contractor: null,
          rows: [],
          summary: { total_amount_to_be_given: 0, total_amount_given: 0, balance_amount: 0 }
        }
      };
    }

    const labourContractor = labourContractors[0];
    const lcName = labourContractor.party_name;

    // Get Daily Expenses for this specific labour contractor at this site
    const dailyExpensesQuery = `
      SELECT 
        de.expense_date AS date,
        de.paid_to AS labour_contractor_name,
        de.amount AS amount_given,
        de.paid_by,
        de.description AS remark
      FROM daily_expenses de
      WHERE de.site_code = '${siteCode}' AND de.is_deleted = 0
      AND de.paid_to = '${lcName}'
      ORDER BY de.expense_date ASC
    `;
    const dailyExpenses = await queryExecute(dailyExpensesQuery);

    // Get Payment Entries for this specific labour contractor
    const paymentEntryQuery = `
      SELECT 
        pe.entry_date AS date,
        pe.paid_to AS labour_contractor_name,
        pe.total_amount AS amount_given,
        pe.paid_by,
        pe.description AS remark
      FROM payment_entry pe
      WHERE pe.is_deleted = 0
      AND pe.paid_to = '${lcName}'
      ORDER BY pe.entry_date ASC
    `;
    const paymentEntries = await queryExecute(paymentEntryQuery);

    const amountToBeGiven = manualEntry && manualEntry.amount ? parseFloat(manualEntry.amount) : 0;

    const rows = [];

    // Manual entry row (amount to be given)
    if (manualEntry && manualEntry.amount) {
      rows.push({
        date: manualEntry.start_date || null,
        labour_contractor_name: lcName,
        amount_to_be_given: amountToBeGiven,
        amount_given: 0,
        paid_by: '-',
        remark: '-',
        manual_description: manualEntry.description || '-'
      });
    }

    // Daily expenses (amount given)
    dailyExpenses.forEach(entry => {
      rows.push({
        date: entry.date,
        labour_contractor_name: entry.labour_contractor_name,
        amount_to_be_given: 0,
        amount_given: parseFloat(entry.amount_given) || 0,
        paid_by: entry.paid_by || '-',
        remark: entry.remark || '-',
        manual_description: manualEntry ? (manualEntry.description || '-') : '-'
      });
    });

    // Payment entries (amount given)
    paymentEntries.forEach(entry => {
      rows.push({
        date: entry.date,
        labour_contractor_name: entry.labour_contractor_name,
        amount_to_be_given: 0,
        amount_given: parseFloat(entry.amount_given) || 0,
        paid_by: entry.paid_by || '-',
        remark: entry.remark || '-',
        manual_description: manualEntry ? (manualEntry.description || '-') : '-'
      });
    });

    // Sort by date ascending
    rows.sort((a, b) => new Date(a.date) - new Date(b.date));

    // Calculate running balance
    let runningToBeGiven = 0;
    let runningGiven = 0;
    rows.forEach(row => {
      runningToBeGiven += row.amount_to_be_given || 0;
      runningGiven += row.amount_given || 0;
      row.balance_amount = runningToBeGiven - runningGiven;
    });

    return {
      success: true,
      data: {
        site,
        labour_contractor: {
          party_id: labourContractor.party_id,
          labour_contractor_name: lcName
        },
        rows,
        summary: {
          total_amount_to_be_given: amountToBeGiven,
          total_amount_given: runningGiven,
          balance_amount: amountToBeGiven - runningGiven
        }
      }
    };
  } catch (error) {
    console.error("Error in getLabourContractorReport:", error);
    return { success: false, message: error.message };
  }
};

// Get list of contractors for dropdown
const getContractors = async () => {
  try {
    const query = `
      SELECT 
        party_id,
        party_name,
        party_type
      FROM party_master
      WHERE party_type = 'Contractor' AND is_deleted = 0
      ORDER BY party_name
    `;
    const contractors = await queryExecute(query);
    return {
      success: true,
      data: contractors
    };
  } catch (error) {
    console.error("Error in getContractors:", error);
    return {
      success: false,
      message: error.message
    };
  }
};

// Get list of labour contractors for dropdown
const getLabourContractors = async () => {
  try {
    const query = `
      SELECT 
        party_id,
        party_name,
        party_type
      FROM party_master
      WHERE party_type = 'Labour Contractor' AND is_deleted = 0
      ORDER BY party_name
    `;
    const labourContractors = await queryExecute(query);
    return {
      success: true,
      data: labourContractors
    };
  } catch (error) {
    console.error("Error in getLabourContractors:", error);
    return {
      success: false,
      message: error.message
    };
  }
};

// Get site codes for dropdown
const getSiteCodes = async () => {
  try {
    const query = `
      SELECT DISTINCT 
        site_code,
        site_name
      FROM work_order
      WHERE site_code IS NOT NULL AND site_code != ''
      ORDER BY site_code
    `;
    const sites = await queryExecute(query);
    return {
      success: true,
      data: sites
    };
  } catch (error) {
    console.error("Error in getSiteCodes:", error);
    return {
      success: false,
      message: error.message
    };
  }
};

const generateContractorReportPDF = async (siteCode, contractorId, data, res) => {
  const rows = data.rows || [];
  const html = `<!DOCTYPE html><html><head><style>${commonStyles}</style></head><body>
    <div class="report-title">Contractor Report</div>
    <div class="section-header">Contractor Details</div>
    <div class="info-row"><span class="info-label">Name:</span> ${esc(data.contractor.contractor_name)}</div>
    <div class="info-row"><span class="info-label">Address:</span> ${esc(data.contractor.party_address)}</div>
    <div class="info-row"><span class="info-label">Mobile:</span> ${esc(data.contractor.mobile_no)}</div>
    ${siteCode ? `<div class="info-row"><span class="info-label">Site Code:</span> ${esc(siteCode)}</div>` : ''}
    <div class="info-row"><span class="info-label">Generated on:</span> ${new Date().toLocaleDateString('en-GB')}</div>
    <div class="summary-bar">
      <div class="summary-chip"><span class="label">Total Amount to be Given: </span><span class="value">${formatCurrency(data.summary.total_amount_to_be_given)}</span></div>
      <div class="summary-chip"><span class="label">Total Amount Given: </span><span class="value">${formatCurrency(data.summary.total_amount_given)}</span></div>
      <div class="summary-chip highlight"><span class="label">Balance Amount: </span><span class="value">${formatCurrency(data.summary.balance_amount)}</span></div>
    </div>
    ${rows.length > 0 ? `
    <div class="section-header">Contractor Ledger</div>
    <table>
      <thead><tr>
        <th>Date</th><th>Contractor Name</th><th class="text-right">Amount to be Given</th>
        <th class="text-right">Amount Given</th><th class="text-right">Balance</th><th>Paid By</th><th>Remark</th>
      </tr></thead>
      <tbody>
        ${rows.map(r => `<tr>
          <td>${esc(formatDate(r.date))}</td><td>${esc(r.contractor_name)}</td>
          <td class="text-right">${r.amount_to_be_given ? formatCurrency(r.amount_to_be_given) : '-'}</td>
          <td class="text-right">${r.amount_given ? formatCurrency(r.amount_given) : '-'}</td>
          <td class="text-right">${formatCurrency(r.balance_amount)}</td>
          <td>${esc(r.paid_by)}</td><td>${esc(r.remark)}</td>
        </tr>`).join('')}
        <tr class="total-row">
          <td colspan="2" class="text-right">Total:</td>
          <td class="text-right">${formatCurrency(data.summary.total_amount_to_be_given)}</td>
          <td class="text-right">${formatCurrency(data.summary.total_amount_given)}</td>
          <td class="text-right">${formatCurrency(data.summary.balance_amount)}</td>
          <td colspan="2"></td>
        </tr>
      </tbody>
    </table>` : '<div class="no-data">No entries found for this contractor.</div>'}
  </body></html>`;

  const filename = `Contractor_Report_${(data.contractor.contractor_name || '').replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.pdf`;
  await generatePDF(html, res, filename, { layout: 'landscape' });
};

const generateLabourContractorReportPDF = async (siteCode, data, res) => {
  const rows = data.rows || [];
  const lcName = data.labour_contractor ? data.labour_contractor.labour_contractor_name : 'All';
  const html = `<!DOCTYPE html><html><head><style>${commonStyles}</style></head><body>
    <div class="report-title">Labour Contractor Report</div>
    <div class="section-header">Details</div>
    <div class="info-row"><span class="info-label">Labour Contractor:</span> ${esc(lcName)}</div>
    <div class="info-row"><span class="info-label">Site:</span> ${esc(data.site.site_code)} - ${esc(data.site.site_name)}</div>
    <div class="info-row"><span class="info-label">Generated on:</span> ${new Date().toLocaleDateString('en-GB')}</div>
    <div class="summary-bar">
      <div class="summary-chip"><span class="label">Total Amount to be Given: </span><span class="value">${formatCurrency(data.summary.total_amount_to_be_given)}</span></div>
      <div class="summary-chip"><span class="label">Total Amount Given: </span><span class="value">${formatCurrency(data.summary.total_amount_given)}</span></div>
      <div class="summary-chip highlight"><span class="label">Balance Amount: </span><span class="value">${formatCurrency(data.summary.balance_amount)}</span></div>
    </div>
    ${rows.length > 0 ? `
    <table>
      <thead><tr>
        <th>Date</th><th>Labour Contractor</th><th class="text-right">Amount to be Given</th>
        <th class="text-right">Amount Given</th><th class="text-right">Balance</th><th>Paid By</th><th>Remark</th><th>Description</th>
      </tr></thead>
      <tbody>
        ${rows.map(r => `<tr>
          <td>${esc(formatDate(r.date))}</td><td>${esc(r.labour_contractor_name)}</td>
          <td class="text-right">${formatCurrency(r.amount_to_be_given)}</td>
          <td class="text-right">${formatCurrency(r.amount_given)}</td>
          <td class="text-right">${formatCurrency(r.balance_amount)}</td>
          <td>${esc(r.paid_by)}</td><td>${esc(r.remark)}</td><td>${esc(r.manual_description)}</td>
        </tr>`).join('')}
      </tbody>
    </table>` : '<div class="no-data">No labour contractor entries found.</div>'}
  </body></html>`;

  const filename = `Labour_Contractor_Report_${siteCode}_${new Date().toISOString().slice(0, 10)}.pdf`;
  await generatePDF(html, res, filename, { layout: 'landscape' });
};

module.exports = {
  getContractorReport,
  getLabourContractorReport,
  getContractors,
  getLabourContractors,
  getSiteCodes,
  generateContractorReportPDF,
  generateLabourContractorReportPDF
};
