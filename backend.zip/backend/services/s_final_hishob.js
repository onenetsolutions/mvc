const { queryExecute } = require('../libs/dbRequest');
const { generatePDF, commonStyles, formatCurrency, formatDate, esc } = require('../libs/pdfGenerator');

const getSiteCodes = async () => {
  const query = `
    SELECT DISTINCT site_code, site_name
    FROM work_order
    WHERE site_code IS NOT NULL AND site_code != ''
    ORDER BY site_code
  `;
  const rows = await queryExecute(query);
  return { success: true, data: rows };
};

const getFinalHishob = async (siteCode) => {
  try {
    const siteQuery = `
      SELECT 
        wo.site_code,
        wo.site_name,
        wo.work_name,
        wo.contractor_name,
        wo.work_order_amount as work_amount,
        wo.workdone_by,
        wo.work_order_date,
        wo.security_deposit_amount,
        wo.additional_security_deposit_amount,
        wo.security_deposit as security_deposit_json,
        wo.additionalsecurity_deposit as additionalsecurity_deposit_json,
        t.entry_date as tender_date,
        t.contractor_details as bidders_json,
        t.tender_id_user as tender_id
      FROM work_order wo
      LEFT JOIN tender t ON t.sr_no = wo.sr_no AND t.is_deleted = 0
      WHERE wo.site_code = '${siteCode}'
      ORDER BY wo.work_order_date DESC
      LIMIT 1
    `;
    const siteRows = await queryExecute(siteQuery);
    const site = siteRows[0] || {};

    let partners = [];
    try {
      if (site.workdone_by && site.workdone_by.startsWith('[')) {
        const parsed = JSON.parse(site.workdone_by);
        if (Array.isArray(parsed)) partners = parsed;
      }
    } catch (e) {
      partners = [];
    }

    // Parse tender/work order JSON for expense extraction
    let bidders = [];
    let securityDeposits = [];
    let additionalSecurityDeposits = [];
    try {
      if (site.bidders_json && String(site.bidders_json).trim().startsWith('[')) {
        bidders = JSON.parse(site.bidders_json);
      }
      if (site.security_deposit_json && String(site.security_deposit_json).trim().startsWith('[')) {
        securityDeposits = JSON.parse(site.security_deposit_json);
      }
      if (site.additionalsecurity_deposit_json && String(site.additionalsecurity_deposit_json).trim().startsWith('[')) {
        additionalSecurityDeposits = JSON.parse(site.additionalsecurity_deposit_json);
      }
    } catch (e) {
      console.error('JSON parse error in Final Hishob:', e);
    }

    // Extract tender fee & EMD from winning bidder
    let tenderFeeAmount = 0, tenderFeePaidBy = '';
    let emdAmount = 0, emdPaidBy = '';
    if (bidders.length > 0) {
      const winningBidder = bidders.find(b => b.contractor_name === site.contractor_name) || bidders[0];
      tenderFeeAmount = parseFloat(winningBidder.tender_fee) || 0;
      tenderFeePaidBy = winningBidder.paid_by || '';
      emdAmount = parseFloat(winningBidder.emd_amount) || 0;
      emdPaidBy = winningBidder.paid_by || '';
    }

    const subContractorQuery = `
      SELECT sub_contractor_name
      FROM bill_details
      WHERE site_code = '${siteCode}' AND is_deleted = 0
      ORDER BY entry_date DESC
      LIMIT 1
    `;
    const subRows = await queryExecute(subContractorQuery);
    const sub_contractor_name = subRows[0]?.sub_contractor_name || '';

    const billDetailsQuery = `
      SELECT 
        entry_date as date,
        bill_no,
        total_bill_amount,
        deduction_amount,
        net_bill_amount
      FROM bill_details
      WHERE site_code = '${siteCode}' AND is_deleted = 0
      ORDER BY entry_date
    `;
    const billDetails = await queryExecute(billDetailsQuery);

    const totalNetBillAmount = billDetails.reduce(
      (sum, row) => sum + (parseFloat(row.net_bill_amount) || 0),
      0
    );

    // Daily Expenses - includes paid_by and paid_to
    const dailyExpenseQuery = `
      SELECT 
        expense_date as date,
        voucher_no as ref,
        description,
        amount,
        paid_by,
        paid_to,
        sub_payment_mode,
        'daily_expenses' as source
      FROM daily_expenses
      WHERE site_code = '${siteCode}' AND is_deleted = 0
    `;

    // Material Entry (exclude machinery entries)
    const materialQuery = `
      SELECT 
        challan_date as date,
        challan_no as ref,
        CONCAT('Material - ', COALESCE(supplier, '')) as description,
        (COALESCE(amount, 0) + COALESCE(other_charges, 0)) as amount,
        supplier as paid_to,
        partner_name as paid_by,
        NULL as sub_payment_mode,
        'material_entry' as source
      FROM material_entry
      WHERE site_code = '${siteCode}' AND is_deleted = 0
        AND (machinery_type IS NULL OR machinery_type = '')
    `;

    // Other Machinery (stored in material_entry)
    const machineryEntryQuery = `
      SELECT
        entry_date as date,
        entry_no as ref,
        CONCAT('Machinery - ', machinery_type) as description,
        machinery_total as amount,
        owner as paid_to,
        partner_name as paid_by,
        NULL as sub_payment_mode,
        'machinery_entry' as source
      FROM material_entry
      WHERE site_code = '${siteCode}' AND is_deleted = 0
        AND machinery_type IS NOT NULL AND machinery_type != ''
    `;

    // JCB Machinery
    const mvjcbQuery = `
      SELECT 
        entry_date as date,
        entry_no as ref,
        'JCB Machinery' as description,
        COALESCE(grand_total, total_amount, 0) as amount,
        party_name as paid_to,
        partner_name as paid_by,
        NULL as sub_payment_mode,
        'mvjcb' as source
      FROM mvjcb_detials
      WHERE site_code = '${siteCode}' AND is_deleted = 0
    `;

    // Roller/TT Machinery
    const mvrollertQuery = `
      SELECT 
        entry_date as date,
        entry_no as ref,
        'Roller/TT Machinery' as description,
        total_amount as amount,
        party_name as paid_to,
        partner_name as paid_by,
        NULL as sub_payment_mode,
        'mv_rollertt' as source
      FROM mv_rollertt_details
      WHERE site_code = '${siteCode}' AND is_deleted = 0
    `;

    // Tipper Machinery
    const mvtipperQuery = `
      SELECT 
        entry_date as date,
        entry_no as ref,
        'Tipper Machinery' as description,
        total_amount as amount,
        party_name as paid_to,
        partner_name as paid_by,
        NULL as sub_payment_mode,
        'mvtipper' as source
      FROM mvtipper_details
      WHERE site_code = '${siteCode}' AND is_deleted = 0
    `;

    // Salary Payments (site-specific by remark)
    const salaryQuery = `
      SELECT
        date as date,
        salary_id as ref,
        CONCAT('Salary - ', employee_name) as description,
        salary_paid as amount,
        CONCAT('Salary To: ', employee_name) as paid_to,
        COALESCE(paid_by, sub_payment_mode) as paid_by,
        sub_payment_mode,
        'salary_entry' as source
      FROM salary_entry
      WHERE is_deleted = 0
        AND site_code = '${siteCode}'
    `;

    // Payment Entry
    const paymentEntryQuery = `
      SELECT
        entry_date as date,
        payment_entry_id as ref,
        CONCAT('Payment - ', COALESCE(description, '')) as description,
        total_amount as amount,
        paid_to,
        paid_by,
        sub_payment_mode,
        'payment_entry' as source
      FROM payment_entry
      WHERE site_code = '${siteCode}' AND is_deleted = 0
    `;

    // Build allExpenses: tender to machinery (excluding payment_entry)
    const tenderWorkOrderExpenses = [];

    // Tender Entry expenses
    if (tenderFeeAmount > 0) {
      tenderWorkOrderExpenses.push({
        date: site.tender_date || null,
        ref: site.tender_id || '',
        description: `Tender Fee for ${site.tender_id || siteCode}`,
        amount: tenderFeeAmount,
        paid_to: 'Tender Fee',
        paid_by: tenderFeePaidBy,
        sub_payment_mode: null,
        source: 'tender_entry'
      });
    }
    if (emdAmount > 0) {
      tenderWorkOrderExpenses.push({
        date: site.tender_date || null,
        ref: site.tender_id || '',
        description: `EMD for ${site.tender_id || siteCode}`,
        amount: emdAmount,
        paid_to: 'EMD',
        paid_by: emdPaidBy,
        sub_payment_mode: null,
        source: 'tender_entry'
      });
    }

    // Work Order expenses (Security Deposits)
    securityDeposits.forEach(sd => {
      const amt = parseFloat(sd.fdr_amount) || 0;
      if (amt > 0) {
        tenderWorkOrderExpenses.push({
          date: site.work_order_date || null,
          ref: sd.fdr_no || '',
          description: `Security Deposit - ${sd.fdr_type || ''} ${sd.fdr_no || ''}`.trim(),
          amount: amt,
          paid_to: 'Security Deposit',
          paid_by: sd.fdr_amount_paid_by || '',
          sub_payment_mode: null,
          source: 'work_order_entry'
        });
      }
    });
    additionalSecurityDeposits.forEach(asd => {
      const amt = parseFloat(asd.fdr_amount) || 0;
      if (amt > 0) {
        tenderWorkOrderExpenses.push({
          date: site.work_order_date || null,
          ref: asd.fdr_no || '',
          description: `Additional SD - ${asd.fdr_type || ''} ${asd.fdr_no || ''}`.trim(),
          amount: amt,
          paid_to: 'Additional Security Deposit',
          paid_by: asd.fdr_amount_paid_by || '',
          sub_payment_mode: null,
          source: 'work_order_entry'
        });
      }
    });

    const allExpenses = [
      ...tenderWorkOrderExpenses,
      ...(await queryExecute(dailyExpenseQuery)),
      ...(await queryExecute(materialQuery)),
      ...(await queryExecute(machineryEntryQuery)),
      ...(await queryExecute(mvjcbQuery)),
      ...(await queryExecute(mvrollertQuery)),
      ...(await queryExecute(mvtipperQuery)),
      ...(await queryExecute(salaryQuery)),
      ...(await queryExecute(paymentEntryQuery))
    ];

    const totalExpense = allExpenses.reduce(
      (sum, row) => sum + (parseFloat(row.amount) || 0),
      0
    );

    // Partner-wise expense aggregation: grouped by paid_by (partner) and paid_to (party)
    const expenseByPartnerParty = {};
    allExpenses.forEach(row => {
      const paidByPartner = row.paid_by || row.sub_payment_mode || 'General';
      const paidToParty = row.paid_to || 'Unspecified';
      const amount = parseFloat(row.amount) || 0;
      const source = row.source || '';

      if (!expenseByPartnerParty[paidByPartner]) {
        expenseByPartnerParty[paidByPartner] = {};
      }
      if (!expenseByPartnerParty[paidByPartner][paidToParty]) {
        expenseByPartnerParty[paidByPartner][paidToParty] = { amount: 0, sources: new Set() };
      }
      expenseByPartnerParty[paidByPartner][paidToParty].amount += amount;
      if (source) expenseByPartnerParty[paidByPartner][paidToParty].sources.add(source);
    });

    // Convert to array format for easier processing
    const expenseDetails = [];
    let srNo = 1;
    Object.keys(expenseByPartnerParty).forEach(partner => {
      const partyExpenses = expenseByPartnerParty[partner];
      Object.keys(partyExpenses).forEach(party => {
        const entry = partyExpenses[party];
        const sourceLabels = {
          'tender_entry': 'Tender Entry',
          'work_order_entry': 'Work Order',
          'daily_expenses': 'Daily Expenses',
          'material_entry': 'Material',
          'machinery_entry': 'Machinery',
          'mvjcb': 'JCB Machinery',
          'mv_rollertt': 'Roller/TT',
          'mvtipper': 'Tipper',
          'salary_entry': 'Salary',
          'payment_entry': 'Payment Entry'
        };
        const sourceDisplay = Array.from(entry.sources).map(s => sourceLabels[s] || s).join(', ');
        expenseDetails.push({
          sr: srNo++,
          partner_name: partner,
          party_name: party,
          paid_to: party,
          paid_by: partner,
          total_amount: entry.amount,
          source: sourceDisplay
        });
      });
    });

    // Aggregate partner-wise totals
    const partnerTotals = {};
    expenseByPartnerParty;
    allExpenses.forEach(row => {
      const partner = row.paid_by || row.sub_payment_mode || 'General';
      const amount = parseFloat(row.amount) || 0;
      if (!partnerTotals[partner]) partnerTotals[partner] = 0;
      partnerTotals[partner] += amount;
    });

    const manualQuery = `
      SELECT other_charges, net_profit_json, partner_receivable_json, is_closed
      FROM final_hishob
      WHERE site_code = '${siteCode}'
      LIMIT 1
    `;
    const manualRows = await queryExecute(manualQuery);
    const manual = manualRows[0] || {
      other_charges: 0,
      net_profit_json: '[]',
      partner_receivable_json: '[]',
      is_closed: 0
    };

    let netProfitList = [];
    let partnerReceivableList = [];
    try {
      netProfitList = JSON.parse(manual.net_profit_json || '[]');
    } catch (e) {
      netProfitList = [];
    }

    try {
      partnerReceivableList = JSON.parse(manual.partner_receivable_json || '[]');
    } catch (e) {
      partnerReceivableList = [];
    }

    const otherCharges = parseFloat(manual.other_charges) || 0;
    const totalReceived = totalNetBillAmount - otherCharges;
    const totalProfit = totalReceived - totalExpense;

    // Calculate partner-wise profit distribution
    const partnerProfitMap = {};
    netProfitList.forEach(item => {
      partnerProfitMap[item.partner] = parseFloat(item.net_profit_amount) || 0;
    });

    // Calculate Amount Receivable by Partner = Partner's Expense + Partner's Net Profit
    const amountReceivableByPartner = [];
    partners.forEach(partner => {
      const partnerExpenseTotal = partnerTotals[partner] || 0;
      const partnerNetProfit = partnerProfitMap[partner] || 0;
      const totalReceivable = partnerExpenseTotal + partnerNetProfit;

      amountReceivableByPartner.push({
        partner_name: partner,
        expense_amount: partnerExpenseTotal,
        net_profit_amount: partnerNetProfit,
        total_receivable: totalReceivable
      });
    });

    return {
      success: true,
      data: {
        site: {
          site_code: site.site_code || siteCode,
          site_name: site.site_name || '',
          work_name: site.work_name || '',
          contractor_name: site.contractor_name || '',
          sub_contractor_name,
          work_amount: site.work_amount || 0,
          partners
        },
        bill_details: {
          items: billDetails,
          total_net_bill_amount: totalNetBillAmount,
          other_charges: otherCharges,
          total_amount_received: totalReceived
        },
        expense_details: {
          items: expenseDetails,
          partner_totals: partnerTotals,
          total_expense: totalExpense
        },
        profit_details: {
          total_amount_received: totalReceived,
          total_expense: totalExpense,
          total_profit: totalProfit
        },
        net_profit_division: netProfitList,
        amount_receivable_by_partner: amountReceivableByPartner,
        manual: {
          other_charges: otherCharges,
          net_profit: netProfitList,
          is_closed: manual.is_closed === 1
        }
      }
    };
  } catch (error) {
    console.error('Error in getFinalHishob:', error);
    return { success: false, message: error.message };
  }
};

const saveFinalHishob = async (siteCode, payload) => {
  const {
    other_charges = 0,
    net_profit = [],
    amount_receivable = [],
    is_closed = false
  } = payload || {};

  try {
    const checkQuery = `SELECT is_closed FROM final_hishob WHERE site_code = '${siteCode}' LIMIT 1`;
    const existing = await queryExecute(checkQuery);

    // If site is already closed, prevent any edits unless they are reopening the site
    if (existing[0]?.is_closed === 1 && is_closed) {
      return { success: false, message: 'Site is closed and cannot be edited. Please reopen to make changes.' };
    }

    // Prepare JSON data
    const netProfitJson = JSON.stringify(net_profit || []);
    const amountReceivableJson = JSON.stringify(amount_receivable || []);

    const upsert = `
      INSERT INTO final_hishob (
        site_code, 
        other_charges, 
        net_profit_json, 
        partner_receivable_json,
        is_closed, 
        updated_at
      )
      VALUES (
        '${siteCode}', 
        '${parseFloat(other_charges) || 0}', 
        '${netProfitJson.replace(/'/g, "\\'")}', 
        '${amountReceivableJson.replace(/'/g, "\\'")}',
        ${is_closed ? 1 : 0}, 
        NOW()
      )
      ON DUPLICATE KEY UPDATE
        other_charges = VALUES(other_charges),
        net_profit_json = VALUES(net_profit_json),
        partner_receivable_json = VALUES(partner_receivable_json),
        is_closed = VALUES(is_closed),
        updated_at = NOW()
    `;

    await queryExecute(upsert);

    // If site is being closed, update partner ledgers
    if (is_closed) {
      await updatePartnerLedgers(siteCode, amount_receivable || []);
    }

    return {
      success: true,
      message: is_closed ? 'Site Hishob finalized and closed. Partner ledgers updated.' : 'Site Hishob saved successfully.'
    };
  } catch (error) {
    console.error('Error in saveFinalHishob:', error);
    return { success: false, message: error.message };
  }
};

const updatePartnerLedgers = async (siteCode, amountReceivable = []) => {
  try {
    // Get site details for reference
    const siteQuery = `SELECT site_name, site_code FROM work_order WHERE site_code = '${siteCode}' LIMIT 1`;
    const siteRows = await queryExecute(siteQuery);
    const siteName = siteRows[0]?.site_name || siteCode;

    // Create ledger entries for each partner
    for (const item of amountReceivable) {
      const partnerName = item.partner_name || '';
      const totalReceivable = parseFloat(item.total_receivable) || 0;

      if (partnerName && totalReceivable > 0) {
        // Insert into partner ledger (assuming a final_hishob_receivable or partner_ledger table exists)
        const insertQuery = `
          INSERT INTO final_hishob_receivable (
            site_code,
            site_name,
            partner_name,
            expense_amount,
            net_profit_amount,
            total_receivable,
            created_at,
            updated_at
          )
          VALUES (
            '${siteCode}',
            '${siteName}',
            '${partnerName}',
            '${parseFloat(item.expense_amount) || 0}',
            '${parseFloat(item.net_profit_amount) || 0}',
            '${totalReceivable}',
            NOW(),
            NOW()
          )
          ON DUPLICATE KEY UPDATE
            expense_amount = VALUES(expense_amount),
            net_profit_amount = VALUES(net_profit_amount),
            total_receivable = VALUES(total_receivable),
            updated_at = NOW()
        `;
        await queryExecute(insertQuery);
      }
    }

    return { success: true, message: 'Partner ledgers updated.' };
  } catch (error) {
    console.error('Error in updatePartnerLedgers:', error);
    throw error;
  }
};

const getExpensesByPartner = async (siteCode) => {
  try {
    const query = `
      SELECT
        paid_by AS partner_name,
        SUM(amount) AS total_expense
      FROM (
        SELECT paid_by, amount FROM daily_expenses WHERE site_code = '${siteCode}' AND is_deleted = 0
        UNION ALL
        SELECT partner_name AS paid_by, (COALESCE(amount, 0) + COALESCE(other_charges, 0)) FROM material_entry WHERE site_code = '${siteCode}' AND is_deleted = 0
          AND (machinery_type IS NULL OR machinery_type = '')
        UNION ALL
        SELECT partner_name AS paid_by, machinery_total FROM material_entry WHERE site_code = '${siteCode}' AND is_deleted = 0
          AND machinery_type IS NOT NULL AND machinery_type != ''
        UNION ALL
        SELECT partner_name AS paid_by, COALESCE(grand_total, total_amount, 0) FROM mvjcb_detials WHERE site_code = '${siteCode}' AND is_deleted = 0
        UNION ALL
        SELECT partner_name AS paid_by, total_amount FROM mv_rollertt_details WHERE site_code = '${siteCode}' AND is_deleted = 0
        UNION ALL
        SELECT partner_name AS paid_by, total_amount FROM mvtipper_details WHERE site_code = '${siteCode}' AND is_deleted = 0
        UNION ALL
        SELECT COALESCE(paid_by, sub_payment_mode) AS paid_by, salary_paid FROM salary_entry WHERE is_deleted = 0
          AND remark LIKE '%${siteCode}%'
        UNION ALL
        SELECT paid_by, total_amount FROM payment_entry WHERE site_code = '${siteCode}' AND is_deleted = 0
      ) AS expenses
      GROUP BY paid_by
      ORDER BY paid_by
    `;

    const result = await queryExecute(query);
    return {
      success: true,
      data: result || []
    };
  } catch (error) {
    console.error('Error in getExpensesByPartner:', error);
    return {
      success: false,
      message: error.message
    };
  }
};

const getPartnerReceivables = async (siteCode) => {
  try {
    const query = `
      SELECT
        partner_name,
        expense_amount,
        net_profit_amount,
        total_receivable,
        created_at,
        updated_at
      FROM final_hishob_receivable
      WHERE site_code = '${siteCode}'
      ORDER BY partner_name
    `;

    const result = await queryExecute(query);
    return {
      success: true,
      data: result || []
    };
  } catch (error) {
    console.error('Error in getPartnerReceivables:', error);
    return {
      success: false,
      message: error.message
    };
  }
};

const generateFinalHishobPDF = async (siteCode, data, res) => {
  const billItems = data.bill_details?.items || [];
  const expenseItems = data.expense_details?.items || [];
  const netProfitDivision = data.net_profit_division || [];
  const amountReceivable = data.amount_receivable_by_partner || [];

  const html = `<!DOCTYPE html><html><head><style>${commonStyles}</style></head><body>
    <div class="report-title">Final Site Hishob</div>
    <div class="report-subtitle">Generated on: ${new Date().toLocaleDateString('en-GB')}</div>

    <div class="section-header">Site Summary</div>
    <div class="info-row"><span class="info-label">Site Code:</span> ${esc(data.site.site_code)}</div>
    <div class="info-row"><span class="info-label">Site Name:</span> ${esc(data.site.site_name)}</div>
    <div class="info-row"><span class="info-label">Work Name:</span> ${esc(data.site.work_name)}</div>
    <div class="info-row"><span class="info-label">Contractor Name:</span> ${esc(data.site.contractor_name)}</div>
    <div class="info-row"><span class="info-label">Sub Contractor Name:</span> ${esc(data.site.sub_contractor_name)}</div>
    <div class="info-row"><span class="info-label">Work Amount:</span> ${formatCurrency(data.site.work_amount)}</div>
    <div class="info-row"><span class="info-label">Partners:</span> ${esc((data.site.partners || []).join(', '))}</div>

    <div class="section-header">Bill Details (Total Amount Received)</div>
    <table>
      <thead><tr>
        <th>Date</th><th>Bill No / Stage</th><th class="text-right">Total Amount</th>
        <th class="text-right">Deduction Amount</th><th class="text-right">Net Bill Amount</th>
      </tr></thead>
      <tbody>
        ${billItems.map(row => `<tr>
          <td>${esc(formatDate(row.date))}</td><td>${esc(row.bill_no)}</td>
          <td class="text-right">${formatCurrency(row.total_bill_amount)}</td>
          <td class="text-right">${formatCurrency(row.deduction_amount)}</td>
          <td class="text-right">${formatCurrency(row.net_bill_amount)}</td>
        </tr>`).join('')}
        <tr class="total-row">
          <td colspan="4" class="text-right">Total Net Bill Amount</td>
          <td class="text-right">${formatCurrency(data.bill_details?.total_net_bill_amount)}</td>
        </tr>
      </tbody>
    </table>
    <div class="info-row">Other Charges or Expense (Manual): ${formatCurrency(data.manual?.other_charges)}</div>
    <div class="info-row bold">Total Amount Received: ${formatCurrency(data.profit_details?.total_amount_received)}</div>

    <div class="section-header">Expense Details (Total Expense by Partners)</div>
    <table>
      <thead><tr>
        <th>Sr</th><th>Name of Partner</th><th>Name of Party</th><th>Paid To</th>
        <th>Paid By</th><th>Source</th><th class="text-right">Total Expense</th>
      </tr></thead>
      <tbody>
        ${expenseItems.map((row, idx) => `<tr>
          <td>${row.sr || idx + 1}</td><td>${esc(row.partner_name)}</td><td>${esc(row.party_name)}</td>
          <td>${esc(row.paid_to)}</td><td>${esc(row.paid_by)}</td><td>${esc(row.source)}</td>
          <td class="text-right">${formatCurrency(row.total_amount)}</td>
        </tr>`).join('')}
        <tr class="total-row">
          <td colspan="6" class="text-right">Total Amount Expense</td>
          <td class="text-right">${formatCurrency(data.expense_details?.total_expense)}</td>
        </tr>
      </tbody>
    </table>

    <div class="section-header">Profit Details</div>
    <div class="info-row">Total Amount Received: <span class="bold">${formatCurrency(data.profit_details?.total_amount_received)}</span></div>
    <div class="info-row">Total Amount Expense: <span class="bold">${formatCurrency(data.profit_details?.total_expense)}</span></div>
    <div class="info-row">Total Profit: <span class="bold ${(data.profit_details?.total_profit || 0) >= 0 ? 'green' : 'red'}">${formatCurrency(data.profit_details?.total_profit)}</span></div>

    <div class="section-header">Net Profit (Profit Division Manual)</div>
    <table>
      <thead><tr><th>Name of Partner</th><th class="text-right">Net Profit (Manual)</th></tr></thead>
      <tbody>
        ${netProfitDivision.map(row => `<tr>
          <td>${esc(row.partner)}</td><td class="text-right">${formatCurrency(row.net_profit_amount)}</td>
        </tr>`).join('')}
      </tbody>
    </table>

    <div class="section-header">Amount Receivable by Partners</div>
    <table>
      <thead><tr>
        <th>Name of Partner</th><th class="text-right">Total Expense</th>
        <th class="text-right">Net Profit</th><th class="text-right">Total Receivable</th>
      </tr></thead>
      <tbody>
        ${amountReceivable.map(row => `<tr>
          <td>${esc(row.partner_name)}</td><td class="text-right">${formatCurrency(row.expense_amount)}</td>
          <td class="text-right">${formatCurrency(row.net_profit_amount)}</td>
          <td class="text-right">${formatCurrency(row.total_receivable)}</td>
        </tr>`).join('')}
      </tbody>
    </table>
  </body></html>`;

  const filename = `Final_Hishob_${siteCode}.pdf`;
  await generatePDF(html, res, filename, { layout: 'portrait' });
};

module.exports = {
  getSiteCodes,
  getFinalHishob,
  saveFinalHishob,
  getExpensesByPartner,
  getPartnerReceivables,
  generateFinalHishobPDF
};
