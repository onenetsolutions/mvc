const lib = require('../libs/index');
let service = {};

const esc = (value) => String(value ?? '').replace(/\\/g, '\\\\').replace(/'/g, "''");
const numVal = (v) => (v === '' || v === null || v === undefined) ? 'NULL' : v;

const normalizeAmountReceivedDetails = (value) => {
    if (Array.isArray(value)) {
        return JSON.stringify(value);
    }
    if (typeof value === 'string') {
        return value;
    }
    if (value && typeof value === 'object') {
        return JSON.stringify(value);
    }
    return '';
};

/**
 * INSERT Bill Adjustment Entry
 */
service.insertBillAdjustment = async (req, res, next) => {
    try {
        const entry_date = esc(req.body.entry_date || new Date().toISOString().split('T')[0]);
        const bank_name = esc(req.body.bank_name || '');
        const account_no = esc(req.body.account_no || '');
        const beneficiary_name = esc(req.body.beneficiary_name || '');
        const person_name = esc(req.body.person_name || '');
        const paid_by = esc(req.body.paid_by || '');
        const rtgs_amount = numVal(req.body.rtgs_amount);
        const comission_rate = numVal(req.body.comission_rate);
        const net_amount = numVal(req.body.net_amount);
        const amount_received_details = esc(normalizeAmountReceivedDetails(req.body.amount_received_details));
        const bal_amount = numVal(req.body.bal_amount);

        // Get the last entry number if needed (similar to your tender service)
        // Currently not using sr_no as it's not in your table structure

        const insertQuery = `
            INSERT INTO bill_adjustment (
                entry_date,
                bank_name,
                account_no,
                beneficiary_name,
                person_name,
                paid_by,
                rtgs_amount,
                comission_rate,
                net_amount,
                amount_received_details,
                bal_amount
            ) VALUES (
                '${entry_date}',
                '${bank_name}',
                '${account_no}',
                '${beneficiary_name}',
                '${person_name}',
                '${paid_by}',
                ${rtgs_amount},
                ${comission_rate},
                ${net_amount},
                '${amount_received_details}',
                ${bal_amount}
            );
        `;

        await lib.queryExecute(insertQuery);
        res.status(200).send({ result: req.body, message: 'Bill Adjustment Entry Added Successfully!' });
    } catch (error) {
        console.error('Error inserting Bill Adjustment:', error);
        res.status(500).send({ message: error.message || 'Error inserting Bill Adjustment' });
    }
};

/**
 * GET Bill Adjustment Entry List
 */
service.billAdjustmentList = async (req, res, next) => {
    try {
        let pageSet = '';
        const searchKey = req.query.searchKey || '';
        let searchCondition = 'is_deleted = 0';
        const allColumns = [
            "DATE_FORMAT(entry_date, '%d %m %Y')",
            'bank_name',
            'account_no',
            'beneficiary_name',
            'person_name',
            'paid_by'
        ];

        if (searchKey) {
            const searchConditions = allColumns
                .map(col => `${col} LIKE '%${searchKey}%'`)
                .join(' OR ');
            searchCondition += ` AND (${searchConditions})`;
        }

        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        if (size > 0) {
            pageSet = `LIMIT ${size} OFFSET ${page * size}`;
        }

        const queryStr = `
            SELECT
                bill_adjustment_id,
                DATE_FORMAT(entry_date, '%d %m %Y') AS entry_date,
                bank_name,
                account_no,
                beneficiary_name,
                person_name,
                paid_by,
                rtgs_amount,
                comission_rate,
                net_amount,
                amount_received_details,
                bal_amount,
                is_deleted
            FROM bill_adjustment
            WHERE ${searchCondition}
            ORDER BY bill_adjustment_id DESC
            ${pageSet};
        `;
        

        const countQuery = `
            SELECT COUNT(*) AS totalCount 
            FROM bill_adjustment 
            WHERE is_deleted = 0;
        `;

        const [totalCountResult, result] = await Promise.all([
            lib.queryExecute(countQuery),
            lib.queryExecute(queryStr)
        ]);

        const totalCount = totalCountResult[0].totalCount;

        const response = result.map(item => ({
            ...item,
            totalCount
        }));

        res.status(200).send(response);
    } catch (error) {
        console.error('Error in billAdjustmentList:', error);
        res.status(500).send({ message: error.message });
    }
};

/**
 * UPDATE or DELETE Bill Adjustment Entry
 */
service.updateDeleteBillAdjustment = async (req, res, next) => {
    try {
        const { changedUpdatedValue = 'edit', bill_adjustment_id } = req.body;

        // Validation: Ensure bill_adjustment_id is provided
        if (!bill_adjustment_id) {
            return res.status(400).send({ error: 'Missing bill_adjustment_id' });
        }

        if (changedUpdatedValue === 'edit') {
            const {
                entry_date = new Date().toISOString().split('T')[0],
                bank_name = '',
                account_no = '',
                beneficiary_name = '',
                person_name = '',
                paid_by = '',
                rtgs_amount = '',
                comission_rate = '',
                net_amount = '',
                amount_received_details = '',
                bal_amount = ''
            } = req.body || {};

            const safeEntryDate = esc(entry_date);
            const safeBankName = esc(bank_name);
            const safeAccountNo = esc(account_no);
            const safeBeneficiaryName = esc(beneficiary_name);
            const safePersonName = esc(person_name);
            const safePaidBy = esc(paid_by);
            const safeRtgsAmount = numVal(rtgs_amount);
            const safeComissionRate = numVal(comission_rate);
            const safeNetAmount = numVal(net_amount);
            const safeAmountReceivedDetails = esc(normalizeAmountReceivedDetails(amount_received_details));
            const safeBalAmount = numVal(bal_amount);

            const updateQuery = `
                UPDATE bill_adjustment SET
                    entry_date = '${safeEntryDate}',
                    bank_name = '${safeBankName}',
                    account_no = '${safeAccountNo}',
                    beneficiary_name = '${safeBeneficiaryName}',
                    person_name = '${safePersonName}',
                    paid_by = '${safePaidBy}',
                    rtgs_amount = ${safeRtgsAmount},
                    comission_rate = ${safeComissionRate},
                    net_amount = ${safeNetAmount},
                    amount_received_details = '${safeAmountReceivedDetails}',
                    bal_amount = ${safeBalAmount}
                WHERE bill_adjustment_id = ${bill_adjustment_id};
            `;

            await lib.queryExecute(updateQuery);
            return res.status(200).send({ message: 'Updated Successfully!', result: req.body });

        } else if (changedUpdatedValue === 'delete') {
            const deleteQuery = `
                UPDATE bill_adjustment SET is_deleted = 1
                WHERE bill_adjustment_id = ${bill_adjustment_id};
            `;
            await lib.queryExecute(deleteQuery);
            return res.status(200).send({ message: 'Deleted Successfully!' });

        } else {
            return res.status(400).send({ error: 'Invalid changedUpdatedValue' });
        }

    } catch (error) {
        console.error('Error in updateDeleteBillAdjustment:', error);
        return res.status(500).send({ message: error.message || 'Internal server error' });
    }
};

module.exports = service;
