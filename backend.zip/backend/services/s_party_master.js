const lib = require('../libs/index');
let service = {};

const sqlValue = (value) => {
  if (value === undefined || value === null || value === '') {
    return 'NULL';
  }
  return `'${value}'`;
};


service.insertpartyMaster = async (req, res, next) => {
  try {

    const party_name = req.body.party_name || '';
    const party_type = req.body.party_type || '';
    const party_address = req.body.party_address || '';
    const mobile_no = req.body.mobile_no || '';
    const gst_no = req.body.gst_no || '';
    const pan_no = req.body.pan_no || '';


        const queryStr = `INSERT INTO party_master 
          (party_name,gst_no,pan_no,party_type,party_address,mobile_no) 
          VALUES 
          (${sqlValue(party_name)},${sqlValue(gst_no)},${sqlValue(pan_no)},${sqlValue(party_type)},${sqlValue(party_address)},${sqlValue(mobile_no)})`;


    await lib.queryExecute(queryStr);


    res.status(200).send({ result: req.body, message: 'Added Successfully!' });
  } catch (error) {
    // Handling any errors
    res.status(500).send(error);
  }
};



service.partyMasterList = async (req, res, next) => {
  try {
    let pageSet = '';
    const searchKey = req.query.searchKey || '';
    let searchCondition = 'is_deleted = 0';

    const allColumns = ['party_name','gst_no','party_type','pan_no','party_address','mobile_no'];

    if (searchKey) {
      const searchConditions = allColumns
        .map(col => `${col} LIKE '%${searchKey}%'`)
        .join(' OR ');


      searchCondition += ` AND (${searchConditions})`;
    }

    const page = parseInt(req.query.page, 10) || 0;
    const size = parseInt(req.query.size, 10) || 10;

    if (size > 0) {
      pageSet = `LIMIT ${size} OFFSET ${page * size}`;
    }

    let queryStr = `SELECT * 
                      FROM party_master
                      WHERE ${searchCondition} 
                      ORDER BY party_id ASC 
                      ${pageSet}`;

    const countQuery = `SELECT COUNT(*) AS totalCount 
                          FROM party_master
                          WHERE is_deleted = 0`;

    const totalCountResult = await lib.queryExecute(countQuery);
    const totalCount = totalCountResult[0].totalCount;

    const result = await lib.queryExecute(queryStr);

    // Include total count in the response
    const response = result.map(item => ({
      ...item,
      totalCount
    }));

    res.status(200).send(response);

  } catch (error) {
    console.error('Error in party_master:', error);
    res.status(500).send({ message: error.message });
  }
};



// Update or delete cylinder_master entry

service.updateDeletepartyMaster = async (req, res, next) => {
    try {
        console.log('Request body:', req.body);
        
        const changedUpdatedValue = req.body.changedUpdatedValue || 'edit';
        const party_id = req.body.party_id;

        if (changedUpdatedValue === 'edit') {
            const {
              party_name = '',
              gst_no = '',
              pan_no = '',
              party_type = '',
              party_address = '',
              mobile_no = ''

            } = req.body;

            const queryStr = `UPDATE party_master SET 
              party_name = ${sqlValue(party_name)},
              gst_no = ${sqlValue(gst_no)},
              pan_no = ${sqlValue(pan_no)},
              party_type = ${sqlValue(party_type)},
              party_address = ${sqlValue(party_address)},
              mobile_no = ${sqlValue(mobile_no)}
                WHERE party_id = ${party_id}`;

            console.log('Generated SQL query:', queryStr);
            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Updated Successfully!' });

        } else if (changedUpdatedValue === 'delete') {
            const queryStr = `UPDATE party_master SET 
                is_deleted = 1
                WHERE party_id = ${party_id}`;

            await lib.queryExecute(queryStr);
            res.status(200).send({ message: 'Deleted Successfully!' });
        } else {
            res.status(400).send({ error: 'Invalid changed update value' });
        }
    } catch (error) {
        console.error('Error in updatePartyMaster:', error);
        res.status(500).send({ error: error.message || error });
    }
};



module.exports = service;


