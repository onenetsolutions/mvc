const { queryExecute } = require('./libs/dbRequest');
(async () => {
    const sample = await queryExecute("SELECT remark, paid_by, employee_name, salary_paid FROM salary_entry WHERE is_deleted = 0 LIMIT 5");
    console.log("Sample salary entries:", JSON.stringify(sample, null, 2));
    process.exit(0);
})();
