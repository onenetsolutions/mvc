const auth = require('../libs/auth');

/**
 * Authentication middleware that verifies JWT token and validates active session
 * Expects token in Authorization header as: "Bearer <token>"
 * Also supports legacy "authtoken" header for backward compatibility
 */
const authenticate = async (req, res, next) => {
    try {
        // Try to get token from Authorization header (Bearer token)
        let token = req.headers['authorization']?.split(' ')[1];
        
        // Fallback to legacy authtoken header for backward compatibility
        if (!token) {
            token = req.headers['authtoken'];
        }

        if (!token) {
            return res.status(401).send({
                result: null,
                message: 'Authentication token is required. Please sign in to continue.'
            });
        }

        // Verify the JWT token
        const decoded = await auth.verifyASY(token);
        
        req.user = decoded;
        
        next(); // Proceed to the next middleware or route handler
    } catch (error) {
        console.error('Authentication error:', error);
        return res.status(401).send({
            result: null,
            message: 'Invalid or expired token. Please sign in again.'
        });
    }
};

module.exports = authenticate;
